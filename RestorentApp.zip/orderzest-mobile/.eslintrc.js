module.exports = {
  root: true,
  extends: '@react-native',
  'prettier/prettier': [
    'error',
    {
      singleQuote: true,
      parser: 'flow',
    },
  ],
};
