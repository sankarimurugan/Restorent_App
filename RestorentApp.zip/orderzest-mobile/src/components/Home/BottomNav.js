import {
  Image,
  Text,
  TouchableOpacity,
  View,
  Modal,
  ImageBackground,
} from 'react-native';
import React, {useState} from 'react';

import {C, F} from '../../assets/styles/ColorsFonts';

import {fS} from '../../constants/Loader/Loader';
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  bottomicon,
  bottomnav,
  delivery,
  histry,
  homeicon,
  profile,
  profileicon,
  rewards,
  tableicon,
} from '../../assets/img';
const NavBar = ({setActive, active}) => {
  const navi = useNavigation();
  const locat = useRoute();
  console.log('locat', locat?.name);

  const navName = locat?.name;
  return (
    <ImageBackground
      tintColor={C.PRIMARY_BG}
      source={bottomnav}
      style={{
        height: fS(100),
        position: 'absolute',
        bottom: fS(0),
        width: '100%',
      }}>
      <View style={{flex: 1}}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingHorizontal: fS(35),
            paddingVertical: fS(10),
          }}>
          <TouchableOpacity onPress={() => navi.navigate('home')}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={homeicon}
                style={[
                  {width: fS(30), height: fS(30), objectFit: 'contain'},
                  navName == 'home'
                    ? {tintColor: C.BLACK}
                    : {tintColor: C.DARK_GRAY},
                ]}
              />
              <Text
                style={[
                  {fontSize: fS(15), fontWeight: '500'},
                  navName == 'home' ? {color: C.BLACK} : {color: C.DARK_GRAY},
                ]}>
                Home
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={histry}
                style={[
                  {width: fS(30), height: fS(30), objectFit: 'contain'},
                  navName == 'history'
                    ? {tintColor: C.BLACK}
                    : {tintColor: C.DARK_GRAY},
                ]}
              />
              <Text
                style={[
                  {fontSize: fS(15), fontWeight: '500'},
                  navName == 'history'
                    ? {color: C.BLACK}
                    : {color: C.DARK_GRAY},
                ]}>
                Histry
              </Text>
            </View>
          </TouchableOpacity>

          <View>
            <Modal
              animationType="slide"
              transparent={true}
              visible={active}
              onRequestClose={() => {
                setActive(false);
                console.warn('close');
              }}>
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: 'rgba(0, 0, 0, 0.3)',
                }}>
                <View
                  style={{
                    backgroundColor: 'white',
                    width: '85%',
                    height: '45%',
                    alignItems: 'center',
                    borderRadius: 20,
                  }}>
                  <View style={{marginBottom: '6%', marginTop: '5%'}}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(28),
                        color: '#000',
                      }}>
                      Select your food type
                    </Text>
                  </View>

                  <View
                    style={{
                      width: '100%',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <View style={{width: '85%', marginBottom: '6%'}}>
                      <View
                        style={{
                          flexDirection: 'row',
                          width: '100%',
                          justifyContent: 'space-between',
                        }}>
                        <TouchableOpacity
                          onPress={() =>
                            // navi.navigate('FoodDeliveryList')
                            navi.navigate('FoodOrderList', {
                              type: 'delivery',
                            })
                          }
                          style={{
                            width: '45%',
                            padding: '16%',
                            backgroundColor: '#FFF',
                            borderRadius: 20,
                            elevation: 8,
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <View style={{marginBottom: '3%'}}>
                            <Image
                              source={delivery}
                              style={{
                                width: fS(200),
                                height: fS(80),
                                resizeMode: 'contain',
                              }}
                            />
                          </View>
                          <View
                            style={{
                              width: fS(80),
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}>
                            <Text
                              style={{
                                fontWeight: '700',
                                fontSize: fS(16),
                                color: '#000',
                              }}>
                              Delivery
                            </Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => navi.navigate('TableDateTime')}
                          style={{
                            width: '45%',
                            padding: '16%',
                            backgroundColor: '#FFF',
                            borderRadius: 20,
                            elevation: 8,
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Image
                            source={tableicon}
                            style={{
                              width: fS(200),
                              height: fS(80),
                              resizeMode: 'contain',
                            }}
                          />
                        </TouchableOpacity>
                      </View>
                    </View>
                    <TouchableOpacity
                      onPress={() => setActive(!active)}
                      style={{
                        backgroundColor: '#A4A4A4',
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        padding: 12,
                        width: '45%',
                      }}>
                      <Text
                        style={{
                          fontWeight: '600',
                          fontSize: fS(21),
                          color: '#FFF',
                        }}>
                        Cancel
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </Modal>
            <TouchableOpacity
              onPress={() => setActive(!active)}
              style={{
                width: fS(90),
                height: fS(90),
                borderRadius: fS(100),
                backgroundColor: '#FFD400',
                alignItems: 'center',
                justifyContent: 'center',
                position: 'absolute',
                bottom: fS(0),
                alignSelf: 'center',
                left: fS(-35),
                right: 0,
              }}>
              <View>
                <Image
                  source={bottomicon}
                  style={{width: fS(30), height: fS(30)}}
                />
              </View>
            </TouchableOpacity>
          </View>

          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={rewards}
                style={[
                  {width: fS(30), height: fS(30), objectFit: 'contain'},
                  navName == 'rewards'
                    ? {tintColor: C.BLACK}
                    : {tintColor: C.DARK_GRAY},
                ]}
              />
              <Text
                style={[
                  {fontSize: fS(15), fontWeight: '500'},
                  navName == 'rewards'
                    ? {color: C.BLACK}
                    : {color: C.DARK_GRAY},
                ]}>
                Rewards
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navi.navigate('profile')}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={profileicon}
                style={[
                  {width: fS(28), height: fS(29), objectFit: 'contain'},
                  navName == 'profile'
                    ? {tintColor: C.BLACK}
                    : {tintColor: C.DARK_GRAY},
                ]}
              />
              <Text
                style={[
                  {fontSize: fS(15), fontWeight: '500'},
                  navName == 'profile'
                    ? {color: C.BLACK}
                    : {color: C.DARK_GRAY},
                ]}>
                Profile
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
};

export default NavBar;
