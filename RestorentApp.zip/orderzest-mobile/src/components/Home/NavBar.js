import {Image, Text, TouchableOpacity, View, Modal} from 'react-native';
import React, {useState} from 'react';

import {C, F} from '../../assets/styles/ColorsFonts';

import {fS} from '../../constants/Loader/Loader';
import {useNavigation} from '@react-navigation/native';
import {
  bottomicon,
  delivery,
  histry,
  homeicon,
  profile,
  profileicon,
  rewards,
  tableicon,
} from '../../assets/img';
const NavBar = () => {
  const [active, setActive] = useState(false);
  const navigation = useNavigation();

  return (
    <View
      style={{
        height: fS(100),
        position: 'absolute',
        bottom: fS(0),
        width: '100%',
        backgroundColor: '#FFF',
        borderRadius: 15,
      }}>
      <View style={{flex: 1}}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
            paddingHorizontal: fS(35),
            paddingVertical: fS(10),
          }}>
          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={homeicon}
                style={{width: fS(30), height: fS(30)}}
              />
              <Text
                style={{color: '#252525', fontSize: fS(15), fontWeight: '500'}}>
                Home
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image source={histry} style={{width: fS(30), height: fS(30)}} />
              <Text
                style={{color: '#A4A4A4', fontSize: fS(15), fontWeight: '500'}}>
                Histry
              </Text>
            </View>
          </TouchableOpacity>

          <View>
            <Modal
              animationType="slide"
              transparent={true}
              visible={active}
              onRequestClose={() => {
                setActive(false);
                console.warn('close');
              }}>
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'center',
                  backgroundColor: 'rgba(0, 0, 0, 0.5)',
                }}>
                <View
                  style={{
                    backgroundColor: 'white',
                    width: '85%',
                    height: '45%',
                    alignItems: 'center',
                    borderRadius: 20,
                  }}>
                  <View style={{marginBottom: '6%', marginTop: '5%'}}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(28),
                        color: '#000',
                      }}>
                      Select your food type
                    </Text>
                  </View>

                  <View
                    style={{
                      width: '100%',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <View style={{width: '85%', marginBottom: '6%'}}>
                      <View
                        style={{
                          flexDirection: 'row',
                          width: '100%',
                          justifyContent: 'space-between',
                        }}>
                        <TouchableOpacity
                          onPress={() =>
                            navigation.navigate('FoodDeliveryList')
                          }
                          style={{
                            width: '45%',
                            padding: '16%',
                            backgroundColor: '#FFF',
                            borderRadius: 20,
                            elevation: 8,
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <View style={{marginBottom: '3%'}}>
                            <Image
                              source={delivery}
                              style={{
                                width: fS(200),
                                height: fS(80),
                                resizeMode: 'contain',
                              }}
                            />
                          </View>
                          <View
                            style={{
                              width: fS(80),
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}>
                            <Text
                              style={{
                                fontWeight: '700',
                                fontSize: fS(16),
                                color: '#000',
                              }}>
                              Delivery
                            </Text>
                          </View>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => navigation.navigate('TableDateTime')}
                          style={{
                            width: '45%',
                            padding: '16%',
                            backgroundColor: '#FFF',
                            borderRadius: 20,
                            elevation: 8,
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Image
                            source={tableicon}
                            style={{
                              width: fS(200),
                              height: fS(80),
                              resizeMode: 'contain',
                            }}
                          />
                        </TouchableOpacity>
                      </View>
                    </View>
                    <TouchableOpacity
                      onPress={() => setActive(!active)}
                      style={{
                        backgroundColor: '#A4A4A4',
                        borderRadius: 10,
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'row',
                        padding: 12,
                        width: '45%',
                      }}>
                      <Text
                        style={{
                          fontWeight: '600',
                          fontSize: fS(21),
                          color: '#FFF',
                        }}>
                        Cancel
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </Modal>
            <TouchableOpacity
              onPress={() => setActive(!active)}
              style={{
                width: 60,
                height: 60,
                borderRadius: 30,
                backgroundColor: '#FFD400',
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <View>
                <Image
                  source={bottomicon}
                  style={{width: fS(30), height: fS(30)}}
                />
              </View>
            </TouchableOpacity>
          </View>

          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image source={rewards} style={{width: fS(30), height: fS(30)}} />
              <Text
                style={{color: '#A4A4A4', fontSize: fS(15), fontWeight: '500'}}>
                Rewards
              </Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: fS(15),
              }}>
              <Image
                source={profileicon}
                style={{width: fS(28), height: fS(29)}}
              />
              <Text
                style={{color: '#A4A4A4', fontSize: fS(15), fontWeight: '500'}}>
                Profile
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default NavBar;
