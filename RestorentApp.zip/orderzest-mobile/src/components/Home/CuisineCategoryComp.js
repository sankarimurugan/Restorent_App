import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {
  americaflag,
  banner,
  cusisne1,
  cusisne2,
  food,
  india,
  profile_img,
} from '../../assets/img';
import {useNavigation} from '@react-navigation/native';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const CuisineCategoryComp = ({setActive}) => {
  const navi = useNavigation();
  return (
    <View style={styles.cont}>
      <View style={styles.textcont}>
        <Text style={styles.text}>Cuisine Category</Text>
        <TouchableOpacity
          activeOpacity={0.6}
          onPress={() => navi.navigate('cuisinLisscreen')}>
          <Text style={styles.text2}>See all (8)</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.imgcont}>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne1} style={styles.img} />
          <View
            style={{
              flexDirection: 'row',
              top: fS(20),
              position: 'absolute',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <View style={styles.sm_img_cont}>
              <Image source={india} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>Indian</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={0.7}
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.b_cont}>
        <Text style={styles.b_text}>
          “Life is the biggest party you’ll ever be at”
        </Text>
        <TouchableOpacity
          onPress={() => setActive(true)}
          style={styles.btn_cont}
          activeOpacity={0.6}>
          <Text style={styles.btn_text}>Select Food</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CuisineCategoryComp;

const styles = StyleSheet.create({
  text: {
    fontSize: fS(22),
    fontFamily: F.f5,
    color: C.BLACK,
  },
  text2: {
    fontSize: fS(18),
    fontFamily: F.f4,
    color: C.BLACK,
  },
  cont: {
    paddingHorizontal: fS(25),
    marginTop: fS(20),
  },
  textcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imgcont: {
    width: '100%',
    flexDirection: 'row',
    marginTop: fS(20),
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: fS(30),
  },
  foodcont: {
    height: fS(150),
    width: '47%',
    // backgroundColor: 'red',
    position: 'relative',
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'cover',
    borderRadius: 10,
  },
  sm_img_cont: {
    height: fS(30),
    width: fS(50),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.WHITE,
    borderTopRightRadius: fS(5),
    borderBottomRightRadius: fS(5),
    // flexDirection: 'row',
  },
  smimg: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  flgtext: {
    fontFamily: F.f4,
    fontSize: fS(22),
    color: C.WHITE,
    marginStart: fS(5),
  },
  b_cont: {
    SCREEN_WIDTH,
    flexDirection: 'row',
    marginTop: fS(30),
    // paddingHorizontal: fS(25),
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  b_text: {
    fontFamily: F.f4,
    fontSize: fS(16),
    color: C.BLACK,
    width: '70%',
  },
  btn_cont: {
    height: 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.PRIMARY,
    paddingVertical: fS(10),
    paddingHorizontal: fS(10),
    borderRadius: fS(10),
  },
  btn_text: {
    fontFamily: F.f5,
    fontSize: fS(16),
    color: C.BLACK,
  },
});
