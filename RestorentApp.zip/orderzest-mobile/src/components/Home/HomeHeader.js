import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C} from '../../assets/styles/ColorsFonts';
import {menu, profile, profile_img, qr_icon} from '../../assets/img';
import {useNavigation} from '@react-navigation/native';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');
const HomeHeader = ({setMenuClick, menuClick}) => {
  const navi = useNavigation();
  return (
    <View style={styles.container}>
      <TouchableOpacity
        activeOpacity={0.6}
        style={styles.menucont}
        onPress={() => setMenuClick(!menuClick)}>
        <Image style={styles.menu} source={menu} />
      </TouchableOpacity>
      <View style={styles.rightcont}>
        <TouchableOpacity
          activeOpacity={0.6}
          style={styles.simgcont}
          onPress={() => navi.navigate('qr-scanner')}>
          <Image style={styles.smimg} source={qr_icon} />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('profile')}
          activeOpacity={0.6}
          style={styles.simgcont2}>
          <Image style={styles.smimg2} source={profile_img} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default HomeHeader;

const styles = StyleSheet.create({
  container: {
    SCREEN_WIDTH,
    height: fS(110),
    backgroundColor: C.PRIMARY_BG,
    // backgroundColor: 'red',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: fS(25),
  },
  menucont: {
    height: fS(40),
    width: fS(40),
  },
  menu: {
    objectFit: 'contain',
    height: '100%',
    width: '100%',
  },
  rightcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: fS(20),
  },
  simgcont: {
    height: fS(35),
    width: fS(35),
    alignItems: 'center',
    justifyContent: 'center',
  },
  simgcont2: {
    height: fS(50),
    width: fS(50),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: fS(10),
    shadowOpacity: 0.5,
    shadowRadius: fS(20),
    shadowColor: C.BLACK,
    shadowOffset: {
      height: 0,
      width: 1,
    },
    elevation: 12,
  },
  smimg2: {
    height: fS(46),
    width: fS(46),
    objectFit: 'contain',
    borderRadius: fS(10),
  },
  smimg: {
    height: '100%',
    width: '100%',
    alignSelf: 'center',
    objectFit: 'contain',
  },
  //   smimg2: {
  //     height: fS(50),
  //     width: fS(50),
  //     objectFit: 'contain',
  //     borderRadius: fS(10),
  //   },
});
