import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Animated,
  Pressable,
} from 'react-native';
import React from 'react';
import {C, F} from '../../assets/styles/ColorsFonts';
import {fS} from '../../constants/Loader/Loader';
import {location, logout, profile_img} from '../../assets/img';
import {side_menu_list} from '../../redux/api/DummyJson';
import {useNavigation} from '@react-navigation/native';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const sidebarComp = ({tranceX1, tranfun, menuClick, toggle}) => {
  console.log(tranceX1);
  const navi = useNavigation();
  return (
    <>
      {menuClick && (
        <TouchableOpacity
          activeOpacity={0.6}
          style={[styles.bglayer]}
          onPress={() => tranfun()}
        />
      )}
      <Animated.View
        style={[styles.menucont, {transform: [{translateX: tranceX1}]}]}>
        <Pressable
          onPress={() => {
            navi.navigate('profile');
            tranfun();
          }}
          style={styles.profilecont}>
          <TouchableOpacity activeOpacity={0.6} style={styles.simgcont2}>
            <Image style={styles.smimg2} source={profile_img} />
          </TouchableOpacity>
          <View>
            <Text style={styles.name}>Stella Chrish</Text>
            <Text style={styles.dis}>Designer</Text>
          </View>
        </Pressable>
        <View style={styles.list}>
          {side_menu_list?.map(item => {
            return (
              <TouchableOpacity
                style={styles.list_cont}
                onPress={() => {
                  tranfun();
                  navi.navigate(item?.navi);
                }}>
                <View style={styles.list_img_cont}>
                  <Image source={item?.img} style={styles.img} />
                </View>
                <Text style={styles.menu_list}>{item?.list}</Text>
              </TouchableOpacity>
            );
          })}
          <TouchableOpacity style={styles.list_cont} onPress={() => toggle()}>
            <View style={styles.list_img_cont}>
              <Image source={logout} style={styles.img} />
            </View>
            <Text style={styles.menu_list}>Logout</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </>
  );
};

export default sidebarComp;

const styles = StyleSheet.create({
  menucont: {
    SCREEN_HEIGHT,
    width: '80%',
    backgroundColor: C.WHITE,
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    zIndex: 100,
  },
  bglayer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    backgroundColor: C.SIDEBAR_BG,
    zIndex: 100,
  },
  profilecont: {
    height: fS(130),
    width: '100%',
    backgroundColor: C.PRIMARY,
    borderBottomEndRadius: fS(30),
    borderBottomStartRadius: fS(30),
    alignItems: 'center',
    justifyContent: 'flex-start',
    flexDirection: 'row',
    paddingHorizontal: fS(30),
    gap: fS(20),
  },
  simgcont2: {
    height: fS(60),
    width: fS(60),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: fS(10),
    shadowOpacity: 0.5,
    shadowRadius: fS(20),
    shadowColor: C.BLACK,
    shadowOffset: {
      height: 0,
      width: 1,
    },
    elevation: 12,
  },
  smimg2: {
    height: fS(54),
    width: fS(54),
    objectFit: 'contain',
    borderRadius: fS(10),
  },
  name: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(20),
    lineHeight: fS(30),
  },
  dis: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(16),
    lineHeight: fS(20),
  },
  list: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    width: '100%',
    paddingHorizontal: fS(25),
    marginTop: fS(20),
  },

  list_cont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(10),
    width: '90%',
    paddingVertical: fS(16),
  },
  list_img_cont: {
    height: fS(39),
    width: fS(30),
    alignItems: 'center',
    textAlign: 'left',
    // justifyContent: 'center',
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  menu_list: {
    fontFamily: F.f3,
    fontSize: fS(20),
    color: C.BLACK,
  },
});
