import {Dimensions, Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import Carousel from 'react-native-snap-carousel';
import {C} from '../../assets/styles/ColorsFonts';
import {banner} from '../../assets/img';
const BannerCarouselImg = Dimensions.get('window').width;
const {width: width, height: height} = Dimensions.get('window');

const HomeBannerComp = () => {
  const data = [
    {
      imgUrl: banner,
    },
    {
      imgUrl: banner,
    },
    {
      imgUrl: banner,
    },
  ];

  const CarouselCardItem = ({item, index}) => {
    return (
      <View style={styles.container} key={index}>
        <Image source={item?.imgUrl} style={styles.image} />
      </View>
    );
  };
  return (
    <View style={styles.bannercomp}>
      <Carousel
        style={{borderRadius: 25, alignSelf: 'center'}}
        layout="tinder"
        layoutCardOffset={9}
        data={data}
        renderItem={CarouselCardItem}
        sliderWidth={BannerCarouselImg}
        itemWidth={width}
        inactiveSlideScale={0.98}
        inactiveSlideOpacity={0.5}
        inactiveSlideShift={0.8}
        useScrollView={true}
        autoplay={true}
        autoplayDelay={4000}
        autoplayInterval={10000}
        loop={true}
        activeSlideAlignment={'center'}
      />
    </View>
  );
};

export default HomeBannerComp;

const styles = StyleSheet.create({
  bannercomp: {
    width: '100%',
    marginTop: fS(15),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 15,
    // backgroundColor: 'red',
  },
  container: {
    backgroundColor: C.PRIMARY_BG,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    height: fS(220),
    width: width - fS(25),
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    borderRadius: 15,
  },
  image: {
    alignSelf: 'center',
    height: '100%',
    width: '100%',
    borderRadius: 15,
    objectFit: 'contain',
    // overflow: 'visible',
  },
});
