import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  women,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';

const FoodCartPage = () => {
  const navigation = useNavigation();
  const foods = [
    {
      name: 'Chicken Briyani',
      rate: ' $22.50',
    },

    {
      name: ' Burger & Fries',
      rate: '$45.50',
    },
  ];

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <View
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          justifyContent: 'space-between',
        }}>
        <ScrollView
          style={{
            flex: 1,
            paddingTop: 30,
          }}>
          <View
            style={{
              width: '100%',
              flex: 1,
            }}>
            <View
              style={{
                width: '100%',
                alignItems: 'center',
                flex: 1,
              }}>
              <View
                style={{
                  width: '93%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '6%',
                  justifyContent: 'space-between',
                }}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <TouchableOpacity onPress={() => navigation.goBack()}>
                    <Image
                      source={leftarrow}
                      style={{
                        width: fS(20),
                        height: fS(20),
                        resizeMode: 'contain',
                      }}
                    />
                  </TouchableOpacity>
                  <View style={{marginLeft: 8}}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(23),
                        color: '#252525',
                      }}>
                      Cart
                    </Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={{
                    width: 35,
                    height: 35,
                    backgroundColor: '#FFD400',
                    borderRadius: 10,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image
                    source={cart}
                    style={{
                      width: fS(24),
                      height: fS(23),
                      resizeMode: 'contain',
                    }}
                  />
                </TouchableOpacity>
              </View>

              {foods.map((food, index) => (
                <View
                  style={[
                    {
                      width: '93%',
                      borderRadius: 20,
                      elevation: 5,
                      backgroundColor: '#FFF',
                      padding: 10,
                      marginBottom: '5%',
                    },
                  ]}
                  key={index}>
                  <View
                    style={{
                      width: '100%',
                    }}>
                    <View
                      style={{
                        width: '100%',
                        flexDirection: 'row',
                      }}>
                      <View
                        style={{
                          width: '45%',
                        }}>
                        <View
                          style={{
                            width: '100%',
                            alignItems: 'center',
                          }}>
                          <Image
                            source={food1}
                            style={{
                              width: '100%',
                              height: fS(150),
                              resizeMode: 'stretch',
                            }}
                          />
                        </View>
                      </View>

                      <View
                        style={{
                          width: '55%',
                        }}>
                        <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                          <Text
                            style={{
                              fontWeight: '700',
                              fontSize: fS(21),
                              color: '#252525',
                            }}>
                            {food.name}
                          </Text>
                        </View>
                        <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                          <Text
                            style={{
                              fontWeight: '700',
                              fontSize: fS(16),
                              color: '#252525',
                            }}>
                            {food.rate}
                          </Text>
                        </View>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                          }}>
                          <View
                            style={{
                              width: '70%',
                              height: fS(50),
                              flexDirection: 'row',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              backgroundColor: '#FFF',
                              borderRadius: 10,
                              elevation: 5,
                              padding: 8,
                              marginTop: '4%',
                              marginHorizontal: '6%',
                              shadowColor: 'black',
                              shadowOffset: {
                                width: 7,
                                height: 7,
                              },
                              shadowOpacity: 0.5,
                              shadowRadius: 5,
                            }}>
                            <TouchableOpacity
                              style={{
                                width: fS(30),
                                height: fS(30),
                                backgroundColor: '#F5F5F5',
                                borderRadius: 5,
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}>
                              <Text
                                style={{
                                  fontWeight: '700',
                                  fontSize: fS(24),
                                  color: '#252525',
                                }}>
                                -
                              </Text>
                            </TouchableOpacity>
                            <Text
                              style={{
                                fontWeight: '700',
                                fontSize: fS(22),
                                color: '#252525',
                                textAlign: 'justify',
                              }}>
                              01
                            </Text>
                            <TouchableOpacity
                              style={{
                                width: fS(30),
                                height: fS(30),
                                backgroundColor: '#FFD400',
                                borderRadius: 5,
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}>
                              <Text
                                style={{
                                  fontWeight: '700',
                                  fontSize: fS(24),
                                  color: '#252525',
                                }}>
                                +
                              </Text>
                            </TouchableOpacity>
                          </View>
                          <TouchableOpacity
                            style={{
                              marginLeft: '6%',
                            }}>
                            <AntDesign
                              name="delete"
                              color="#A4A4A4"
                              size={height / 42}
                            />
                          </TouchableOpacity>
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
              ))}
            </View>
          </View>
        </ScrollView>
        <View
          style={{
            width: '100%',
            alignItems: 'center',
            padding: 5,
          }}>
          <View style={{width: '93%'}}>
            <View style={{marginBottom: '4%'}}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(23),
                  color: '#252525',
                }}>
                Price Details
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: fS(18),
                  color: '#000',
                }}>
                Price (1 items)
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(20),
                  color: '#252525',
                }}>
                $22.60
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: fS(18),
                  color: '#000',
                }}>
                Taxes
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(20),
                  color: '#252525',
                }}>
                $5.00
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(23),
                  color: '#000',
                }}>
                Total Amount
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(22),
                  color: '#252525',
                }}>
                $27.60
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => navigation.navigate('BookingSuccess')}
              style={{
                width: '100%',
                padding: 12,
                backgroundColor: '#FFD400',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '5%',
              }}>
              <Text
                style={[
                  {
                    color: '#000',
                    fontSize: 16,
                    fontWeight: '700',
                  },
                ]}>
                Proceed to Pay
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default FoodCartPage;
