import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  fooddelivery,
  process,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';

const FoodDeliveryDetail = () => {
  const navigation = useNavigation();
  const ratings = [
    {
      name: 'Charles Kuanda',
      rating: '4.8',
    },

    {
      name: ' Gunaseelan',
      rating: '3.8',
    },
    {
      name: ' Guna',
      rating: '3.8',
    },
  ];

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScrollView>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              marginTop: '7%',
            }}>
            <View
              style={{
                width: '93%',
                flexDirection: 'row',
                alignItems: 'center',
                marginBottom: '6%',
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Image
                    source={leftarrow}
                    style={{
                      width: fS(20),
                      height: fS(20),
                      resizeMode: 'contain',
                    }}
                  />
                </TouchableOpacity>
                <View style={{marginLeft: 8}}>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(23),
                      color: '#252525',
                    }}>
                    Wingman’s Restaurant
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  width: 35,
                  height: 35,
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  source={cart}
                  style={{
                    width: fS(24),
                    height: fS(23),
                    resizeMode: 'contain',
                  }}
                />
              </TouchableOpacity>
            </View>

            <View
              style={{
                width: '90%',
              }}>
              <View
                style={{
                  width: '100%',
                  alignItems: 'center',
                  position: 'relative',
                  justifyContent: 'center',
                  marginBottom: '5%',
                }}>
                <Image
                  source={food4}
                  style={{
                    width: '100%',
                    height: fS(230),
                    resizeMode: 'stretch',
                  }}
                />

                <View
                  style={{
                    width: 27,
                    height: 25,
                    borderRadius: 5,
                    position: 'absolute',
                    top: 15,
                    right: 20,
                    backgroundColor: '#FFF',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <AntDesign name="heart" color="#FF0000" size={height / 45} />
                </View>
              </View>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '3%',
                }}>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(23),
                    color: '#252525',
                  }}>
                  Chicken Briyani
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Icon name="star" color="#FFD400" size={height / 50} />
                  <View style={{marginLeft: 4}}>
                    <Text
                      style={{
                        fontWeight: '500',
                        fontSize: fS(18),
                        color: '#252525',
                      }}>
                      4.8
                    </Text>
                  </View>
                </View>
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '4%',
                }}>
                <Image
                  source={india}
                  style={{
                    width: fS(25),
                    height: fS(22),
                    resizeMode: 'contain',
                  }}
                />

                <View style={{marginLeft: 7}}>
                  <Text
                    style={{
                      color: '#A4A4A4',
                      fontSize: fS(16),
                      fontWeight: '700',
                    }}>
                    Indian
                  </Text>
                </View>
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '6%',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(22),
                    color: '#252525',
                  }}>
                  $22.50
                </Text>

                <View
                  style={{
                    width: '33%',
                    height: fS(50),
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    backgroundColor: '#FFF',
                    borderRadius: 10,
                    elevation: 5,
                    padding: 8,
                  }}>
                  <TouchableOpacity
                    style={{
                      width: fS(30),
                      height: fS(30),
                      backgroundColor: '#F5F5F5',
                      borderRadius: 5,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(24),
                        color: '#252525',
                      }}>
                      -
                    </Text>
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(22),
                      color: '#252525',
                      textAlign: 'center',
                    }}>
                    01
                  </Text>
                  <TouchableOpacity
                    style={{
                      width: fS(30),
                      height: fS(30),
                      backgroundColor: '#FFD400',
                      borderRadius: 5,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(24),
                        color: '#252525',
                      }}>
                      +
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View>
                <Text
                  style={{
                    color: '#000',
                    fontSize: fS(16),
                    fontWeight: '400',
                    textAlign: 'justify',
                    lineHeight: 20,
                    marginBottom: '6%',
                  }}>
                  Chicken Biryani is a popular and delicious Indian dish made
                  with chicken, rice, and a blend of aromatic spices. It's known
                  for its rich and flavorful taste.
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '5%',
                }}>
                <TouchableOpacity
                  style={{
                    width: 35,
                    height: 35,
                    backgroundColor: '#FFD400',
                    borderRadius: 10,
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image
                    source={fooddelivery}
                    style={{
                      width: fS(24),
                      height: fS(23),
                      resizeMode: 'contain',
                    }}
                  />
                </TouchableOpacity>
                <View style={{marginLeft: '2%'}}>
                  <Text
                    style={{
                      color: '#000',
                      fontSize: fS(18),
                      fontWeight: '500',
                    }}>
                    Express Food Delivery
                  </Text>
                </View>
              </View>

              <View>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(23),
                    color: '#252525',
                    marginBottom: '5%',
                  }}>
                  Add ons about food
                </Text>
              </View>

              <View
                style={{
                  marginBottom: '7%',
                }}>
                <TextInput
                  multiline={true}
                  numberOfLines={5}
                  style={[
                    {
                      width: '100%',
                      borderRadius: 10,
                      textAlignVertical: 'top',
                      fontSize: 15,
                      shadowOpacity: 2,
                      shadowRadius: 3,
                      shadowOffset: {
                        height: 0,
                        width: 0,
                      },
                      backgroundColor: '#FFF',
                      elevation: 3,
                    },
                  ]}
                  placeholderTextColor="#CDCDCD"
                  placeholder="Type here"
                />
              </View>

              <View
                style={{
                  height: fS(140),
                  width: '100%',
                  backgroundColor: '#FFFDD0',
                  borderRadius: 20,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '7%',
                  padding: '4%',
                }}>
                <View
                  style={{
                    width: '90%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: '2%',
                  }}>
                  <View style={{justifyContent: 'center'}}>
                    <Text
                      style={{
                        fontWeight: '600',
                        fontSize: fS(19),
                        color: '#000',
                      }}>
                      OrderZest
                    </Text>
                    <View style={{marginTop: '2%', width: '95%'}}>
                      <Text
                        style={{
                          fontWeight: '500',
                          fontSize: fS(16),
                          color: '#000',
                          lineHeight: 20,
                        }}>
                        "Craving satisfaction at your doorstep – we deliver
                        deliciousness!"
                      </Text>
                    </View>
                  </View>
                  <View>
                    <Image
                      source={process}
                      style={{
                        width: fS(70),
                        height: fS(70),
                        resizeMode: 'contain',
                      }}
                    />
                  </View>
                </View>
              </View>
            </View>
            <View
              style={{
                width: '100%',
                marginBottom: '5%',
                backgroundColor: '#FCFBF4',
                alignItems: 'center',
              }}>
              <View style={{width: '85%'}}>
                <View style={{marginBottom: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(21),
                      color: '#000',
                    }}>
                    Ratings & Reviews
                  </Text>
                </View>
                {ratings.map((rate, index) => (
                  <View style={{marginBottom: '5%'}} key={index}>
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        marginBottom: '4%',
                      }}>
                      <View
                        style={{flexDirection: 'row', alignItems: 'center'}}>
                        <View
                          style={{
                            backgroundColor: '#FFF',
                            borderRadius: 10,
                            width: fS(50),
                            height: fS(50),
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Image
                            source={profile1}
                            style={{
                              width: fS(50),
                              height: fS(50),
                              borderRadius: 10,
                              resizeMode: 'contain',
                            }}
                          />
                        </View>

                        <View style={{marginLeft: '6%'}}>
                          <Text
                            style={{
                              fontWeight: '600',
                              fontSize: fS(18),
                              color: '#000',
                            }}>
                            {rate.name}
                          </Text>

                          <View
                            style={{
                              flexDirection: 'row',
                              alignItems: 'center',
                              marginTop: '3%',
                            }}>
                            <Icon
                              name="star"
                              color="#FFD400"
                              size={height / 50}
                            />
                            <View style={{marginLeft: 4}}>
                              <Text
                                style={{
                                  fontWeight: '500',
                                  fontSize: fS(17),
                                  color: '#252525',
                                }}>
                                {rate.rating}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                      <View>
                        <Text
                          style={{
                            fontWeight: '500',
                            fontSize: fS(17),
                            color: '#A4A4A4',
                          }}>
                          10 mon ago
                        </Text>
                      </View>
                    </View>

                    <View style={{}}>
                      <Text
                        style={{
                          fontWeight: '400',
                          fontSize: fS(16),
                          color: '#000',
                          lineHeight: 19,
                        }}>
                        One of the best chicken biryani’s in the city, with
                        every bite filled with delicious pieces of chicken that
                        melt in the mouth.
                      </Text>
                    </View>
                  </View>
                ))}
              </View>
            </View>
          </View>
        </View>
      </ScrollView>

      <View
        style={{
          height: fS(110),
          position: 'absolute',
          bottom: fS(0),
          width: '100%',
          backgroundColor: '#FFFDD0',
          borderRadius: 20,
          alignItems: 'center',
          elevation: 2,
          justifyContent: 'center',
        }}>
        <View
          style={{
            justifyContent: 'space-between',
            flexDirection: 'row',
            width: '90%',
          }}>
          <TouchableOpacity
            onPress={() => navigation.navigate('FoodCartPage')}
            style={{
              backgroundColor: '#A4A4A4',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              padding: 12,
              width: '45%',
            }}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: fS(20),
                color: '#FFF',
              }}>
              Add to cart
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => navigation.navigate('FoodDeliveryCheckOut')}
            style={{
              backgroundColor: '#FFD400',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              padding: 12,
              width: '45%',
            }}>
            <Text
              style={{
                fontWeight: '600',
                fontSize: fS(20),
                color: '#000',
              }}>
              Order now
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default FoodDeliveryDetail;
