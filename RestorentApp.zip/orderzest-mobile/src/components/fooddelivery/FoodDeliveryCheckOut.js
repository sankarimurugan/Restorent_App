import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
  Animated,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  women,
  locationicon,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Entypo from 'react-native-vector-icons/Entypo';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const FoodDeliveryCheckOut = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScrollView
        style={{
          flexGrow: 1,
          paddingTop: 30,
        }}
        contentContainerStyle={{
          height: '100%',
          justifyContent: 'space-between',
        }}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              flex: 1,
            }}>
            <View
              style={{
                width: '93%',
                flexDirection: 'row',
                alignItems: 'center',
                marginBottom: '6%',
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Image
                    source={leftarrow}
                    style={{
                      width: fS(20),
                      height: fS(20),
                      resizeMode: 'contain',
                    }}
                  />
                </TouchableOpacity>
                <View style={{marginLeft: 8}}>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(23),
                      color: '#252525',
                    }}>
                    Checkout Details
                  </Text>
                </View>
              </View>
            </View>

            <View
              style={[
                {
                  width: '93%',
                  borderRadius: 20,
                  elevation: 5,
                  backgroundColor: '#FFF',
                  padding: 9,
                  marginBottom: '5%',
                },
              ]}>
              <View
                style={{
                  width: '100%',
                }}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                  }}>
                  <View
                    style={{
                      width: '45%',
                    }}>
                    <View
                      style={{
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        source={food1}
                        style={{
                          width: '100%',
                          height: fS(150),
                          resizeMode: 'stretch',
                        }}
                      />
                    </View>
                  </View>

                  <View
                    style={{
                      width: '55%',
                    }}>
                    <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                      <Text
                        style={{
                          fontWeight: '700',
                          fontSize: fS(21),
                          color: '#252525',
                        }}>
                        Chicken Briyani
                      </Text>
                    </View>
                    <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                      <Text
                        style={{
                          fontWeight: '700',
                          fontSize: fS(16),
                          color: '#252525',
                        }}>
                        $22.50
                      </Text>
                    </View>

                    <View
                      style={{
                        width: '70%',
                        height: fS(50),
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        backgroundColor: '#FFF',
                        borderRadius: 10,
                        elevation: 5,
                        padding: 8,
                        marginTop: '4%',
                        marginHorizontal: '6%',
                      }}>
                      <TouchableOpacity
                        style={{
                          width: fS(30),
                          height: fS(30),
                          backgroundColor: '#F5F5F5',
                          borderRadius: 5,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <Text
                          style={{
                            fontWeight: '700',
                            fontSize: fS(24),
                            color: '#252525',
                          }}>
                          -
                        </Text>
                      </TouchableOpacity>
                      <Text
                        style={{
                          fontWeight: '700',
                          fontSize: fS(22),
                          color: '#252525',
                          textAlign: 'justify',
                        }}>
                        01
                      </Text>
                      <TouchableOpacity
                        style={{
                          width: fS(30),
                          height: fS(30),
                          backgroundColor: '#FFD400',
                          borderRadius: 5,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <Text
                          style={{
                            fontWeight: '700',
                            fontSize: fS(24),
                            color: '#252525',
                          }}>
                          +
                        </Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
              </View>
            </View>
            <View style={{width: '93%'}}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(23),
                  color: '#252525',
                  marginBottom: '4%',
                }}>
                Delivery Address
              </Text>
            </View>

            <View
              style={{
                width: '93%',
                borderRadius: 10,
                elevation: 3,
                backgroundColor: '#FFF',
                padding: 17,
              }}>
              <View
                style={{
                  width: '100%',
                  justifyContent: 'space-between',
                  flexDirection: 'row',
                  marginBottom: '3%',
                }}>
                <View
                  style={{
                    width: '30%',
                    backgroundColor: '#FFD400',
                    borderRadius: 8,
                    alignItems: 'center',
                    flexDirection: 'row',
                    padding: 4,
                    justifyContent: 'center',
                  }}>
                  <View>
                    <Entypo name="home" color="#000" size={height / 45} />
                  </View>
                  <View style={{marginLeft: '6%'}}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(19),
                        color: '#252525',
                      }}>
                      Home
                    </Text>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() => navigation.navigate('SavedAddress')}>
                  <FontAwesome name="edit" color="#0A7AFF" size={height / 30} />
                </TouchableOpacity>
              </View>

              <View style={{marginBottom: '2%'}}>
                <Text>
                  {' '}
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Stella Chrish{' '}
                  </Text>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(19),
                      color: '#252525',
                    }}>
                    {' '}
                    +1-212-456-7890
                  </Text>
                </Text>
              </View>
              <View
                style={{
                  fontWeight: '400',
                  fontSize: fS(19),
                  color: '#252525',
                }}>
                <Text>132, My Street, Kingston, New York 12401.</Text>
              </View>
            </View>
          </View>
        </View>
        <View
          style={{
            width: '100%',
            alignItems: 'center',
          }}>
          <View style={{width: '93%'}}>
            <View style={{marginBottom: '4%'}}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(23),
                  color: '#252525',
                }}>
                Price Details
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: fS(18),
                  color: '#000',
                }}>
                Price (1 items)
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(20),
                  color: '#252525',
                }}>
                $22.60
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: fS(18),
                  color: '#000',
                }}>
                Taxes
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(20),
                  color: '#252525',
                }}>
                $5.00
              </Text>
            </View>

            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                marginBottom: '4%',
              }}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(23),
                  color: '#000',
                }}>
                Total Amount
              </Text>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(22),
                  color: '#252525',
                }}>
                $27.60
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => navigation.navigate('BookingSuccess')}
              style={{
                width: '100%',
                padding: 12,
                backgroundColor: '#FFD400',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: '5%',
              }}>
              <Text
                style={[
                  {
                    color: '#000',
                    fontSize: 16,
                    fontWeight: '700',
                  },
                ]}>
                Checkout
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default FoodDeliveryCheckOut;

const styles = StyleSheet.create({});
