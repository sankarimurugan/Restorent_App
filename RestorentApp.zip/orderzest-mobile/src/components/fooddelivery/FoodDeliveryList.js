import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {cart, leftarrow, food1, table2} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';

const FoodDeliveryList = () => {
  const navigation = useNavigation();
  const products = [
    {
      name: ' Chicken Briyani',
      price: '$22.50',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$30',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
  ];

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScrollView>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              marginTop: '7%',
            }}>
            <View
              style={{
                width: '93%',
                flexDirection: 'row',
                alignItems: 'center',
                marginBottom: '6%',
                justifyContent: 'space-between',
              }}>
              <View style={{flexDirection: 'row', alignItems: 'center'}}>
                <TouchableOpacity onPress={() => navigation.goBack()}>
                  <Image
                    source={leftarrow}
                    style={{
                      width: fS(20),
                      height: fS(20),
                      resizeMode: 'contain',
                    }}
                  />
                </TouchableOpacity>
                <View style={{marginLeft: 8}}>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(23),
                      color: '#252525',
                    }}>
                    Wingman’s Restaurant
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                style={{
                  width: 35,
                  height: 35,
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  source={cart}
                  style={{
                    width: fS(24),
                    height: fS(23),
                    resizeMode: 'contain',
                  }}
                />
              </TouchableOpacity>
            </View>

            <View
              style={{
                width: '90%',
                alignItems: 'center',
              }}>
              <View
                style={[
                  {
                    width: '100%',
                    height: height / 16,
                    paddingHorizontal: 15,
                    borderRadius: 10,
                    shadowOpacity: 2,
                    shadowRadius: 3,
                    shadowOffset: {
                      height: 0,
                      width: 0,
                    },
                    backgroundColor: '#FFF',
                    elevation: 5,
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: '5%',
                  },
                ]}>
                <Icon name="search" color="#CDCDCD" size={height / 40} />
                <TextInput
                  placeholderTextColor="#CDCDCD"
                  placeholder="Search your food"
                  style={{
                    flex: 1,
                    marginLeft: 5,
                    fontSize: fS(17),
                  }}
                />
              </View>

              <View style={{width: '100%', marginBottom: '5%'}}>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(22),
                    color: '#252525',
                  }}>
                  Food Menus
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                  marginBottom: '25%',
                }}>
                {products.map((product, index) => (
                  <TouchableOpacity
                    onPress={() => navigation.navigate('FoodDeliveryDetail')}
                    style={{
                      backgroundColor: '#FFF',
                      elevation: 5,
                      width: '48%',
                      borderRadius: 20,
                      padding: 6,
                      marginBottom: 15,
                    }}
                    key={index}>
                    <View
                      style={{
                        width: '100%',
                        marginBottom: '5%',
                        alignItems: 'center',
                        justifyContent: 'center',
                        position: 'relative',
                      }}>
                      <Image
                        source={food1}
                        style={{
                          width: '100%',
                          height: fS(150),
                          resizeMode: 'stretch',
                        }}
                      />
                      <View
                        style={{
                          width: 27,
                          height: 20,
                          borderRadius: 5,
                          position: 'absolute',
                          top: 4,
                          right: 10,
                          backgroundColor: '#FFF',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <AntDesign
                          name="heart"
                          color="#CDCDCD"
                          size={height / 45}
                        />
                      </View>
                    </View>
                    <View style={{marginBottom: '4%'}}>
                      <Text
                        style={{
                          fontWeight: '700',
                          fontSize: fS(20),
                          color: '#252525',
                        }}>
                        Chicken Briyani
                      </Text>
                    </View>
                    <View style={{marginBottom: '4%'}}>
                      <Text
                        style={{
                          fontWeight: '600',
                          fontSize: fS(16),
                          color: '#252525',
                        }}>
                        $22.50
                      </Text>
                    </View>
                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                      <Icon name="star" color="#FFD400" size={height / 45} />
                      <View style={{marginLeft: 3}}>
                        <Text
                          style={{
                            fontWeight: '500',
                            fontSize: fS(14),
                            color: '#252525',
                          }}>
                          4.8
                        </Text>
                      </View>

                      <View style={{marginLeft: 3}}>
                        <Text
                          style={{
                            fontWeight: '500',
                            fontSize: fS(14),
                            color: '#A4A4A4',
                          }}>
                          (256 reviews)
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default FoodDeliveryList;
