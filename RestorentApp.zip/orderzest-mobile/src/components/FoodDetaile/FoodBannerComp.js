import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {
  food,
  food1,
  food2,
  food3,
  food4,
  heart,
  likebefore,
  likes,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import {C} from '../../assets/styles/ColorsFonts';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const FoodBannerComp = () => {
  const [like, setLike] = useState(true);
  return (
    <View
      style={{
        width: '100%',
        alignItems: 'center',
        position: 'relative',
        justifyContent: 'center',
        marginBottom: '5%',
      }}>
      <Image
        source={food}
        style={{
          width: '100%',
          height: fS(230),
          resizeMode: 'cover',
          borderRadius: fS(15),
        }}
      />
      <TouchableOpacity
        activeOpacity={0.7}
        onPress={() => setLike(!like)}
        style={{
          width: fS(35),
          height: fS(35),
          borderRadius: fS(10),
          position: 'absolute',
          top: fS(10),
          right: fS(10),
          backgroundColor: '#FFF',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Image
          style={[
            styles.heartimg,
            like ? {tintColor: 'red'} : {tintColor: C.LIGHT_GRAY},
          ]}
          source={likes}
        />
      </TouchableOpacity>
    </View>
  );
};

export default FoodBannerComp;

const styles = StyleSheet.create({
  heartimg: {
    height: fS(25),
    width: fS(25),
    alignSelf: 'center',
  },
});
