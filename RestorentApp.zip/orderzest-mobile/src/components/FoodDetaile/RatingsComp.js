import {Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {profile1, start} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';

const RatingsComp = ({ratings}) => {
  return (
    <View style={{width: '85%'}}>
      <View style={{marginBottom: '5%'}}>
        <Text
          style={{
            fontSize: fS(20),
            color: '#000',
            fontFamily: F.f5,
          }}>
          Ratings & Reviews
        </Text>
      </View>
      {ratings.map((rate, index) => (
        <View style={{marginBottom: '6%'}} key={index}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: '4%',
            }}>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <View
                style={{
                  backgroundColor: '#FFF',
                  width: fS(50),
                  height: fS(50),
                  alignItems: 'center',
                  justifyContent: 'center',
                  shadowColor: C.BLACK,
                  borderRadius: fS(20),
                  shadowOpacity: 1,
                  shadowRadius: fS(20),
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  elevation: 6,
                  borderRadius: fS(10),
                }}>
                <Image
                  source={profile1}
                  style={{
                    width: fS(46),
                    height: fS(46),
                    borderRadius: fS(10),
                    resizeMode: 'contain',
                  }}
                />
              </View>

              <View style={{marginLeft: '6%'}}>
                <Text
                  style={{
                    fontSize: fS(17),
                    color: '#000',
                    fontFamily: F.f4,
                  }}>
                  {rate.name}
                </Text>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: '3%',
                    gap: fS(5),
                  }}>
                  <Image
                    source={start}
                    style={{height: fS(18), width: fS(18)}}
                  />
                  <Text
                    style={{
                      fontSize: fS(15),
                      color: '#252525',
                      fontFamily: F.f4,
                    }}>
                    {rate.rating}
                  </Text>
                </View>
              </View>
            </View>
            <View>
              <Text
                style={{
                  fontSize: fS(16),
                  color: '#A4A4A4',
                  fontFamily: F.f3,
                }}>
                10 mon ago
              </Text>
            </View>
          </View>
          <View>
            <Text
              style={{
                fontSize: fS(15),
                color: '#000',
                lineHeight: 19,
                fontFamily: F.f3,
              }}>
              One of the best chicken biryani’s in the city, with every bite
              filled with delicious pieces of chicken that melt in the mouth.
            </Text>
          </View>
        </View>
      ))}
    </View>
  );
};

export default RatingsComp;

const styles = StyleSheet.create({});
