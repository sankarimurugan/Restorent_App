import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import {
  americaflag,
  cusisne1,
  cusisne2,
  food,
  food1,
  food2,
  india,
} from '../../assets/img';
import {C, F} from '../../assets/styles/ColorsFonts';
import {useNavigation} from '@react-navigation/native';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const CuisinListComp = () => {
  const navi = useNavigation();
  return (
    <View style={{marginTop: fS(10), backgroundColor: C.PRIMARY_BG}}>
      <View style={styles.imgcont}>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food1} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food1} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food1} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={cusisne2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food2} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navi.navigate('foodlist')}
          style={styles.foodcont}>
          <Image source={food1} style={styles.img} />
          <View
            style={{flexDirection: 'row', top: fS(20), position: 'absolute'}}>
            <View style={styles.sm_img_cont}>
              <Image source={americaflag} style={styles.smimg} />
            </View>
            <Text style={styles.flgtext}>American</Text>
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CuisinListComp;

const styles = StyleSheet.create({
  imgcont: {
    SCREEN_WIDTH,
    position: 'relative',
    marginTop: fS(20),
    gap: fS(10),
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  foodcont: {
    height: fS(150),
    width: '47%',
    position: 'relative',
    elevation: 5,
    backgroundColor: C.WHITE,
    borderRadius: fS(10),
    shadowRadius: fS(20),
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'cover',
    borderRadius: 10,
  },
  sm_img_cont: {
    height: fS(30),
    width: fS(50),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.WHITE,
    borderTopRightRadius: fS(5),
    borderBottomRightRadius: fS(5),
    // flexDirection: 'row',
  },
  smimg: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  flgtext: {
    fontFamily: F.f4,
    fontSize: fS(22),
    color: C.WHITE,
    marginStart: fS(5),
  },
  b_cont: {
    SCREEN_WIDTH,
    flexDirection: 'row',
    marginTop: fS(30),
    // paddingHorizontal: fS(25),
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  b_text: {
    fontFamily: F.f4,
    fontSize: fS(16),
    color: C.BLACK,
    width: '70%',
  },
  btn_cont: {
    height: 'auto',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.PRIMARY,
    paddingVertical: fS(10),
    paddingHorizontal: fS(10),
    borderRadius: fS(10),
  },
  btn_text: {
    fontFamily: F.f5,
    fontSize: fS(16),
    color: C.BLACK,
  },
});
