import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {leftarrow, schedule, table, women} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {C} from '../../assets/styles/ColorsFonts';

const TableBooking = () => {
  const navigation = useNavigation();
  const [chareBook, setChareBook] = useState([]);
  const boxes = [
    {
      id: '1',
      table: '1',
      chare1: 1,
      chare2: 2,
      chare3: 3,
      chare4: 4,
    },
    {
      id: '2',
      table: '2',
      chare5: 5,
      chare6: 6,
      chare7: 7,
      chare8: 8,
    },
    {
      id: '3',
      table: '3',
      chare9: 9,
      chare10: 10,
      chare11: 11,
      chare12: 12,
    },
    {
      id: '4',
      table: '4',
      chare13: 13,
      chare14: 14,
      chare15: 15,
      chare16: 16,
    },
    {
      id: '5',
      table: '6',
      chare17: 17,
      chare18: 18,
      chare19: 19,
      chare20: 20,
    },
    {
      id: '6',
      table: '7',
      chare22: 22,
      chare21: 21,
      chare23: 23,
      chare24: 24,
    },
  ];

  const charesFun = id => {
    let temp = [...chareBook];
    console.log('TEMP', temp, 'id', id);
    let val = temp.indexOf(id);
    if (temp.includes(id)) {
      temp.splice(val, 1);
    } else {
      temp.push(id);
    }
    setChareBook(temp);
    console.log('bottom temp', temp);
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp headername={'Wingman’s Restaurant'} />
      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={styles.topcont}>
          <View style={styles.boxcont}>
            <View style={styles.boxlayer}>
              <View style={styles.layer1}>
                <View
                  style={{
                    width: '50%',
                  }}>
                  <View>
                    <Text
                      style={{
                        fontWeight: '500',
                        fontSize: fS(16),
                        color: '#252525',
                      }}>
                      Date 7th Oct, 2023
                    </Text>
                    <View style={{marginTop: '8%'}}>
                      <Text
                        style={{
                          fontWeight: '500',
                          fontSize: fS(16),
                          color: '#252525',
                        }}>
                        Time 11:30 AM - 12:30 PM
                      </Text>
                    </View>
                  </View>
                </View>
                <View style={styles.line} />
                <View
                  style={{
                    width: '45%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    position: 'relative',
                  }}>
                  <View style={{alignItems: 'center'}}>
                    <Text
                      style={{
                        fontWeight: '900',
                        fontSize: fS(30),
                        color: '#00C408',
                      }}>
                      04
                    </Text>
                    <View style={{marginTop: '5%', alignItems: 'center'}}>
                      <Text
                        style={{
                          fontWeight: '600',
                          fontSize: fS(19),
                          color: '#252525',
                        }}>
                        Members
                      </Text>
                    </View>
                  </View>
                  <View
                    style={{
                      position: 'absolute',
                      bottom: 0,
                      right: 0,
                      top: 0,
                      alignItems: 'center',
                    }}>
                    <Image
                      source={women}
                      style={{
                        width: fS(100),
                        height: fS(100),
                        resizeMode: 'contain',
                      }}
                    />
                  </View>
                </View>
              </View>
            </View>
          </View>

          <View
            style={{
              width: '90%',
              alignItems: 'center',
              marginBottom: '7%',
            }}>
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  alignContent: 'center',
                  justifyContent: 'center',
                }}>
                <TouchableOpacity
                  style={{
                    width: 22,
                    height: 22,
                    borderWidth: 2,
                    borderColor: '#FFD400',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: 5,
                  }}
                />
                <View style={{marginLeft: 7}}>
                  <Text
                    style={{
                      fontWeight: '500',
                      fontSize: fS(18),
                      color: '#252525',
                    }}>
                    Available
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignContent: 'center',
                  justifyContent: 'center',
                }}>
                <TouchableOpacity
                  style={{
                    width: 22,
                    height: 22,
                    backgroundColor: '#D9D9D9',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: 5,
                  }}
                />
                <View style={{marginLeft: 7}}>
                  <Text
                    style={{
                      fontWeight: '500',
                      fontSize: fS(18),
                      color: '#252525',
                    }}>
                    Booked
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignContent: 'center',
                  justifyContent: 'center',
                }}>
                <TouchableOpacity
                  style={{
                    width: 22,
                    height: 22,
                    backgroundColor: '#00C408',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: 5,
                  }}
                />
                <View style={{marginLeft: 7}}>
                  <Text
                    style={{
                      fontWeight: '500',
                      fontSize: fS(18),
                      color: '#252525',
                    }}>
                    Selected
                  </Text>
                </View>
              </View>
            </View>
          </View>
          <View
            style={{
              width: '80%',
              flexDirection: 'row',
              flexWrap: 'wrap',
              justifyContent: 'space-between',
            }}>
            {boxes.map((box, index) => (
              <View style={{width: '44%', marginBottom: '15%'}} key={index}>
                <View style={{width: '100%'}}>
                  <View
                    style={{
                      flexDirection: 'row',
                      marginBottom: '5%',
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                    }}>
                    <TouchableOpacity
                      activeOpacity={1}
                      style={[
                        {
                          width: 21,
                          height: 21,
                          borderWidth: 2,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: 5,
                          backgroundColor: '#D9D9D9',
                          borderColor: '#D9D9D9',
                          borderColor: '#D9D9D9',
                        },
                      ]}
                      onPress={() => charesFun(1)}
                    />
                    <TouchableOpacity
                      style={[
                        {
                          width: 21,
                          height: 21,
                          borderWidth: 2,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: 5,
                        },
                        chareBook.includes(2)
                          ? {
                              backgroundColor: '#00C408',
                              borderColor: '#00C408',
                            }
                          : {borderColor: '#FFD400'},
                      ]}
                      onPress={() => charesFun(2)}
                    />
                  </View>
                  <View style={{marginBottom: '7%', alignItems: 'center'}}>
                    <TouchableOpacity
                      style={{
                        width: 110,
                        height: 100,
                        backgroundColor: '#FEE77A',
                        alignItems: 'center',
                        justifyContent: 'center',
                        borderRadius: 20,
                      }}>
                      <View
                        style={{
                          backgroundColor: '#FFF',
                          borderRadius: 15,
                          width: 25,
                          height: 25,
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <Text
                          style={{
                            fontWeight: '500',
                            fontSize: fS(16),
                            color: '#252525',
                          }}>
                          {box.table}
                        </Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-evenly',
                    }}>
                    <TouchableOpacity
                      style={[
                        {
                          width: 21,
                          height: 21,
                          borderWidth: 2,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: 5,
                        },
                        chareBook.includes(3)
                          ? {
                              backgroundColor: '#00C408',
                              borderColor: '#00C408',
                            }
                          : {borderColor: '#FFD400'},
                      ]}
                      onPress={() => charesFun(3)}
                    />
                    <TouchableOpacity
                      style={[
                        {
                          width: 21,
                          height: 21,
                          borderWidth: 2,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: 5,
                        },
                        chareBook.includes(4)
                          ? {
                              backgroundColor: '#00C408',
                              borderColor: '#00C408',
                            }
                          : {borderColor: '#FFD400'},
                      ]}
                      onPress={() => charesFun(4)}
                    />
                  </View>
                </View>
              </View>
            ))}
          </View>
        </View>
        <View
          style={{
            width: '100%',
            position: 'absolute',
            bottom: 15,
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '93%',
              backgroundColor: '#FFF',
              borderRadius: 20,
              padding: 15,
              elevation: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
            }}>
            <View style={{marginLeft: '2%'}}>
              <Text
                style={{
                  fontWeight: '600',
                  fontSize: fS(17),
                  color: '#252525',
                }}>
                Seat selection confirmed.
              </Text>
              <View style={{marginTop: '3%'}}>
                <Text
                  style={{
                    fontWeight: '500',
                    fontSize: fS(16),
                    color: '#A4A4A4',
                  }}>
                  4 Seats
                </Text>
              </View>
            </View>

            <TouchableOpacity
              onPress={() => navigation.navigate('TableBookingDetails')}
              style={{
                backgroundColor: '#FFD400',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'row',
                padding: 10,
                width: '43%',
              }}>
              <Text
                style={{
                  fontWeight: '700',
                  fontSize: fS(20),
                  color: '#000',
                }}>
                Proceed
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default TableBooking;

const styles = StyleSheet.create({
  topcont: {
    width: '100%',
    alignItems: 'center',
    marginTop: '3%',
    marginBottom: '20%',
  },
  boxcont: {
    width: '93%',
    height: fS(130),
    alignItems: 'center',
    borderRadius: 20,
    marginBottom: '10%',
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 5,
    backgroundColor: '#FFF',
  },
  boxlayer: {
    width: '100%',
    alignItems: 'center',
    marginTop: '7%',
  },
  line: {
    height: '100%',
    width: '0.5%',
    borderColor: '#DADADA',
    backgroundColor: '#DADADA',
    borderWidth: 1,
  },
  layer1: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: fS(20),
  },
});
