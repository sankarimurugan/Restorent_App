import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  start,
  pascel,
  food_delivery,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import FoodBannerComp from '../FoodDetaile/FoodBannerComp';
import {C, F} from '../../assets/styles/ColorsFonts';
import RatingsComp from '../FoodDetaile/RatingsComp';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');

const FoodDetailPage = () => {
  const navigation = useNavigation();
  const location = useRoute();
  console.log(location?.params?.type2);
  const type3 = location?.params?.type2;
  const view = location?.params?.view;
  console.log(view);
  console.log('type3', type3);
  const ratings = [
    {
      name: 'Charles Kuanda',
      rating: '4.8',
    },

    {
      name: ' Gunaseelan',
      rating: '3.8',
    },
    {
      name: ' Guna',
      rating: '3.8',
    },
  ];

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp
        status={type3}
        type={view != 'detaile' && 1}
        headername={view == 'detaile' ? 'Biriyani' : 'Wingman’s Restaurant'}
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={
          view != 'detaile' ? {paddingBottom: fS(100)} : {paddingBottom: fS(10)}
        }>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              marginTop: '7%',
            }}>
            <View
              style={{
                width: '90%',
              }}>
              <FoodBannerComp />
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '3%',
                }}>
                <Text
                  style={{
                    fontSize: fS(23),
                    color: '#252525',
                    fontFamily: F.f5,
                  }}>
                  Chicken Briyani
                </Text>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Image
                    source={start}
                    style={{height: fS(20), width: fS(20)}}
                  />
                  <View style={{marginLeft: 4}}>
                    <Text
                      style={{
                        fontSize: fS(17),
                        color: '#252525',
                        fontFamily: F.f4,
                      }}>
                      4.8
                    </Text>
                  </View>
                </View>
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '4%',
                }}>
                <Image
                  source={india}
                  style={{
                    width: fS(25),
                    height: fS(22),
                    resizeMode: 'contain',
                  }}
                />

                <View style={{marginLeft: 7}}>
                  <Text
                    style={{
                      color: '#A4A4A4',
                      fontSize: fS(16),
                      fontFamily: F.f3,
                    }}>
                    Indian
                  </Text>
                </View>
              </View>

              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '6%',
                  alignItems: 'center',
                }}>
                <Text
                  style={{
                    fontSize: fS(22),
                    color: '#252525',
                    fontFamily: F.f5,
                  }}>
                  $22.50
                </Text>

                {view != 'detaile' && (
                  <View
                    style={{
                      width: '33%',
                      height: fS(50),
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                      alignItems: 'center',
                      backgroundColor: '#FFF',
                      borderRadius: 10,
                      elevation: 5,
                      padding: 8,
                    }}>
                    <TouchableOpacity
                      style={{
                        width: fS(30),
                        height: fS(30),
                        backgroundColor: '#F5F5F5',
                        borderRadius: 5,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: F.f5,
                          fontSize: fS(20),
                          color: '#252525',
                          textAlign: 'center',
                        }}>
                        -
                      </Text>
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontFamily: F.f4,
                        fontSize: fS(22),
                        color: '#252525',
                      }}>
                      01
                    </Text>
                    <TouchableOpacity
                      style={{
                        width: fS(30),
                        height: fS(30),
                        backgroundColor: '#FFD400',
                        borderRadius: 5,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Text
                        style={{
                          fontFamily: F.f5,
                          fontSize: fS(20),
                          color: '#252525',
                          textAlign: 'center',
                        }}>
                        +
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>

              <View>
                <Text
                  style={{
                    color: '#000',
                    fontSize: fS(15),
                    lineHeight: 20,
                    marginBottom: '6%',
                    fontFamily: F.f3,
                  }}>
                  Chicken Biryani is a popular and delicious Indian dish made
                  with chicken, rice, and a blend of aromatic spices. It's known
                  for its rich and flavorful taste.
                </Text>
              </View>

              {type3 == 'delivery' && view != 'detaile' && (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: '5%',
                  }}>
                  <TouchableOpacity
                    style={{
                      width: fS(35),
                      height: fS(35),
                      backgroundColor: '#FFD400',
                      borderRadius: 10,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Image
                      source={food_delivery}
                      style={{
                        width: fS(24),
                        height: fS(23),
                        resizeMode: 'contain',
                        alignSelf: 'center',
                      }}
                    />
                  </TouchableOpacity>
                  <View style={{marginLeft: '2%'}}>
                    <Text
                      style={{
                        color: '#000',
                        fontSize: fS(18),
                        fontFamily: F.f3,
                      }}>
                      Express Food Delivery
                    </Text>
                  </View>
                </View>
              )}

              {type3 != 'delivery' && view != 'detaile' && (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginBottom: '5%',
                  }}>
                  <TouchableOpacity
                    style={{
                      width: fS(35),
                      height: fS(35),
                      backgroundColor: '#FFD400',
                      borderRadius: 10,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Image
                      source={cooking}
                      style={{
                        width: fS(24),
                        height: fS(23),
                        resizeMode: 'contain',
                        alignSelf: 'center',
                      }}
                    />
                  </TouchableOpacity>
                  <View style={{marginLeft: '2%'}}>
                    <Text
                      style={{
                        color: '#000',
                        fontSize: fS(18),
                        fontFamily: F.f3,
                      }}>
                      10 mins to serve
                    </Text>
                  </View>
                </View>
              )}

              {view != 'detaile' && (
                <View>
                  <Text
                    style={{
                      fontSize: fS(20),
                      color: '#252525',
                      marginBottom: '5%',
                      fontFamily: F.f5,
                    }}>
                    Add ons about food
                  </Text>
                </View>
              )}

              {view != 'detaile' && (
                <View
                  style={{
                    marginBottom: '7%',
                  }}>
                  <TextInput
                    multiline={true}
                    numberOfLines={5}
                    style={[
                      {
                        width: '100%',
                        borderRadius: 10,
                        textAlignVertical: 'top',
                        shadowOpacity: 2,
                        shadowRadius: 3,
                        shadowOffset: {
                          height: 0,
                          width: 0,
                        },
                        backgroundColor: '#FFF',
                        elevation: 3,
                        fontFamily: F.f3,
                        fontSize: fS(17),
                        color: C.BLACK,
                        paddingHorizontal: fS(15),
                        paddingVertical: fS(15),
                      },
                    ]}
                    placeholderTextColor="#CDCDCD"
                    placeholder="Type here"
                  />
                </View>
              )}

              {type3 != 'delivery' && view != 'detaile' && (
                <View
                  style={{
                    height: fS(140),
                    width: '100%',
                    backgroundColor: '#FFFDD0',
                    borderRadius: 20,
                    alignItems: 'center',

                    marginBottom: '7%',
                  }}>
                  <View
                    style={{
                      width: '90%',
                      flexDirection: 'row',
                      alignItems: 'center',
                      marginTop: '2%',
                      marginBottom: '2%',
                      gap: fS(6),
                    }}>
                    <Image
                      source={table2}
                      style={{
                        width: fS(45),
                        height: fS(40),
                        resizeMode: 'contain',
                      }}
                    />
                    <Text
                      style={{
                        fontSize: fS(17),
                        color: '#252525',
                        fontFamily: F.f5,
                      }}>
                      Reserved Table No : 03
                    </Text>
                  </View>

                  <TouchableOpacity
                    style={{
                      width: '90%',
                      flexDirection: 'row',
                      alignItems: 'center',
                      backgroundColor: '#0257DC',
                      borderRadius: 20,
                      justifyContent: 'center',
                      padding: 9,
                    }}>
                    <Text
                      style={{
                        fontSize: fS(13),
                        color: '#FFF',
                        fontFamily: F.f3,
                        textAlign: 'center',
                      }}>
                      Reservation Date & Time : 7th Oct - 11:30 AM - 12:30 PM{' '}
                    </Text>
                  </TouchableOpacity>
                </View>
              )}
              {type3 == 'delivery' && (
                <View
                  style={{
                    width: '100%',
                    backgroundColor: '#FFFDD0',
                    borderRadius: fS(20),
                    alignItems: 'center',
                    marginBottom: '7%',
                    paddingVertical: fS(20),
                    paddingHorizontal: fS(20),
                  }}>
                  <View
                    style={{
                      width: '100%',
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginTop: '2%',
                      position: 'relative',
                    }}>
                    <View style={{paddingEnd: '20%'}}>
                      <Text
                        style={{
                          fontSize: fS(17),
                          color: '#252525',
                          fontFamily: F.f5,
                        }}>
                        OrderZest
                      </Text>
                      <Text
                        style={{
                          fontSize: fS(15),
                          color: C.BLACK,
                          fontFamily: F.f4,
                          textAlign: 'left',
                          lineHeight: fS(30),
                          marginTop: fS(10),
                        }}>
                        "Craving satisfaction at your doorstep – we deliver
                        deliciousness!"{' '}
                      </Text>
                    </View>
                    <Image
                      source={pascel}
                      style={{
                        height: fS(70),
                        width: fS(70),
                        objectFit: 'contain',
                        position: 'absolute',
                        right: 0,
                      }}
                    />
                  </View>
                </View>
              )}
            </View>
            <View
              style={{
                width: '100%',
                marginBottom: '5%',
                backgroundColor: '#FCFBF4',
                alignItems: 'center',
              }}>
              <RatingsComp ratings={ratings} />
            </View>
          </View>
        </View>
      </ScrollView>

      {view != 'detaile' && (
        <View
          style={{
            height: fS(110),
            position: 'absolute',
            bottom: fS(0),
            width: '100%',
            backgroundColor: '#FFFDD0',
            borderTopRightRadius: fS(20),
            borderTopLeftRadius: fS(20),
            alignItems: 'center',
            elevation: 2,
            justifyContent: 'center',
          }}>
          <View
            style={{
              justifyContent: 'space-between',
              flexDirection: 'row',
              width: '90%',
            }}>
            <TouchableOpacity
              // onPress={() => navigation.navigate('CartPage')}
              onPress={() => navigation.goBack()}
              style={{
                backgroundColor: '#A4A4A4',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'row',
                padding: 12,
                width: '45%',
              }}>
              <Text
                style={{
                  fontSize: fS(20),
                  color: '#FFF',
                  fontFamily: F.f5,
                }}>
                Add to cart
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() =>
                navigation.navigate('FoodCheckOut', {type3: type3})
              }
              style={{
                backgroundColor: '#FFD400',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
                flexDirection: 'row',
                padding: 12,
                width: '45%',
              }}>
              <Text
                style={{
                  fontFamily: F.f5,
                  fontSize: fS(20),
                  color: '#000',
                }}>
                Order now
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
};

export default FoodDetailPage;
