import {
  Dimensions,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const CheckinOutComp = () => {
  // Time picker start
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [checkInHour, setCheckInHour] = useState('');
  const [checkInMinute, setCheckInMinute] = useState('');
  const [checkOutHour, setCheckOutHour] = useState('');
  const [checkOutMinute, setCheckOutMinute] = useState('');

  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  const handleConfirm = time => {
    const hour = moment(time).format('HH');
    const minute = moment(time).format('mm');
    // You can differentiate between check-in and check-out here based on your logic
    // For now, I assume you set the same time for both
    setCheckInHour(hour);
    setCheckInMinute(minute);
    setCheckOutHour(hour);
    setCheckOutMinute(minute);
    hideDatePicker();
  };
  // Time picker end

  return (
    <View style={styles.cont}>
      <View style={styles.btnmaincont}>
        <View style={styles.topbtncont}>
          <View style={styles.rowcont}>
            <Text style={styles.checktext}>Check In</Text>
            <TouchableOpacity
              disableFullscreenUI={true}
              style={styles.in_box}
              // placeholder="12:00 PM"
              onPress={showDatePicker}
              editable={false}>
              <Text style={styles.placshold}>{checkOutHour}</Text>
              <Text style={styles.placshold}> : </Text>
              <Text style={styles.placshold}>{checkOutMinute}</Text>
              <Text style={styles.placshold}> AM</Text>
            </TouchableOpacity>
          </View>
          <View>
            <Text style={styles.checktext}>Check Out</Text>
            <TouchableOpacity
              disableFullscreenUI={true}
              style={styles.in_box}
              // placeholder="12:00 PM"
              onPress={showDatePicker}
              editable={false}>
              <Text style={styles.placshold}>{checkOutHour}</Text>
              <Text style={styles.placshold}> : </Text>
              <Text style={styles.placshold}>{checkOutMinute}</Text>
              <Text style={styles.placshold}> AM</Text>
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.btextcont}>
          <Text style={styles.btext}>
            To reserve a table, kindly provide the check-in and check-out time.
            Thank you.
          </Text>
        </View>
      </View>
      <View style={{flexDirection: 'row', width: '40%'}}>
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="time"
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        />
      </View>

      <View style={{flexDirection: 'row', width: '40%'}}>
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="time"
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        />
      </View>
    </View>
  );
};

export default CheckinOutComp;

const styles = StyleSheet.create({
  cont: {
    width: SCREEN_WIDTH,
    paddingHorizontal: fS(25),
  },
  btnmaincont: {
    height: 'auto',
    width: '100%',
    shadowOpacity: 1,
    shadowRadius: fS(20),
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 6,
    backgroundColor: C.WHITE,
    paddingVertical: fS(20),
    // paddingHorizontal: fS(10),
    marginVertical: fS(10),
    borderRadius: fS(20),
    justifyContent: 'space-between',
    paddingHorizontal: fS(10),
  },
  topbtncont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: fS(10),
  },
  in_box: {
    borderRadius: fS(15),
    marginTop: fS(10),
    shadowOpacity: 2,
    shadowRadius: 3,
    borderColor: C.BLACK,
    borderWidth: fS(2),
    backgroundColor: C.WHITE,
    paddingHorizontal: fS(10),
    width: SCREEN_WIDTH / 2.6,
    // height: fS(55),
    paddingStart: fS(20),
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'center',
    paddingVertical: fS(10),
  },
  placshold: {
    fontSize: fS(17),
    fontFamily: F.f4,
    color: '#CDCDCD',
  },
  rowcont: {},
  checktext: {
    fontFamily: F.f4,
    color: C.BLACK,
    fontSize: fS(18),
    paddingHorizontal: fS(5),
  },
  btextcont: {
    paddingHorizontal: fS(10),
    marginTop: fS(15),
  },
  btext: {
    fontFamily: F.f2,
    color: C.BLACK,
    fontSize: fS(15),
    lineHeight: fS(25),
  },
});
