import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {leftarrow, schedule, table, women} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {F} from '../../assets/styles/ColorsFonts';

const TableBookingDetails = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp headername={'Wingman’s Restaurant'} />
      <ScrollView>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              marginTop: '7%',
            }}>
            <View
              style={[
                {
                  width: '93%',
                  alignItems: 'center',
                  borderRadius: 20,
                  marginBottom: '6%',
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  elevation: 5,
                  backgroundColor: '#FFF',
                  padding: 7,
                },
              ]}>
              <View
                style={{
                  width: '100%',
                  alignItems: 'center',
                  marginTop: '7%',
                }}>
                <View
                  style={{
                    width: '95%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginBottom: '2%',
                    flexWrap: 'nowrap',
                  }}>
                  <View
                    style={{
                      width: '50%',
                    }}>
                    <View>
                      <Text
                        style={{
                          fontFamily: F.f4,
                          fontSize: fS(15),
                          color: '#252525',
                        }}>
                        Date 7th Oct, 2023
                      </Text>
                      <View
                        style={{
                          marginTop: '8%',
                        }}>
                        <Text
                          style={{
                            fontFamily: F.f4,
                            fontSize: fS(15),
                            color: '#252525',
                          }}>
                          Time 11:30 AM - 12:30 PM
                        </Text>
                      </View>

                      <View style={{marginTop: '8%'}}>
                        <Text
                          style={{
                            fontFamily: F.f4,
                            fontSize: fS(15),
                            color: '#252525',
                          }}>
                          Table no : 3
                        </Text>
                      </View>
                    </View>
                  </View>
                  <View
                    style={{
                      height: '100%',
                      width: '0.5%',
                      borderColor: '#DADADA',
                      backgroundColor: '#DADADA',
                      borderWidth: 1,
                    }}></View>
                  <View
                    style={{
                      width: '45%',
                      flexDirection: 'row',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      position: 'relative',
                    }}>
                    <View style={{alignItems: 'center'}}>
                      <Text
                        style={{
                          fontWeight: '900',
                          fontSize: fS(30),
                          color: '#00C408',
                        }}>
                        04
                      </Text>
                      <View style={{marginTop: '5%', alignItems: 'center'}}>
                        <Text
                          style={{
                            fontWeight: '600',
                            fontSize: fS(19),
                            color: '#252525',
                          }}>
                          Members
                        </Text>
                      </View>
                    </View>
                    <View
                      style={{
                        position: 'absolute',
                        bottom: 0,
                        right: 0,
                        top: 0,
                        alignItems: 'center',
                      }}>
                      <Image
                        source={women}
                        style={{
                          width: fS(100),
                          height: fS(100),
                          resizeMode: 'contain',
                        }}
                      />
                    </View>
                  </View>
                </View>
              </View>
            </View>

            <View
              style={{
                width: '90%',
                alignItems: 'center',
                marginBottom: '10%',
              }}>
              <Text
                style={{
                  fontSize: fS(17),
                  fontFamily: F.f3,
                  color: '#252525',
                  lineHeight: fS(30),
                }}>
                It looks like you've chosen your table. Would you like to place
                your food order at this time?
              </Text>
            </View>

            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',
                width: '90%',
              }}>
              <TouchableOpacity
                onPress={() => navigation.navigate('home')}
                style={{
                  backgroundColor: '#A4A4A4',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  padding: 12,
                  width: '45%',
                }}>
                <Text
                  style={{
                    fontSize: fS(19),
                    fontFamily: F.f4,
                    color: '#FFF',
                  }}>
                  Order Later
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => navigation.navigate('FoodOrderList')}
                style={{
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  padding: 12,
                  width: '45%',
                }}>
                <Text
                  style={{
                    fontSize: fS(19),
                    fontFamily: F.f4,
                    color: '#000',
                  }}>
                  Order now
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default TableBookingDetails;
