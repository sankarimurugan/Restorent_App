import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState, useMemo} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {
  leftarrow,
  location,
  locationicon,
  schedule,
  spoon,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import {Calendar} from 'react-native-calendars';
import {C} from '../../assets/styles/ColorsFonts';
const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');
function CustomCalendar(props) {
  const initDate = '2023-10-25';
  const [selected, setSelected] = useState(initDate);
  const marked = useMemo(
    () => ({
      [selected]: {
        selected: true,
        selectedColor: '#FFD400',
        selectedTextColor: '#000',
      },
    }),
    [selected],
  );
  return (
    <Calendar
      style={{width: SCREEN_WIDTH}}
      initialDate={initDate}
      markedDates={marked}
      onDayPress={day => {
        setSelected(day.dateString);
        props.onDaySelect && props.onDaySelect(day);
      }}
      {...props}
    />
  );
}

const TableDateTime = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: C.PRIMARY_BG,

        SCREEN_WIDTH,
      }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{paddingHorizontal: fS(25)}}>
        <View
          style={{
            width: SCREEN_WIDTH,
            flex: 1,
          }}>
          <View
            style={{
              width: SCREEN_WIDTH,
              alignItems: 'center',
              marginTop: '7%',
            }}>
            <View
              style={{
                width: SCREEN_WIDTH,
                flexDirection: 'row',
                alignItems: 'center',
                marginBottom: '5%',
              }}>
              <TouchableOpacity onPress={() => navigation.goBack()}>
                <Image
                  source={leftarrow}
                  style={{
                    width: fS(20),
                    height: fS(20),
                    resizeMode: 'contain',
                  }}
                />
              </TouchableOpacity>
              <View style={{marginLeft: 8}}>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(23),
                    color: '#252525',
                  }}>
                  Wingman’s Restaurant
                </Text>
              </View>
            </View>

            <View
              style={{
                alignItems: 'center',
                flexDirection: 'row',
                width: SCREEN_WIDTH,
                marginBottom: '8%',
              }}>
              <View>
                <Image
                  source={schedule}
                  style={{
                    width: fS(24),
                    height: fS(24),
                    resizeMode: 'contain',
                  }}
                />
              </View>
              <View style={{marginLeft: 7}}>
                <Text
                  style={{
                    fontWeight: '500',
                    fontSize: fS(20),
                    color: '#252525',
                  }}>
                  Choose Reservation Date & Time
                </Text>
              </View>
            </View>

            <View
              style={{
                width: SCREEN_WIDTH,
                borderRadius: fS(100),
                elevation: 5,
                shadowColor: C.BLACK,
                borderRadius: fS(20),
                shadowOpacity: 1,
                shadowRadius: fS(20),
                shadowOffset: {
                  height: 0,
                  width: 0,
                },
                elevation: 6,
                marginVertical: fS(20),
              }}>
              <CustomCalendar />
            </View>

            <View
              style={[
                {
                  width: '93%',
                  paddingBottom: 15,
                  alignItems: 'center',
                  borderRadius: 20,
                  marginBottom: '8%',
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  elevation: 5,
                  backgroundColor: '#FFF',
                },
              ]}>
              <View
                style={{
                  width: '100%',
                  alignItems: 'center',
                  marginTop: '5%',
                }}>
                <View
                  style={{
                    width: '90%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginBottom: '2%',
                  }}>
                  <View
                    style={{
                      width: '45%',
                    }}>
                    <View>
                      <Text
                        style={{
                          fontWeight: '500',
                          fontSize: fS(20),
                          color: '#252525',
                        }}>
                        Check In
                      </Text>
                    </View>
                    <View>
                      <TextInput
                        style={[
                          {
                            height: height / 20,
                            paddingHorizontal: 15,
                            borderRadius: 12,
                            fontSize: fS(17),
                            marginTop: 10,
                            shadowOpacity: 2,
                            shadowRadius: 3,
                            borderColor: '#000',
                            borderWidth: 1,
                            backgroundColor: '#FFF',
                          },
                        ]}
                        placeholderTextColor="#CDCDCD"
                        placeholder="12.00 AM"
                        keyboardType="numeric"
                      />
                    </View>
                  </View>

                  <View
                    style={{
                      width: '45%',
                    }}>
                    <View>
                      <Text
                        style={{
                          fontWeight: '500',
                          fontSize: fS(20),
                          color: '#252525',
                        }}>
                        Check Out
                      </Text>
                    </View>
                    <View>
                      <TextInput
                        style={[
                          {
                            height: height / 20,
                            paddingHorizontal: 15,
                            borderRadius: 12,
                            fontSize: fS(17),
                            marginTop: 10,
                            shadowOpacity: 2,
                            shadowRadius: 3,
                            borderColor: '#000',
                            borderWidth: 1,
                            backgroundColor: '#FFF',
                          },
                        ]}
                        placeholderTextColor="#CDCDCD"
                        placeholder="1.00PM"
                        keyboardType="numeric"
                      />
                    </View>
                  </View>
                </View>
                <View style={{width: '90%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(16),
                      color: '#252525',
                      textAlign: 'justify',
                      lineHeight: 15,
                    }}>
                    To reserve a table, kindly provide the check-in and
                    check-out time. Thank you.
                  </Text>
                </View>
              </View>
            </View>

            <View
              style={{
                alignItems: 'center',
                flexDirection: 'row',
                width: '93%',
                marginBottom: '4%',
              }}>
              <View>
                <Image
                  source={schedule}
                  style={{
                    width: fS(24),
                    height: fS(24),
                    resizeMode: 'contain',
                  }}
                />
              </View>
              <View style={{marginLeft: 7}}>
                <Text
                  style={{
                    fontWeight: '500',
                    fontSize: fS(21),
                    color: '#252525',
                  }}>
                  Members
                </Text>
              </View>
            </View>

            <View
              style={[
                {
                  width: '93%',
                  height: fS(80),
                  alignItems: 'center',
                  borderRadius: 20,
                  marginBottom: '8%',
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  elevation: 5,
                  backgroundColor: '#FFF',
                },
              ]}>
              <View
                style={{
                  width: '100%',
                  alignItems: 'center',
                  marginTop: '5%',
                }}>
                <View
                  style={{
                    width: '90%',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                  }}>
                  <TouchableOpacity
                    style={{
                      width: fS(50),
                      height: fS(50),
                      backgroundColor: '#F5F5F5',
                      borderRadius: 10,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(24),
                        color: '#252525',
                      }}>
                      -
                    </Text>
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontWeight: '700',
                      fontSize: fS(22),
                      color: '#252525',
                      textAlign: 'justify',
                    }}>
                    4 Guests
                  </Text>
                  <TouchableOpacity
                    style={{
                      width: fS(50),
                      height: fS(50),
                      backgroundColor: '#FFD400',
                      borderRadius: 10,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        fontWeight: '700',
                        fontSize: fS(25),
                        color: '#252525',
                      }}>
                      +
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>

            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',
                width: '93%',
                marginBottom: '5%',
              }}>
              <TouchableOpacity
                onPress={() => navigation.goBack()}
                style={{
                  backgroundColor: '#A4A4A4',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  padding: 12,
                  width: '45%',
                }}>
                <Text
                  style={{
                    fontWeight: '600',
                    fontSize: fS(21),
                    color: '#FFF',
                  }}>
                  Cancel
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => navigation.navigate('TableBooking')}
                style={{
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexDirection: 'row',
                  padding: 12,
                  width: '45%',
                }}>
                <Text
                  style={{
                    fontWeight: '600',
                    fontSize: fS(21),
                    color: '#000',
                  }}>
                  Confirm
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default TableDateTime;
