import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {phonehand} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {F} from '../../assets/styles/ColorsFonts';

const BookingSuccess = () => {
  const navi = useNavigation();

  useEffect(() => {
    setTimeout(() => {
      navi.navigate('home');
    }, 2000);
  }, []);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <View
        style={{
          flex: 1,
          height: '100%',
        }}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View>
            <Image
              source={phonehand}
              style={{
                width: fS(200),
                height: fS(180),
                resizeMode: 'contain',
              }}
            />
          </View>

          <View style={{marginBottom: '2%'}}>
            <Text
              style={{
                fontSize: fS(22),
                color: '#252525',
                fontFamily: F.f5,
              }}>
              Reservation Success
            </Text>
          </View>
          <View style={{alignItems: 'center', width: '80%'}}>
            <Text
              style={{
                fontSize: fS(15),
                color: '#000',
                lineHeight: fS(27),
                textAlign: 'center',
                fontFamily: F.f3,
              }}>
              Congratulations, your table reservation has been confirmed, and
              with your favourite food
            </Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default BookingSuccess;
