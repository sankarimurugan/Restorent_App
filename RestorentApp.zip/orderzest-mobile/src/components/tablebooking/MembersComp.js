import {
  Dimensions,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');

const MembersComp = () => {
  const [guestAdd, setGuestAdd] = useState(4);

  const addGuest = () => {
    setGuestAdd(guestAdd + 1);
  };
  const canGuest = () => {
    if (guestAdd > 1) {
      setGuestAdd(guestAdd - 1);
    } else {
      setGuestAdd(1);
    }
  };

  return (
    <View style={styles.btnmaincont}>
      <TouchableOpacity style={styles.boxcont} onPress={canGuest}>
        <Text style={styles.simbl}>-</Text>
      </TouchableOpacity>
      <Text style={styles.midtext}>{guestAdd} Guests</Text>
      <TouchableOpacity style={styles.boxcont2} onPress={addGuest}>
        <Text style={styles.simbl}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

export default MembersComp;

const styles = StyleSheet.create({
  btnmaincont: {
    height: 'auto',
    width: '100%',
    shadowOpacity: 1,
    shadowRadius: fS(20),
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 6,
    backgroundColor: C.WHITE,
    paddingVertical: fS(20),
    marginVertical: fS(10),
    borderRadius: fS(20),
    justifyContent: 'space-between',
    paddingHorizontal: fS(20),
    flexDirection: 'row',
  },
  boxcont: {
    height: fS(40),
    width: fS(40),
    backgroundColor: C.LT_BOX_GRY,
    borderRadius: fS(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  boxcont2: {
    height: fS(40),
    width: fS(40),
    backgroundColor: C.PRIMARY,
    borderRadius: fS(10),
    alignItems: 'center',
    justifyContent: 'center',
  },
  simbl: {
    fontFamily: F.f3,
    fontSize: fS(25),
    color: C.BLACK,
    textAlignVertical: 'center',
    lineHeight: fS(30),
    textAlign: 'center',
  },
  midtext: {
    fontFamily: F.f4,
    fontSize: fS(18),
    color: C.BLACK,
    lineHeight: fS(30),
  },
});
