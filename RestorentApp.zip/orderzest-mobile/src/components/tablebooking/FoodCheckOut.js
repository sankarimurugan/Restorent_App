import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
  Animated,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  women,
  house,
  dotes,
  editicon,
  cancelled,
  trash,
  deliverybike,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {C, F} from '../../assets/styles/ColorsFonts';
import {cartList} from '../../redux/api/DummyJson';
import LinearGradient from 'react-native-linear-gradient';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const FoodCheckOutPage = () => {
  const navi = useNavigation();
  const location = useRoute();
  console.log(location?.params?.type3);
  const type3 = location?.params?.type3;
  console.log('edf', type3);

  const [poppup, setPoppup] = useState(false);
  const [deliveryStatus, setDeliveryStatus] = useState(false);

  // Animation start
  const tranceY = useRef(new Animated.Value(0)).current;
  const opac = useRef(new Animated.Value(0)).current;

  const tranfun = () => {
    setPoppup(!poppup);
  };

  useEffect(() => {
    if (!poppup) {
      Animated.timing(tranceY, {
        toValue: SCREEN_HEIGHT,
        duration: 500,
        useNativeDriver: true,
      }).start();
      Animated.timing(opac, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
      Animated.timing(opac, {
        toValue: 0,
        duration: 700,
        useNativeDriver: true,
      }).start();
    } else {
      if (poppup) {
        Animated.timing(tranceY, {
          toValue: 0,
          duration: 500,
          useNativeDriver: true,
        }).start();
        Animated.timing(opac, {
          toValue: 0,
          duration: 500,
          useNativeDriver: true,
        }).start();
        Animated.timing(opac, {
          toValue: 1,
          duration: 700,
          useNativeDriver: true,
        }).start();
      }
    }
  }, [tranfun]);
  // Animation End

  const checkoutClick = () => {
    if (type3 == 'delivery' && !deliveryStatus) {
      console.log('di9yhi');
      setPoppup(true);
    } else {
      if (type3 != 'delivery' || deliveryStatus)
        navi.navigate('BookingSuccess');
    }
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp headername={'Checkout Details'} />
      <ScrollView
        style={{
          flexGrow: 1,
        }}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: fS(10),
          justifyContent: 'space-between',
        }}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              flex: 1,
            }}>
            {cartList?.map(items => {
              return (
                <View
                  style={[
                    {
                      width: '93%',
                      borderRadius: 20,
                      elevation: 5,
                      backgroundColor: '#FFF',
                      padding: 9,
                      marginBottom: '5%',
                    },
                  ]}>
                  <View
                    style={{
                      width: '100%',
                    }}>
                    <View
                      style={{
                        width: '100%',
                        flexDirection: 'row',
                      }}>
                      <View
                        style={{
                          width: '45%',
                        }}>
                        <View
                          style={{
                            width: '100%',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}>
                          <Image
                            source={items?.img}
                            style={{
                              width: '100%',
                              height: fS(150),
                              resizeMode: 'stretch',
                              borderRadius: fS(18),
                            }}
                          />
                        </View>
                      </View>

                      <View
                        style={{
                          width: '55%',
                        }}>
                        <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                          <Text
                            style={{
                              fontSize: fS(18),
                              color: '#252525',
                              fontFamily: F.f5,
                            }}>
                            {items?.naem}
                          </Text>
                        </View>
                        <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                          <Text
                            style={{
                              fontSize: fS(16),
                              color: '#252525',
                              fontFamily: F.f4,
                            }}>
                            {F.doller}
                            {items?.amount}
                          </Text>
                        </View>
                        <View
                          style={{
                            flexDirection: 'row',
                            alignItems: 'center',
                            justifyContent: 'space-between',
                          }}>
                          <View
                            style={{
                              width: '70%',
                              height: fS(50),
                              flexDirection: 'row',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              backgroundColor: '#FFF',
                              borderRadius: 10,
                              elevation: 5,
                              padding: 8,
                              marginTop: '4%',
                              marginHorizontal: '6%',
                            }}>
                            <TouchableOpacity
                              style={{
                                width: fS(30),
                                height: fS(30),
                                backgroundColor: '#F5F5F5',
                                borderRadius: 5,
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}>
                              <Text
                                style={{
                                  fontSize: fS(19),
                                  color: '#252525',
                                  fontFamily: F.f3,
                                  textAlign: 'center',
                                }}>
                                -
                              </Text>
                            </TouchableOpacity>
                            <Text
                              style={{
                                fontFamily: F.f4,
                                fontSize: fS(22),
                                color: '#252525',
                                textAlign: 'justify',
                              }}>
                              01
                            </Text>
                            <TouchableOpacity
                              style={{
                                width: fS(30),
                                height: fS(30),
                                backgroundColor: '#FFD400',
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRadius: fS(10),
                              }}>
                              <Text
                                style={{
                                  fontSize: fS(19),
                                  color: '#252525',
                                  fontFamily: F.f3,
                                  textAlign: 'center',
                                }}>
                                +
                              </Text>
                            </TouchableOpacity>
                          </View>
                          {type3 == 'delivery' && (
                            <TouchableOpacity activeOpacity={0.6}>
                              <Image source={trash} />
                            </TouchableOpacity>
                          )}
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
              );
            })}
            {type3 != 'delivery' && (
              <View
                style={{
                  height: fS(140),
                  width: '93%',
                  backgroundColor: '#FFFDD0',
                  borderRadius: 20,
                  alignItems: 'center',
                  marginBottom: '7%',
                }}>
                <View
                  style={{
                    width: '90%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    marginTop: '2%',
                    marginBottom: '4%',
                    gap: fS(6),
                  }}>
                  <Image
                    source={table2}
                    style={{
                      width: fS(45),
                      height: fS(40),
                      resizeMode: 'contain',
                    }}
                  />
                  <Text
                    style={{
                      fontSize: fS(17),
                      color: '#252525',
                      fontFamily: F.f5,
                    }}>
                    Reserved Table No : 03
                  </Text>
                </View>

                <TouchableOpacity
                  style={{
                    width: '90%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    backgroundColor: '#0257DC',
                    borderRadius: fS(10),
                    justifyContent: 'center',
                    paddingVertical: fS(10),
                  }}>
                  <Text
                    style={{
                      fontSize: fS(13),
                      color: '#FFF',
                      fontFamily: F.f3,
                    }}>
                    Reservation Date & Time : 7th Oct - 11:30 AM - 12:30 PM{' '}
                  </Text>
                </TouchableOpacity>
              </View>
            )}
            {type3 == 'delivery' && (
              <View style={styles.box}>
                <View style={styles.topcont}>
                  <TouchableOpacity style={styles.btn}>
                    <View style={styles.imgcont}>
                      <Image source={house} style={styles.img} />
                    </View>
                    <Text style={styles.text}>Home</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => navi.navigate('savedaddress')}
                    style={styles.dotecont}>
                    <View style={styles.imgcont}>
                      <Image source={editicon} style={styles.img} />
                    </View>
                  </TouchableOpacity>
                </View>
                <View style={styles.textcont}>
                  <Text style={styles.lefttext}>Stella Chrish </Text>
                  <Text style={styles.righttext}>+1-212-456-7890</Text>
                </View>
                <Text style={styles.righttext}>Aeonik, Medium Italic</Text>
              </View>
            )}
          </View>
        </View>
      </ScrollView>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          backgroundColor: C.PRIMARY_BG,
          borderTopEndRadius: fS(20),
          borderTopStartRadius: fS(20),
          paddingVertical: fS(10),
        }}>
        <View style={{width: '93%'}}>
          <View style={{marginBottom: '5%'}}>
            <Text
              style={{
                fontSize: fS(22),
                color: '#252525',
                fontFamily: F.f5,
              }}>
              Price Details
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: '4%',
            }}>
            <Text
              style={{
                fontSize: fS(18),
                color: '#000',
                fontFamily: F.f3,
              }}>
              Price (1 items)
            </Text>
            <Text
              style={{
                fontSize: fS(18),
                color: '#000',
                fontFamily: F.f4,
              }}>
              $22.60
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: '4%',
            }}>
            <Text
              style={{
                fontSize: fS(18),
                color: '#000',
                fontFamily: F.f3,
              }}>
              Taxes
            </Text>
            <Text
              style={{
                fontSize: fS(18),
                color: '#000',
                fontFamily: F.f4,
              }}>
              $5.00
            </Text>
          </View>

          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginBottom: '6%',
            }}>
            <Text
              style={{
                fontSize: fS(22),
                color: '#000',
                fontFamily: F.f4,
              }}>
              Total Amount
            </Text>
            <Text
              style={{
                fontSize: fS(22),
                color: '#252525',
                fontFamily: F.f4,
              }}>
              $27.60
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => checkoutClick()}
            style={{
              width: '100%',
              padding: 12,
              backgroundColor: '#FFD400',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              marginBottom: '5%',
            }}>
            <Text
              style={[
                {
                  color: '#000',
                  fontSize: fS(20),
                  fontFamily: F.f4,
                },
              ]}>
              Checkout
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <Animated.View
        style={[
          styles.slidbottom,
          {transform: [{translateY: tranceY}]},
          {opacity: opac},
          {backgroundColor: 'rgba(0,0,0,0.3)'},
        ]}
      />
      <Animated.View
        style={[styles.boxcont, {transform: [{translateY: tranceY}]}]}>
        <LinearGradient
          colors={[C.PRIMARY_GRAYD, C.PRIMARY_GRAYD2]}
          style={styles.mainbox}>
          <View style={styles.boxes}>
            <Image source={deliverybike} style={styles.bike} />
            <View style={styles.textcont2}>
              <Text style={styles.htxt}>Hey, Wait !!</Text>
              <Text style={styles.htxt2}>
                Please choose the order delivery type you want...
              </Text>
            </View>
          </View>
          <View style={styles.boxes2}>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                tranfun();
                setDeliveryStatus(true);
              }}
              style={styles.btnact}>
              <Text style={styles.btnacttxt}>Take Away</Text>
            </TouchableOpacity>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => {
                tranfun();
                setDeliveryStatus(true);
              }}
              style={styles.btnact2}>
              <Text style={styles.btnact2txt}>Door Delivery</Text>
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            onPress={tranfun}
            activeOpacity={0.7}
            style={styles.close}>
            <Image source={cancelled} style={styles.close} />
          </TouchableOpacity>
        </LinearGradient>
      </Animated.View>
    </SafeAreaView>
  );
};

export default FoodCheckOutPage;

const styles = StyleSheet.create({
  box: {
    padding: fS(10),
    elevation: 10,
    backgroundColor: C.WHITE,
    width: SCREEN_WIDTH / 1.1,
    borderRadius: fS(10),
    marginVertical: fS(20),
    position: 'relative',
  },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: fS(7),
    backgroundColor: C.PRIMARY,
    paddingHorizontal: fS(10),
    paddingVertical: fS(5),
    borderRadius: fS(6),
    width: '25%',
  },
  imgcont: {
    height: fS(20),
    width: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  text: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(16),
  },
  topcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dotecont: {
    height: fS(40),
    width: fS(40),
    alignItems: 'center',
    justifyContent: 'center',
  },
  textcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(7),
    marginVertical: fS(10),
  },
  lefttext: {
    fontFamily: F.f5,
    fontSize: fS(17),
    color: C.BLACK,
  },
  righttext: {
    fontFamily: F.f3,
    fontSize: fS(17),
    color: C.BLACK,
  },
  menu: {
    position: 'absolute',
    right: fS(35),
    top: fS(40),
    backgroundColor: C.LT_YELLOW,
    borderRadius: fS(10),
    elevation: 2,
    zIndex: 1000,
  },
  menutxt: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(15),
  },
  btncont: {
    paddingStart: fS(10),
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    paddingEnd: fS(40),
    paddingVertical: fS(10),
  },
  slidbottom: {
    position: 'absolute',
    height: SCREEN_HEIGHT,
    width: SCREEN_WIDTH,
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  boxcont: {
    width: SCREEN_WIDTH,
    height: 'auto',
    paddingHorizontal: fS(20),
    backgroundColor: C.WHITE,
    paddingVertical: fS(30),
    position: 'absolute',
    bottom: 0,
    borderTopRightRadius: fS(30),
    borderTopLeftRadius: fS(30),
    elevation: 3,
  },
  mainbox: {
    width: '100%',
    height: '100%',
    backgroundColor: C.PRIMARY,
    padding: fS(15),
    borderRadius: fS(15),
    position: 'relative',
    elevation: 5,
    shadowColor: C.PRIMARY,
  },
  boxes: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(20),
  },
  bike: {
    height: fS(120),
    width: fS(120),
    objectFit: 'contain',
  },
  textcont2: {
    width: '70%',
    gap: fS(10),
  },
  htxt: {
    fontFamily: F.f5,
    fontSize: fS(23),
    color: C.BLACK,
  },
  htxt2: {
    fontFamily: F.f3,
    fontSize: fS(16),
    color: C.BLACK,
    lineHeight: fS(25),
  },
  boxes2: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: fS(20),
    marginTop: fS(30),
    alignSelf: 'center',
  },
  btnact: {
    paddingVertical: fS(15),
    backgroundColor: 'transparent',
    borderWidth: fS(2),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(10),
    borderColor: C.WHITE,
    width: '46%',
  },
  btnact2: {
    paddingVertical: fS(15),
    backgroundColor: C.WHITE,
    borderWidth: fS(2),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(10),
    borderColor: C.WHITE,
    width: '46%',
  },
  btnact2txt: {
    fontFamily: F.f5,
    color: C.PRIMARY,
    fontSize: fS(20),
  },
  btnacttxt: {
    fontFamily: F.f5,
    color: C.WHITE,
    fontSize: fS(20),
  },
  close: {
    tintColor: C.WHITE,
    height: fS(35),
    width: fS(35),
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    right: fS(5),
    top: fS(5),
  },
});
