import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';

const CalendarArrow = ({...props}) => {
  console.log('props', props);
  return (
    <View
      style={{
        // flexDirection: 'row',
        // justifyContent: 'space-between',
        paddingHorizontal: 20,
      }}>
      <Text>{props?.month}</Text>
      <TouchableOpacity onPress={props.onPressArrowLeft}>
        <Text>{'<'}</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={props.onPressArrowRight}>
        <Text>{'>'}</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CalendarArrow;

const styles = StyleSheet.create({});
