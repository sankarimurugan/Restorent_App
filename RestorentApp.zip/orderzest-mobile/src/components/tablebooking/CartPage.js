import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import BottomNav from '../../components/Home/BottomNav';

const {height} = Dimensions.get('window');
import {useNavigation, useRoute} from '@react-navigation/native';
import {
  cart,
  leftarrow,
  food1,
  table2,
  food4,
  india,
  cooking,
  profile1,
  women,
  cartEmpty,
  emptycart,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import CartListComp from '../Cart/CartListComp';
import {F} from '../../assets/styles/ColorsFonts';
import {product_list} from '../../redux/api/DummyJson';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');

const CartPage = () => {
  const navigation = useNavigation();
  const loc = useRoute();

  const [active, setActive] = useState(false);

  console.log('dfrdf', loc?.params?.type2);
  const status = loc?.params?.type2;
  const orderstatus = loc?.params?.status;
  const [productList, setProductList] = useState([...product_list]);

  const seDlt = ind => {
    const updatecart = [...productList];
    updatecart.splice(ind, 1);
    setProductList(updatecart);
  };

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <View
        style={{
          flex: 1,
          width: '100%',
          height: '100%',
          justifyContent: 'space-between',
        }}>
        <ScreenHeaderComp headername={'Cart'} />
        {productList?.length == 0 && (
          <View
            style={{
              SCREEN_HEIGHT,
              SCREEN_WIDTH,
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={emptycart}
              style={{
                width: fS(250),
                height: fS(250),
                resizeMode: 'contain',
                alignSelf: 'center',
              }}
            />
          </View>
        )}
        {productList?.length > 0 && (
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{paddingBottom: fS(30)}}
            style={{
              flex: 1,
              paddingTop: 30,
            }}>
            <CartListComp productList={productList} seDlt={seDlt} />
          </ScrollView>
        )}
        {orderstatus !== 'order' && productList?.length > 0 && (
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              paddingVertical: fS(10),
              borderTopRightRadius: fS(10),
              borderTopLeftRadius: fS(10),
              paddingHorizontal: fS(10),
            }}>
            <View style={{width: '93%'}}>
              <View style={{marginBottom: '4%'}}>
                <Text
                  style={{
                    fontSize: fS(23),
                    color: '#252525',
                    fontFamily: F.f5,
                  }}>
                  Price Details
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '4%',
                }}>
                <Text
                  style={{
                    fontSize: fS(17),
                    color: '#000',
                    fontFamily: F.f4,
                  }}>
                  Price (1 items)
                </Text>
                <Text
                  style={{
                    fontSize: fS(17),
                    color: '#000',
                    fontFamily: F.f5,
                  }}>
                  $22.60
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '4%',
                }}>
                <Text
                  style={{
                    fontSize: fS(17),
                    color: '#000',
                    fontFamily: F.f4,
                  }}>
                  Taxes
                </Text>
                <Text
                  style={{
                    fontSize: fS(17),
                    color: '#000',
                    fontFamily: F.f5,
                  }}>
                  $5.00
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginBottom: '4%',
                }}>
                <Text
                  style={{
                    fontSize: fS(23),
                    color: '#000',
                    fontFamily: F.f5,
                  }}>
                  Total Amount
                </Text>
                <Text
                  style={{
                    fontSize: fS(23),
                    color: '#000',
                    fontFamily: F.f5,
                  }}>
                  $27.60
                </Text>
              </View>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('FoodCheckOut', {type3: status})
                }
                style={{
                  width: '100%',
                  padding: 12,
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '5%',
                }}>
                <Text
                  style={[
                    {
                      color: '#000',
                      fontSize: 16,
                      fontWeight: '700',
                    },
                  ]}>
                  Proceed to Pay
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      </View>
      {orderstatus == 'order' && (
        <BottomNav setActive={setActive} active={active} />
      )}
    </SafeAreaView>
  );
};

export default CartPage;
