import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation, useRoute} from '@react-navigation/native';
import {cart, leftarrow, food1, table2, start, likes} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import Icon from 'react-native-vector-icons/Ionicons';
import AntDesign from 'react-native-vector-icons/AntDesign';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {C, F} from '../../assets/styles/ColorsFonts';

const FoodOrderList = () => {
  const navigation = useNavigation();
  const location = useRoute();
  console.log('locahhtion', location);

  const products = [
    {
      name: ' Chicken Briyani',
      price: '$22.50',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$30',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
    {
      name: ' Chicken Briyani',
      price: '$20',
      rating: '4.8',
      review: '256 reviews',
    },
  ];

  const [like, setLike] = useState(true);
  const type2 = location?.params?.type;
  console.log('sagi', type2);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp
        status={type2}
        type={1}
        headername={'Wingman’s Restaurant'}
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={styles.scroll}
        contentContainerStyle={{paddingVertical: fS(30)}}>
        <View
          style={{
            width: '100%',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '90%',
              alignItems: 'center',
            }}>
            <View
              style={[
                {
                  width: '100%',
                  height: height / 16,
                  paddingHorizontal: 15,
                  borderRadius: 10,
                  shadowOpacity: 2,
                  shadowRadius: 3,
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  backgroundColor: '#FFF',
                  elevation: 5,
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '5%',
                },
              ]}>
              <Icon name="search" color="#CDCDCD" size={height / 35} />
              <TextInput
                keyboardType={'numeric'}
                placeholderTextColor="#CDCDCD"
                placeholder="Search your food"
                style={{
                  flex: 1,
                  marginLeft: 5,
                  fontSize: fS(19),
                }}
              />
            </View>

            <View style={{width: '100%', marginBottom: '5%'}}>
              <Text
                style={{
                  fontSize: fS(22),
                  color: '#252525',
                  fontFamily: F.f4,
                }}>
                Cuisine Category
              </Text>
            </View>

            <View
              style={[
                {
                  flexDirection: 'row',
                  flexWrap: 'wrap',
                  justifyContent: 'space-between',
                },
                type2 != 'delivery' && {marginBottom: '25%'},
              ]}>
              {products.map((product, index) => (
                <TouchableOpacity
                  onPress={() =>
                    navigation.navigate('FoodDetailPage', {type2: type2})
                  }
                  style={{
                    backgroundColor: '#FFF',
                    elevation: 5,
                    width: '48%',
                    borderRadius: fS(20),
                    padding: fS(8),
                    marginBottom: fS(10),
                  }}
                  key={index}>
                  <View
                    style={{
                      width: '100%',
                      marginBottom: '5%',
                      alignItems: 'center',
                      justifyContent: 'center',
                      position: 'relative',
                    }}>
                    <Image
                      source={food1}
                      style={{
                        width: '100%',
                        height: fS(150),
                        resizeMode: 'stretch',
                        borderRadius: fS(15),
                      }}
                    />
                    <TouchableOpacity
                      activeOpacity={0.7}
                      onPress={() => setLike(!like)}
                      style={{
                        width: fS(35),
                        height: fS(35),
                        borderRadius: fS(10),
                        position: 'absolute',
                        top: fS(10),
                        right: fS(10),
                        backgroundColor: '#FFF',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <Image
                        style={[
                          styles.heartimg,
                          like ? {tintColor: 'red'} : {tintColor: C.LIGHT_GRAY},
                        ]}
                        source={likes}
                      />
                    </TouchableOpacity>
                  </View>
                  <View style={{marginBottom: '4%'}}>
                    <Text
                      style={{
                        fontFamily: F.f5,
                        fontSize: fS(17),
                        color: '#252525',
                      }}>
                      Chicken Briyani
                    </Text>
                  </View>
                  <View style={{marginBottom: '4%'}}>
                    <Text
                      style={{
                        fontFamily: F.f3,
                        fontSize: fS(15),
                        color: '#252525',
                      }}>
                      $22.50
                    </Text>
                  </View>
                  <View style={{flexDirection: 'row', alignItems: 'center'}}>
                    <View style={styles.startcont}>
                      <Image source={start} style={styles.start} />
                    </View>

                    {/* <Icon name="star" color="#FFD400" size={height / 42} /> */}
                    <View style={{marginLeft: 3}}>
                      <Text
                        style={{
                          fontFamily: F.f4,
                          fontSize: fS(14),
                          color: '#252525',
                        }}>
                        4.8
                      </Text>
                    </View>

                    <View style={{marginLeft: 3}}>
                      <Text
                        style={{
                          fontFamily: F.f4,
                          fontSize: fS(13),
                          color: '#A4A4A4',
                        }}>
                        (256 reviews)
                      </Text>
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </ScrollView>
      {type2 != 'delivery' && (
        <View
          style={{
            // height: fS(130),
            position: 'absolute',
            bottom: fS(0),
            width: '100%',
            backgroundColor: C.LT_YELLOW,
            alignItems: 'center',
            elevation: 2,
            borderTopRightRadius: fS(30),
            borderTopLeftRadius: fS(30),
            paddingVertical: fS(10),
          }}>
          <View
            style={{
              width: '90%',
              flexDirection: 'row',
              alignItems: 'center',
              marginTop: '2%',
              marginBottom: '2%',
            }}>
            <Image
              source={table2}
              style={{
                width: fS(45),
                height: fS(40),
                resizeMode: 'contain',
              }}
            />
            <View style={{marginLeft: 5}}>
              <Text
                style={{
                  fontFamily: F.f5,
                  fontSize: fS(20),
                  color: '#252525',
                }}>
                Reserved Table No : 03
              </Text>
            </View>
          </View>

          <TouchableOpacity
            onPress={() => navigation.navigate('FoodDetailPage')}
            style={{
              width: '90%',
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: '#0257DC',
              borderRadius: fS(20),
              justifyContent: 'center',
              paddingHorizontal: fS(10),
              paddingVertical: fS(13),
            }}>
            <Text
              style={{
                fontFamily: F.f4,
                fontSize: fS(12),
                color: '#FFF',
                textAlign: 'center',
                lineHeight: fS(25),
              }}>
              Reservation Date & Time : 7th Oct - 11:30 AM - 12:30 PM{' '}
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};

export default FoodOrderList;

const styles = StyleSheet.create({
  startcont: {
    height: fS(16),
    width: fS(16),
    alignItems: 'center',
    justifyContent: 'center',
  },
  start: {
    height: '100%',
    width: '100%',
    objectFit: 'cover',
  },
  scroll: {},
  heartimg: {
    height: fS(25),
    width: fS(25),
    alignSelf: 'center',
  },
});
