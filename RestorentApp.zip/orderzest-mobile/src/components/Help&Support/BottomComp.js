import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {call, contact_us, house} from '../../assets/img';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const BottomComp = () => {
  return (
    <View style={styles.bcont}>
      <View style={styles.boxcont}>
        <View style={{width: '70%'}}>
          <Text style={styles.bigtxt}>
            Say hello! and let the conversation begin.
          </Text>
          <View style={styles.textcnot}>
            <TouchableOpacity style={styles.iconcont}>
              <Image source={call} style={{height: fS(17), width: fS(17)}} />
            </TouchableOpacity>
            <Text style={styles.notxt}>+1 1234567890</Text>
          </View>
        </View>
        <View style={{width: '30%'}}>
          <View style={styles.imgcont}>
            <Image source={contact_us} style={styles.img} />
          </View>
        </View>
      </View>
    </View>
  );
};

export default BottomComp;

const styles = StyleSheet.create({
  bcont: {
    paddingHorizontal: fS(25),
  },
  boxcont: {
    paddingVertical: fS(15),
    paddingHorizontal: fS(20),
    backgroundColor: C.LT_YELLOW,
    flexDirection: 'row',
    borderRadius: fS(15),
    alignItems: 'flex-start',
    width: '100%',
    // gap: fS(70),
  },

  bigtxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(20),
  },
  imgcont: {
    height: fS(100),
    width: fS(100),
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  iconcont: {
    height: fS(40),
    width: fS(40),
    backgroundColor: C.PRIMARY,
    borderRadius: fS(15),
    alignItems: 'center',
    justifyContent: 'center',
  },
  textcnot: {
    marginVertical: fS(10),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(7),
  },
  notxt: {
    fontFamily: F.f4,
    color: C.BLACK,
    fontSize: fS(17),
  },
});
