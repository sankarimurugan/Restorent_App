import {
  Dimensions,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {EMAIL, NUMBER, fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {useNavigation} from '@react-navigation/native';

const FormComp = () => {
  const navi = useNavigation();
  // Form State
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [mobileno, setMobileNo] = useState('');
  const [description, setDescription] = useState('');

  // Error State
  const [firstNameErr, setFirstNameErr] = useState(false);
  const [lastNameErr, setLastNameErr] = useState(false);
  const [emailErr, setEmailErr] = useState(false);
  const [validEmailErr, setValidEmailErr] = useState(false);
  const [mobilenoErr, setMobileNoErr] = useState(false);
  const [alidMobilenoErr, setValidMobileNoErr] = useState(false);
  const [descriptionErr, setDescriptionErr] = useState(false);

  const onSubmit = () => {
    if (
      firstName?.length < 4 ||
      lastName?.length < 4 ||
      email?.length < 0 ||
      mobileno?.length < 10 ||
      description?.length < 0 ||
      NUMBER.test(mobileno) == false ||
      EMAIL.test(email) == false
    ) {
      setFirstNameErr(true);
      setLastNameErr(true);
      setEmailErr(true);
      setDescriptionErr(true);
      setValidEmailErr(true);
      setValidMobileNoErr(true);
      setMobileNoErr(true);
    } else {
      console.log('Success');
      navi.navigate('home');
    }
  };
  return (
    <View style={styles.cont}>
      <View style={{marginTop: fS(20), marginBottom: fS(30)}}>
        <View style={{marginVertical: fS(20)}}>
          <TextInput
            style={styles.inputcont}
            placeholderTextColor="#CDCDCD"
            placeholder="First Name"
            value={firstName}
            onChangeText={e => setFirstName(e)}
          />
          {firstNameErr && firstName.length < 4 && (
            <Text style={styles.errorText}>Please Enter First Name*</Text>
          )}
        </View>
        <View style={{marginVertical: fS(20)}}>
          <TextInput
            style={styles.inputcont}
            placeholderTextColor="#CDCDCD"
            placeholder="Last Name"
            value={lastName}
            onChangeText={e => setLastName(e)}
          />
          {lastNameErr && lastName.length < 4 && (
            <Text style={styles.errorText}>Please Enter Last Name*</Text>
          )}
        </View>
        <View style={{marginVertical: fS(20)}}>
          <TextInput
            style={styles.inputcont}
            placeholderTextColor="#CDCDCD"
            placeholder="Email"
            keyboardType="email-address"
            value={email}
            onChangeText={e => setEmail(e)}
          />
          {emailErr && email.length < 4 && (
            <Text style={styles.errorText}>Please Enter Email*</Text>
          )}
          {validEmailErr && EMAIL.test(email) == false && email.length > 4 && (
            <Text style={styles.errorText}>Please Enter Valid Email*</Text>
          )}
        </View>
        <View style={{marginVertical: fS(20)}}>
          <TextInput
            style={styles.inputcont}
            placeholderTextColor="#CDCDCD"
            placeholder="Mobile number"
            keyboardType="phone-pad"
            maxLength={10}
            value={mobileno}
            onChangeText={e => setMobileNo(e)}
          />
          {mobilenoErr && mobileno.length < 10 && (
            <Text style={styles.errorText}>Please Enter Mobile number*</Text>
          )}
          {alidMobilenoErr &&
            NUMBER.test(mobileno) == false &&
            mobileno.length == 10 && (
              <Text style={styles.errorText}>
                Please Enter Valid Mobile number*
              </Text>
            )}
        </View>
        <View style={{marginVertical: fS(20)}}>
          <TextInput
            style={styles.inputcont}
            placeholderTextColor="#CDCDCD"
            placeholder="Description"
            value={description}
            onChangeText={e => setDescription(e)}
          />
          {descriptionErr && description.length < 4 && (
            <Text style={styles.errorText}>Please Enter Description*</Text>
          )}
        </View>
      </View>
      <TouchableOpacity onPress={onSubmit} style={styles.btncont}>
        <Text style={styles.btntext}>Submit</Text>
      </TouchableOpacity>
    </View>
  );
};

export default FormComp;

const styles = StyleSheet.create({
  cont: {
    width: '100%',
    paddingHorizontal: fS(25),
  },
  inputcont: {
    width: '100%',
    borderRadius: fS(15),
    paddingVertical: fS(15),
    paddingHorizontal: fS(20),
    fontSize: fS(18),
    fontFamily: F.f3,
    shadowOpacity: 2,
    shadowRadius: 3,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    backgroundColor: '#FFF',
    elevation: 6,
    color: C.BLACK,
    shadowColor: C.Gray,
  },
  errorText: {
    fontFamily: F.f1,
    color: C.RED,
    fontSize: fS(14),
    position: 'absolute',
    bottom: fS(-33),
    right: 0,
  },
  btncont: {
    width: '100%',
    paddingVertical: fS(20),
    paddingHorizontal: fS(20),
    backgroundColor: C.PRIMARY,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(15),
  },
  btntext: {
    fontFamily: F.f5,
    fontSize: fS(20),
    color: C.BLACK,
  },
});
