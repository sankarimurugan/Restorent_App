import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  Pressable,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useNavigation} from '@react-navigation/native';
import {homesmile, profile} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';

const {width: width, height: height} = Dimensions.get('window');

const Drawer = ({toggleDrawer}) => {
  const navigation = useNavigation();

  return (
    <View style={{flex: 1, backgroundColor: '#FFF', zIndex: 100}}>
      <Pressable
        onPress={toggleDrawer}
        style={{
          width,
          height,
          position: 'absolute',
          top: 0,
          backgroundColor: '#00000080',
        }}>
        <View style={{width: '70%', position: 'relative'}}>
          <View
            style={{
              width: '100%',
              backgroundColor: '#FFD400',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '6%',
              borderBottomLeftRadius: 20,
              borderBottomRightRadius: 20,
              position: 'absolute',
              top: '0',
              zIndex: 10,
              //   marginBottom: '8%',
            }}>
            <View
              style={{
                width: '80%',
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={profile}
                style={{
                  width: fS(55),
                  height: fS(65),
                  resizeMode: 'contain',
                }}
              />
              <View style={{marginLeft: 5}}>
                <Text
                  style={{
                    fontWeight: '700',
                    fontSize: fS(25),
                    color: '#252525',
                  }}>
                  Stella Chrish
                </Text>
                <Text
                  style={{
                    fontWeight: '400',
                    fontSize: fS(18),
                    color: '#252525',
                  }}>
                  Designer
                </Text>
              </View>
            </View>
          </View>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
              backgroundColor: '#FFF',
              height: '100%',
              paddingTop: '38%',
            }}>
            <View
              style={{
                width: '80%',
                justifyContent: 'center',
              }}>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Home
                  </Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => navigation.navigate('EmptyAddress')}
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Address
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Favorites
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Table Reservation
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Rewards
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Orders
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Settings
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Help & Support
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '12%',
                }}>
                <View>
                  <Image
                    source={homesmile}
                    style={{
                      width: fS(30),
                      height: fS(30),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <View style={{marginLeft: '5%'}}>
                  <Text
                    style={{
                      fontWeight: '400',
                      fontSize: fS(20),
                      color: '#252525',
                    }}>
                    Logout
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Pressable>
    </View>
  );
};

export default Drawer;
