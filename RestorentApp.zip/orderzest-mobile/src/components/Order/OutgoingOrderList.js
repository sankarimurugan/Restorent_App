import React from 'react';
import {StyleSheet, View, Text, Image, TouchableOpacity} from 'react-native';
import {C, F} from '../../assets/styles/ColorsFonts';
import {fS} from '../../constants/Loader/Loader';
import {non_veg, table, veg} from '../../assets/img';
import {useNavigation} from '@react-navigation/native';

const OutgoingOrderList = () => {
  const navi = useNavigation();
  return (
    <>
      <View style={styles.listBox}>
        <Text style={styles.title}>Wingsman’s Restaurant</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginTop: 2,
          }}>
          <Text style={styles.desc}>Order Id: 1234</Text>
          <Text style={styles.desc}>Number of Items: 1234</Text>
        </View>
        <Text style={styles.desc1}>Order Type: Delivery</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginVertical: 3,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '60%',
            }}>
            <Image source={non_veg} style={styles.icon} />
            <Text style={styles.desc}>Chicken Briyani</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '40%',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.desc}>Qty: 1</Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.desc2}>$1234</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginVertical: 3,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '60%',
            }}>
            <Image source={veg} style={styles.icon} />
            <Text style={styles.desc}>Veg Sandwich</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '40%',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.desc}>Qty: 4</Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.desc2}>$1234</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignSelf: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginTop: fS(10),
          }}>
          <TouchableOpacity
            onPress={() => navi.goBack()}
            style={styles.cancelBtn}>
            <Text style={styles.cancelBtnTxt}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navi.navigate('trackorder')}
            style={styles.trackBtn}>
            <Text style={styles.cancelBtnTxt}>Track Order</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.listBox}>
        <Text style={styles.title}>Wingsman’s Restaurant</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginTop: 2,
          }}>
          <Text style={styles.desc}>Order Id: 1234</Text>
          <Text style={styles.desc}>Number of Items: 1234</Text>
        </View>
        <Text style={styles.desc1}>Order Type: Delivery</Text>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginVertical: 3,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '60%',
            }}>
            <Image source={non_veg} style={styles.icon} />
            <Text style={styles.desc}>Chicken Briyani</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '40%',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.desc}>Qty: 1</Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.desc2}>$1234</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginVertical: 3,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '60%',
            }}>
            <Image source={veg} style={styles.icon} />
            <Text style={styles.desc}>Veg Sandwich</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '40%',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.desc}>Qty: 4</Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.desc2}>$1234</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginVertical: 3,
          }}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '60%',
            }}>
            <Image source={non_veg} style={styles.icon} />
            <Text style={styles.desc}>Chicken Sandwich</Text>
          </View>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              width: '40%',
              justifyContent: 'space-between',
            }}>
            <Text style={styles.desc}>Qty: 2</Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Text style={styles.desc2}>$1234</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignSelf: 'center',
            justifyContent: 'space-between',
            width: '100%',
            marginTop: fS(10),
          }}>
          <TouchableOpacity style={styles.cancelBtn}>
            <Text style={styles.cancelBtnTxt}>Cancel</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navi.navigate('trackorder')}
            style={styles.trackBtn}>
            <Text style={styles.cancelBtnTxt}>Track Order</Text>
          </TouchableOpacity>
        </View>
      </View>
    </>
  );
};

export default OutgoingOrderList;
const styles = StyleSheet.create({
  listBox: {
    width: '90%',
    elevation: 2,
    shadowColor: '#c4c4c4',
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: '#f1f1f1',
    backgroundColor: C.WHITE,
    borderRadius: fS(15),
    marginTop: fS(30),
    paddingVertical: fS(15),
    paddingHorizontal: fS(20),
  },
  title: {
    fontFamily: F.f5,
    fontSize: fS(20),
    color: C.BLACK,
    marginBottom: 6,
  },
  desc: {
    fontFamily: F.f4,
    fontSize: fS(15),
    color: C.BLACK,
  },
  desc1: {
    fontFamily: F.f5,
    fontSize: fS(15),
    color: C.BLACK,
    marginVertical: fS(10),
  },
  desc2: {
    fontFamily: F.f5,
    fontSize: fS(15),
    color: C.BLACK,
    marginTop: fS(6),
  },
  icon: {
    width: fS(20),
    height: fS(20),
    resizeMode: 'stretch',
    marginRight: fS(5),
  },

  cancelBtn: {
    backgroundColor: C.DARK_GRAY,
    height: fS(52),
    borderRadius: fS(10),
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(5),
    marginBottom: fS(10),
    width: fS(165),
    alignSelf: 'center',
  },

  trackBtn: {
    backgroundColor: C.PRIMARY,
    height: fS(52),
    borderRadius: fS(10),
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(5),
    marginBottom: fS(10),
    width: fS(165),
    alignSelf: 'center',
    marginHorizontal: 10,
    marginVertical: 15,
  },
  cancelBtnTxt: {
    fontFamily: F.f5,
    fontSize: fS(17),
    color: C.WHITE,
  },
});
