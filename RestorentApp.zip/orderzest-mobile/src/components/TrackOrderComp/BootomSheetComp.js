import {
  Dimensions,
  Image,
  PermissionsAndroid,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useCallback, useEffect, useRef, useState} from 'react';

import {Gesture, GestureHandlerRootView} from 'react-native-gesture-handler';
import {C, F} from '../../assets/styles/ColorsFonts';
import {fS} from '../../constants/Loader/Loader';
import {
  GreenLocation,
  LocationPin,
  Tracker,
  bikemap,
  locationicon,
  logout,
  mapdown,
  restaurantmap,
  trackcheck,
} from '../../assets/img';
import {GestureDetector} from 'react-native-gesture-handler';
import Animated, {
  event,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import {duration} from 'moment';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const lineWidth = SCREEN_WIDTH - fS(100);
const SheetHight = SCREEN_HEIGHT - fS(100);

const MinTrnsY = SCREEN_HEIGHT / SheetHight + fS(20);
const MaxTrnsY = -SheetHight + fS(150);

const BootomSheetComp = ({
  requestLocPermission,
  handleMyLocationPress,
  finalAddress,
}) => {
  // Animated Values
  const trackLevel = 3;
  const transY = useSharedValue(MinTrnsY);

  const context = useSharedValue({y: 0});

  const scrollTo = useCallback((destination: number) => {
    transY.value = withSpring(destination, {damping: 1000});
  }, []);

  useEffect(() => {
    handleMyLocationPress();
    scrollTo(MinTrnsY);
    closeBtn();
  }, [transY]);

  const gesture = Gesture.Pan()
    .onStart(() => {
      context.value = {y: transY.value};
    })
    .onUpdate(e => {
      console.log(e?.absoluteY);
      transY.value = e.translationY + context.value.y;
      transY.value = Math.max(transY.value, MaxTrnsY);
    })
    .onEnd(() => {
      if (transY.value <= MinTrnsY) {
        console.log('top');
        scrollTo(MaxTrnsY);
      } else if (transY.value >= -SCREEN_HEIGHT / 5) {
        console.log('bottom');
        scrollTo(MinTrnsY);
        // scrollTo(MaxTrnsY);
      }
    });

  const closeBtn = () => {
    scrollTo(MinTrnsY);
    // scrollTo(MaxTrnsY);
    handleMyLocationPress();
    console.log('location');
  };

  const rBottomStyle = useAnimatedStyle(() => {
    return {
      transform: [{translateY: withTiming(transY.value)}],
    };
  });

  const SLine = useSharedValue(0);

  const LineAni = {
    btnStyles: useAnimatedStyle(() => {
      return {
        width: SLine.value,
      };
    }),
  };
  console.log('width', SCREEN_WIDTH);
  useEffect(() => {
    if (trackLevel == 1) {
      SLine.value = withTiming(lineWidth / 3, {duration: 1000});
    } else if (trackLevel == 2) {
      SLine.value = withTiming(lineWidth - lineWidth / 3, {duration: 1000});
    } else if (trackLevel == 3) {
      SLine.value = withTiming(lineWidth, {
        duration: 1000,
      });
    } else {
      SLine.value = withTiming(0, {
        duration: 1000,
      });
    }
  }, []);
  return (
    <GestureDetector gesture={gesture}>
      <Animated.View style={[rBottomStyle, styles.sheetlayer]}>
        {requestLocPermission && (
          <Animated.View style={[styles.sheet]}>
            <Pressable
              onPress={() => closeBtn()}
              onPointerCancel={() => closeBtn()}
              onPointerDown={() => closeBtn()}
              onFocus={() => closeBtn()}
              onHoverIn={() => closeBtn()}
              style={{
                width: '100%',
                flexDirection: 'column',
                gap: fS(10),
                position: 'relative',
                marginBottom: fS(40),
              }}>
              <TouchableOpacity onPress={() => closeBtn()}>
                <Image
                  source={mapdown}
                  style={{
                    position: 'absolute',
                    height: fS(30),
                    width: fS(30),
                    right: fS(20),
                  }}
                />
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.7}
                style={{
                  position: 'absolute',
                  right: fS(0),
                  top: fS(-100),
                  height: fS(60),
                  width: fS(60),
                  backgroundColor: C.PRIMARY,
                  borderRadius: fS(100),
                  alignItems: 'center',
                  justifyContent: 'center',
                  zIndex: 1000,
                }}
                onPress={() => closeBtn()}>
                <Image source={locationicon} />
              </TouchableOpacity>
              <Text
                style={{
                  fontFamily: F.f3,
                  fontSize: fS(17),
                  color: C.BLACK,
                }}>
                Delivering to
              </Text>
              <Text
                numberOfLines={1}
                style={{
                  fontFamily: F.f2,
                  fontSize: fS(17),
                  color: C.BLACK,
                  lineHeight: 20,
                }}>
                {finalAddress?.address}
              </Text>
              {/* Track Line Start */}
              <View style={styles.tracklineconp}>
                <View style={styles.line} />
                <Animated.View style={[styles.Sline1, LineAni.btnStyles]} />
                {/* <View style={styles.Sline2} /> */}
                {/* <View style={styles.Sline3} /> */}
                <View
                  style={[
                    styles.chekbox1,
                    trackLevel >= 0
                      ? {backgroundColor: C.LINE_GREEN}
                      : {backgroundColor: 'red'},
                  ]}>
                  {trackLevel >= 0 && (
                    <Image source={trackcheck} style={styles.icon} />
                  )}
                </View>
                <View style={styles.Text1}>
                  <Text
                    style={[
                      styles.btxt2,
                      trackLevel >= 0
                        ? {color: C.LINE_GREEN}
                        : {color: C.LINE_GRAY},
                    ]}>
                    Confirmed
                  </Text>
                </View>
                <View
                  style={[
                    styles.chekbox2,
                    trackLevel >= 1
                      ? {backgroundColor: C.LINE_GREEN}
                      : {backgroundColor: C.LINE_GRAY},
                  ]}>
                  {trackLevel >= 1 && (
                    <Image source={trackcheck} style={styles.icon} />
                  )}
                </View>
                <View style={styles.Text2}>
                  <Text
                    style={[
                      styles.btxt2,
                      trackLevel >= 1
                        ? {color: C.LINE_GREEN}
                        : {color: C.LINE_GRAY},
                    ]}>
                    Preparing
                  </Text>
                </View>
                <View
                  style={[
                    styles.chekbox3,
                    trackLevel >= 2
                      ? {backgroundColor: C.LINE_GREEN}
                      : {backgroundColor: C.LINE_GRAY},
                  ]}>
                  {trackLevel >= 2 && (
                    <Image source={trackcheck} style={styles.icon} />
                  )}
                </View>
                <View style={styles.Text3}>
                  <Text
                    style={[
                      styles.btxt2,
                      trackLevel >= 2
                        ? {color: C.LINE_GREEN}
                        : {color: C.LINE_GRAY},
                    ]}>
                    Dispatched
                  </Text>
                </View>
                <View
                  style={[
                    styles.chekbox4,
                    trackLevel >= 3
                      ? {backgroundColor: C.LINE_GREEN}
                      : {backgroundColor: C.LINE_GRAY},
                  ]}>
                  {trackLevel >= 3 && (
                    <Image source={trackcheck} style={styles.icon} />
                  )}
                </View>
                <View style={styles.Text4}>
                  <Text
                    style={[
                      styles.btxt2,
                      trackLevel >= 3
                        ? {color: C.LINE_GREEN}
                        : {color: C.LINE_GRAY},
                    ]}>
                    Delivered
                  </Text>
                </View>
              </View>
              {/* Track Line End */}
            </Pressable>
            <View style={{width: '100%'}}>
              <Text style={styles.ordertxt}>Order ID : 12347</Text>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'flex-start',
                  gap: fS(10),
                }}>
                <Text
                  style={{
                    fontFamily: F.f3,
                    fontSize: fS(17),
                    color: C.BLACK,
                    marginTop: fS(10),
                  }}>
                  Payment Method : COD
                </Text>
                <Text
                  style={{
                    fontFamily: F.f3,
                    fontSize: fS(15),
                    color: C.BLACK,
                    marginTop: fS(10),
                  }}>
                  3 Items
                </Text>
              </View>
            </View>
            <View style={styles.table}>
              <Text
                style={[styles.btxt, {marginTop: fS(30), marginBottom: fS(6)}]}>
                Qty & Item Name
              </Text>
              <View style={styles.tablecont}>
                <Text style={styles.rtxt}>1 x Chicken Briyani</Text>
                <Text style={styles.rtxt}>$22.50</Text>
              </View>
              <View style={styles.tablecont}>
                <Text style={styles.rtxt}>2 x Veg Sandwich</Text>
                <Text style={styles.rtxt}>$10.00</Text>
              </View>
              <View style={styles.tablecont}>
                <Text style={styles.rtxt}>1 x Chicken Sandwich</Text>
                <Text style={styles.rtxt}>$15.80</Text>
              </View>
              <View style={styles.tablecont}>
                <Text style={styles.btxt}>Sub Total</Text>
                <Text style={styles.btxt}>$15.80</Text>
              </View>
              <View style={styles.tablecont}>
                <Text style={styles.btxt}>Taxes & Charges</Text>
                <Text style={styles.btxt}>$5.00</Text>
              </View>
            </View>
            <View
              style={{
                width: '100%',
                height: fS(3),
                backgroundColor: C.LINE_GRAY,
                marginVertical: fS(10),
              }}
            />
            <View style={styles.tablecont}>
              <Text style={styles.botxt}>Grand Total</Text>
              <Text style={styles.botxt}>$53.30</Text>
            </View>
          </Animated.View>
        )}
      </Animated.View>
    </GestureDetector>
  );
};

export default BootomSheetComp;

const styles = StyleSheet.create({
  map: {
    height: SCREEN_HEIGHT,
    width: SCREEN_WIDTH,
  },
  tracklineconp: {
    alignItems: 'center',
    justifyContent: 'center',
    width: lineWidth,
    marginVertical: fS(30),
    position: 'relative',
    alignSelf: 'center',
  },
  line: {
    width: lineWidth,
    backgroundColor: C.LINE_GRAY,
    height: fS(3),
    alignSelf: 'center',
  },
  Sline1: {
    // width: lineWidth / 3,
    height: fS(3),
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    backgroundColor: C.LINE_GREEN,
  },
  Sline2: {
    // width: lineWidth / 3,
    height: fS(3),
    position: 'absolute',
    backgroundColor: 'green',
    left: lineWidth / 3,
    top: 0,
    bottom: 0,
  },
  Sline3: {
    width: lineWidth / 3,
    height: fS(3),
    position: 'absolute',
    left: lineWidth - lineWidth / 3,
    top: 0,
    bottom: 0,
  },
  chekbox1: {
    height: fS(20),
    width: fS(20),
    backgroundColor: 'red',
    borderRadius: fS(30),
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    left: fS(-10),
  },
  chekbox2: {
    position: 'absolute',
    height: fS(20),
    width: fS(20),
    // backgroundColor: 'red',
    borderRadius: fS(30),
    alignItems: 'center',
    justifyContent: 'center',
    left: lineWidth / 3.2,
  },
  chekbox3: {
    position: 'absolute',
    height: fS(20),
    width: fS(20),
    // backgroundColor: 'red',
    borderRadius: fS(30),
    alignItems: 'center',
    justifyContent: 'center',
    left: lineWidth - lineWidth / 3,
  },
  chekbox4: {
    position: 'absolute',
    height: fS(20),
    width: fS(20),
    // backgroundColor: 'red',
    borderRadius: fS(30),
    alignItems: 'center',
    justifyContent: 'center',
    right: fS(-10),
  },
  icon: {
    objectFit: 'contain',
    height: fS(15),
    width: fS(15),
  },
  Text1: {
    position: 'absolute',
    top: 0,
    marginTop: fS(30),
    left: fS(-40),
  },
  Text2: {
    position: 'absolute',
    top: 0,
    marginTop: fS(30),
    left: lineWidth / 3 - fS(30),
  },
  Text3: {
    position: 'absolute',
    top: 0,
    marginTop: fS(30),
    right: lineWidth / 3 - fS(50),
  },
  Text4: {
    position: 'absolute',
    top: 0,
    marginTop: fS(30),
    right: fS(-30),
  },
  btxt2: {
    fontFamily: F.f4,
    fontSize: fS(15),
    // color: C.LINE_GREEN,
  },
  ordertxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(20),
  },
  table: {
    width: '100%',
  },
  tablecont: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginVertical: fS(15),
  },
  rtxt: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(17),
  },
  btxt: {
    fontFamily: F.f5,
    fontSize: fS(17),
    color: C.BLACK,
  },
  botxt: {
    fontFamily: F.f5,
    fontSize: fS(20),
    color: C.BLACK,
  },
  sheet: {
    borderTopLeftRadius: fS(30),
    borderTopRightRadius: fS(30),
    paddingHorizontal: 20,
    backgroundColor: C.WHITE,
    elevation: 3,
    shadowColor: C.PRIMARY,
    paddingVertical: fS(20),
    width: '100%',
    top: 0,
    height: SheetHight,
  },
  sheetlayer: {
    height: SheetHight / 7.5,
    width: '100%',
    position: 'absolute',
    backgroundColor: 'red',
    borderTopLeftRadius: fS(30),
    borderTopRightRadius: fS(30),
    backgroundColor: C.WHITE,
    elevation: 3,
    bottom: 0,
  },
});
