import React from 'react';
import {StyleSheet, TouchableOpacity, View, Text, Image} from 'react-native';
import {C, F} from '../../assets/styles/ColorsFonts';
import {fS} from '../../constants/Loader/Loader';
import {sad, schedule, table} from '../../assets/img';
import {
  NavigationContainer,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import {reservationList} from '../../redux/api/DummyJson';

const TableReservationList = ({navigation}) => {
  const navi = useNavigation();

  return (
    <View style={{marginTop: fS(10), flex: 1}}>
      {reservationList?.map(item => {
        return (
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => navi.navigate('TableDetail')}
            style={{
              paddingVertical: fS(15),
              marginBottom: fS(10),
              borderBottomColor: C.LightPrimary,
              borderBottomWidth: 1,
              shadowColor: 'black',
              shadowOffset: {
                width: 7,
                height: 7,
              },
              shadowOpacity: 0.5,
              shadowRadius: fS(20),
              elevation: 6,
              backgroundColor: C.WHITE,
              paddingHorizontal: fS(15),
              borderRadius: fS(20),
              marginVertical: fS(15),
            }}>
            <Text style={styles.title}>{item?.name}</Text>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: fS(10),
                justifyContent: 'flex-start',
                marginVertical: fS(7),
              }}>
              <Image source={table} style={styles.table} />
              <Text style={styles.name}>{item?.tablecount}</Text>
            </View>
            <View style={styles.dateTime}>
              <Text style={styles.dateTimeText}>{item?.time}</Text>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'flex-start',
                alignItems: 'center',
              }}>
              <Image source={item?.icon} style={styles.schedule} />
              <Text style={styles.discriptionText}>{item?.comments}</Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    fontFamily: F.f5,
    fontSize: fS(19),
    color: C.BLACK,
  },
  name: {
    fontFamily: F.f5,
    fontSize: fS(16),
    color: C.BLACK,
  },
  table: {
    width: fS(40),
    height: fS(40),
    resizeMode: 'contain',
  },
  schedule: {
    width: fS(22),
    height: fS(22),
    resizeMode: 'contain',
    marginRight: fS(10),
  },
  dateTime: {
    backgroundColor: '#0257DC',
    height: fS(40),
    borderRadius: fS(10),
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(5),
    marginBottom: fS(10),
  },
  dateTimeText: {
    fontFamily: F.f4,
    fontSize: fS(13),
    color: C.WHITE,
  },
  discriptionText: {
    fontFamily: F.f3,
    fontSize: fS(14),
    color: C.BLACK,
  },
});
export default TableReservationList;
