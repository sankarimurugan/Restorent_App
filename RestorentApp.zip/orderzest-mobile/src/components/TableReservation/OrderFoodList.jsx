import React from 'react';
import {Image, StyleSheet, Text, View} from 'react-native';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {detailBanner, food1} from '../../assets/img';
import {foodlist} from '../../redux/api/DummyJson';

const OrderFoodList = () => {
  return (
    <>
      <Text style={styles.title}>Ordered Foods</Text>
      <Text style={styles.desc}>
        At the time of your reservation, food will be served to you
      </Text>
      {foodlist?.map(item => {
        return (
          <View style={styles.lists}>
            <View style={styles.imgBox}>
              <Image source={food1} style={styles.detailBanner} />
            </View>
            <View style={styles.ritList}>
              <Text style={styles.listTitle}>{item?.name}</Text>
              <Text style={styles.listDesc}>
                {F.doller}
                {item?.amount}
              </Text>
              <Text style={styles.listTitle1}>{item?.qty}</Text>
            </View>
          </View>
        );
      })}
    </>
  );
};

export default OrderFoodList;

const styles = StyleSheet.create({
  title: {
    fontFamily: F.f5,
    fontSize: fS(20),
    color: C.BLACK,
    marginBottom: fS(10),
  },
  desc: {
    fontFamily: F.f3,
    fontSize: fS(15),
    color: C.BLACK,
  },
  lists: {
    width: '97%',
    flexDirection: 'row',
    shadowColor: '#000',
    shadowOffset: {width: 10, height: 40},
    shadowOpacity: 1,
    shadowRadius: fS(15),
    borderRadius: fS(15),
    elevation: 5,
    shadowColor: '#000',
    paddingVertical: fS(13),
    paddingHorizontal: fS(13),
    marginVertical: fS(10),
    gap: fS(10),
    backgroundColor: C.WHITE,
    alignSelf: 'center',
  },
  imgBox: {
    width: fS(130),
    height: fS(90),
    borderRadius: 5,
    overflow: 'hidden',
    marginRight: 5,
  },
  detailBanner: {
    width: '100%',
    height: '100%',
    resizeMode: 'stretch',
  },
  ritList: {
    justifyContent: 'space-between',
  },
  listTitle: {
    fontFamily: F.f5,
    fontSize: fS(15),
    color: C.BLACK,
    marginBottom: 2,
  },
  listTitle1: {
    fontFamily: F.f5,
    fontSize: fS(14),
    color: C.BLACK,
    marginBottom: 2,
  },
  listDesc: {
    fontFamily: F.f3,
    fontSize: fS(15),
    color: C.BLACK,
  },
});
