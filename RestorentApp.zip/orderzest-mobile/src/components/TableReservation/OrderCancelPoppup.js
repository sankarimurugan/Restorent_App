import {
  Dimensions,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {useNavigation} from '@react-navigation/native';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const OrderCancelPoppup = ({toggle, mess, btn1, btn2}) => {
  const navi = useNavigation();
  return (
    <View style={styles.poplayer}>
      <View style={styles.box}>
        <Text style={styles.content}>{mess}</Text>
        <View style={styles.layercont}>
          <TouchableOpacity
            onPress={() => {
              toggle();
            }}
            style={[
              styles.btncont,
              {color: C.WHITE, backgroundColor: C.LIGHT_GRAY},
            ]}>
            <Text style={[styles.btn_text]}>{btn1}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              toggle();
              if (mess == 'Are you sure you want to log out?') {
                navi.navigate('LoginScreen');
              } else {
                navi.navigate('home');
              }
            }}
            style={[
              styles.btncont,
              {color: C.BLACK, backgroundColor: C.PRIMARY},
            ]}>
            <Text style={[styles.btn_text]}>{btn2}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default OrderCancelPoppup;

const styles = StyleSheet.create({
  poplayer: {
    SCREEN_HEIGHT,
    SCREEN_WIDTH,
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(0,0,0,0.5)',
    zIndex: 1000,
    alignItems: 'center',
    justifyContent: 'center',
  },
  box: {
    width: '80%',
    backgroundColor: C.WHITE,
    paddingVertical: fS(20),
    paddingHorizontal: fS(15),
    borderRadius: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    shadowOpacity: 2,
    shadowRadius: 3,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    backgroundColor: '#FFF',
    elevation: 10,
  },
  content: {
    fontFamily: F.f4,
    fontSize: fS(20),
    color: C.BLACK,
    textAlign: 'center',
    lineHeight: fS(30),
  },
  layercont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: fS(25),
    marginBottom: fS(10),
    width: '90%',
  },
  btncont: {
    paddingVertical: fS(10),
    paddingHorizontal: fS(30),
    borderRadius: fS(10),
  },
  btn_text: {
    fontFamily: F.f4,
    fontSize: fS(18),
    color: C.WHITE,
  },
});
