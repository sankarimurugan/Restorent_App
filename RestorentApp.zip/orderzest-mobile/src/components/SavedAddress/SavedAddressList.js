import {
  Dimensions,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {dotes, home, house} from '../../assets/img';
import {
  address_list,
  address_list2,
  product_list,
} from '../../redux/api/DummyJson';
import {useNavigation} from '@react-navigation/native';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');

const SavedAddressList = () => {
  const navi = useNavigation();
  const [select, setSelect] = useState(undefined);

  const menufun = ind => {
    setSelect(ind);
  };

  useEffect(() => {
    if (select == undefined) {
      setSelect(0);
    }
  }, []);
  console.log(select, 'select');
  return (
    <View style={styles.cont}>
      <View style={styles.listcont}>
        {address_list2?.map((item, ind) => {
          return (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => menufun(ind)}
              style={styles.box}>
              <View style={{}}>
                <View style={styles.topcont}>
                  <TouchableOpacity style={styles.btn}>
                    <View style={styles.imgcont}>
                      <Image source={item?.icon} style={styles.img} />
                    </View>
                    <Text style={styles.text}>{item?.iconName}</Text>
                  </TouchableOpacity>
                </View>
                <View style={styles.textcont}>
                  <Text style={styles.lefttext}>{item?.name}</Text>
                  <Text style={styles.righttext}>{item?.no}</Text>
                </View>
                <Text style={styles.righttext}>{item?.address}</Text>
                <TouchableOpacity
                  style={styles.btncont}
                  onPress={() => {
                    // menufun(ind);
                    navi.navigate('AddAddress', {edit: true});
                  }}>
                  <Text style={styles.menutxt}>Edit</Text>
                </TouchableOpacity>
              </View>
              <Pressable
                onPress={() => menufun(ind)}
                style={[
                  styles.dotecont,
                  select == ind
                    ? {borderColor: C.DARK_BLUE}
                    : {borderColor: C.BLACK},
                ]}>
                <View style={styles.imgcont}>
                  <View
                    style={[
                      styles.dots,
                      select == ind
                        ? {backgroundColor: C.DARK_BLUE}
                        : {display: 'none'},
                    ]}
                  />
                </View>
              </Pressable>
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

export default SavedAddressList;

const styles = StyleSheet.create({
  cont: {
    marginBottom: fS(30),
  },
  listcont: {
    marginHorizontal: fS(25),
  },
  box: {
    padding: fS(10),
    elevation: 10,
    backgroundColor: C.WHITE,
    width: SCREEN_WIDTH / 1.1,
    borderRadius: fS(10),
    marginVertical: fS(20),
    position: 'relative',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: fS(7),
    backgroundColor: C.PRIMARY,
    paddingHorizontal: fS(10),
    paddingVertical: fS(5),
    borderRadius: fS(6),
    width: '25%',
  },
  imgcont: {
    height: fS(20),
    width: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  text: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(16),
  },
  topcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  textcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(7),
    marginVertical: fS(10),
  },
  lefttext: {
    fontFamily: F.f5,
    fontSize: fS(17),
    color: C.BLACK,
  },
  righttext: {
    fontFamily: F.f3,
    fontSize: fS(17),
    color: C.BLACK,
  },
  menu: {
    position: 'absolute',
    right: fS(35),
    top: fS(40),
    backgroundColor: C.LT_YELLOW,
    borderRadius: fS(10),
    elevation: 2,
    zIndex: 1000,
  },
  menutxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(15),
  },
  btncont: {
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    marginTop: fS(7),
  },
  dotecont: {
    width: fS(25),
    height: fS(25),
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: fS(2),
    borderRadius: fS(30),
    // borderColor: C.DARK_BLUE,
    marginStart: fS(20),
  },
  dots: {
    height: fS(10),
    width: fS(10),
    backgroundColor: C.DARK_BLUE,
    borderRadius: fS(10),
  },
});
