import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {C, F} from '../../assets/styles/ColorsFonts';
import {fS} from '../../constants/Loader/Loader';
import {cart, leftarrow} from '../../assets/img';
import {useNavigation} from '@react-navigation/native';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const ScreenHeaderComp = ({headername, type, status, backhome, track}) => {
  const navi = useNavigation();
  return (
    <View
      style={[
        styles.head_comp,
        track
          ? {backgroundColor: 'transparent'}
          : {backgroundColor: C.PRIMARY_BG},
      ]}>
      <View style={styles.titlecont}>
        <TouchableOpacity
          onPress={() => {
            backhome ? navi.navigate('home') : navi.goBack();
          }}
          style={styles.iconcont}
          activeOpacity={0.5}>
          <Image source={leftarrow} style={styles.arrow} />
        </TouchableOpacity>
        <Text style={styles.headtext}>{headername}</Text>
      </View>
      {type == 1 && (
        <TouchableOpacity
          onPress={() => {
            headername == 'Orders'
              ? navi.navigate('CartPage', {status: 'order'})
              : navi.navigate('CartPage', {type2: status});
          }}
          style={{
            width: fS(40),
            height: fS(40),
            backgroundColor: '#FFD400',
            borderRadius: fS(10),
            alignItems: 'center',
            justifyContent: 'center',
            marginEnd: fS(20),
          }}>
          <Image
            source={cart}
            style={{
              width: fS(25),
              height: fS(25),
              resizeMode: 'contain',
              alignItems: 'center',
            }}
          />
          <View
            style={{
              position: 'absolute',
              height: fS(15),
              width: fS(15),
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: 'red',
              zIndex: 100,
              borderRadius: fS(12),
              top: fS(5),
              right: fS(3),
            }}>
            <Text style={{fontFamily: F.f4, fontSize: fS(8), color: C.WHITE}}>
              10
            </Text>
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default ScreenHeaderComp;

const styles = StyleSheet.create({
  head_comp: {
    width: SCREEN_WIDTH,
    height: 'auto',
    // backgroundColor: C.PRIMARY_BG,
    paddingVertical: fS(20),
    // borderRadius
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: fS(10),
  },
  titlecont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    SCREEN_WIDTH,
    gap: fS(5),
  },
  headtext: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(21),
  },
  iconcont: {
    height: fS(40),
    width: fS(40),
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: 'red',
  },
  arrow: {
    height: '50%',
    width: '50%',
    objectFit: 'contain',
  },
});
