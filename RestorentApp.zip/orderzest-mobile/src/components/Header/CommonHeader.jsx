import React from 'react';
import {StyleSheet, View, Text, TouchableOpacity, Image} from 'react-native';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {leftarrow} from '../../assets/img';
import {useRoute} from '@react-navigation/native';

const CommonHeader = ({title}) => {
  const route = useRoute();
  console.log(title);
  return (
    <View style={styles.titleBox}>
      <TouchableOpacity
        style={styles.arwBtn}
        onPress={() => navigation.goBack()}>
        <Image
          source={leftarrow}
          style={{
            width: fS(20),
            height: fS(20),
            resizeMode: 'contain',
          }}
        />
      </TouchableOpacity>
      <Text style={styles.title}>{title}</Text>
    </View>
  );
};
const styles = StyleSheet.create({
  titleBox: {
    width: '100%',
    height: fS(70),
    flexDirection: 'row',
    alignItems: 'center',
  },
  arwBtn: {
    width: fS(40),
    height: fS(40),
    // backgroundColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontFamily: F.f4,
    fontSize: fS(21),
    color: C.BLACK,
  },
});
export default CommonHeader;
