//

import {
  Dimensions,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {
  americaflag,
  banner,
  cusisne1,
  cusisne2,
  food,
  food1,
  india,
  likes,
  profile_img,
  start,
  trash,
} from '../../assets/img';
import {product_list} from '../../redux/api/DummyJson';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const FavoritsListComp = ({productList, setLikeFun}) => {
  return (
    <View style={styles.cont}>
      <View style={styles.categorycont}>
        {productList?.map((item, ind) => {
          return (
            <View style={styles.box_cont}>
              <View style={styles.box_cont_layer2}>
                {/* <View style={styles.imgcont}> */}
                <Image source={item?.img} style={styles.foodimg} />
                {/* </View> */}
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => setLikeFun(ind)}
                  style={{
                    width: fS(35),
                    height: fS(35),
                    borderRadius: fS(10),
                    position: 'absolute',
                    top: fS(10),
                    right: fS(10),
                    backgroundColor: '#FFF',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  <Image style={styles.heartimg} source={trash} />
                </TouchableOpacity>
              </View>
              <View style={styles.textcont}>
                <Text style={styles.name}>{item?.name}</Text>
                <Text style={styles.amount}>
                  {F.doller}
                  {item?.amount}
                </Text>
                <View style={styles.rew_cont}>
                  <View style={styles.startcont}>
                    <Image source={start} style={styles.start} />
                  </View>
                  <Text style={styles.rate}>{item?.rating}</Text>
                  <Text style={styles.review}>{item?.review}</Text>
                </View>
              </View>
            </View>
          );
        })}
      </View>
    </View>
  );
};

export default FavoritsListComp;

const styles = StyleSheet.create({
  text: {
    fontSize: fS(22),
    fontFamily: F.f5,
    color: C.BLACK,
  },
  cont: {
    paddingHorizontal: fS(25),
    SCREEN_WIDTH,
  },
  list_cont: {
    // width: '100%',
    flexDirection: 'row',
    marginTop: fS(20),
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  img_Cont: {
    width: fS(200),
    height: fS(300),
    // backgroundColor: 'red',
    shadowColor: C.LightGray,
    borderRadius: fS(15),
    shadowOpacity: 1,
    shadowRadius: fS(20),
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 6,
    backgroundColor: C.WHITE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  img: {
    width: fS(120),
    height: fS(120),
    objectFit: 'contain',
    borderRadius: fS(15),
    borderColor: '#d9d9d9',
    borderWidth: 2,
  },
  categorycont: {
    SCREEN_WIDTH,
    position: 'relative',
    marginTop: fS(20),
    gap: fS(10),
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  box_cont: {
    backgroundColor: '#FFF',
    elevation: 5,
    width: '48%',
    borderRadius: fS(20),
    padding: fS(8),
    marginBottom: fS(10),
  },
  box_cont_layer: {
    // height: fS(150),
    // width: '100%',
    // alignSelf: 'center',
  },
  box_cont_layer2: {
    height: fS(163),
    // width: fS(180),
    width: '100%',
    // height: '60%',
    alignSelf: 'center',
  },
  foodimg: {
    height: '100%',
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    objectFit: 'contain',
    borderRadius: fS(15),
  },
  name: {
    fontFamily: F.f5,
    fontSize: fS(16),
    color: C.BLACK,
  },
  amount: {
    fontFamily: F.f4,
    fontSize: fS(15),
    color: C.BLACK,
    paddingVertical: fS(10),
  },
  textcont: {
    marginVertical: fS(10),
  },
  startcont: {
    height: fS(16),
    width: fS(16),
    alignItems: 'center',
    justifyContent: 'center',
  },
  start: {
    height: '100%',
    width: '100%',
    objectFit: 'cover',
  },
  rew_cont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(6),
  },
  rate: {
    fontFamily: F.f4,
    fontSize: fS(14),
    color: C.BLACK,
  },
  review: {
    fontFamily: F.f4,
    fontSize: fS(12),
    color: C.DARK_GRAY,
  },
  imgcont: {
    // height: '100%',
    // width: '100%',
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  heartimg: {
    height: fS(20),
    width: fS(20),
    alignSelf: 'center',
  },
});
