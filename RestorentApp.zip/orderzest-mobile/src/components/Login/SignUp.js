import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
  Pressable,
  Keyboard,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {checkbox, spoon, uncheckbox} from '../../assets/img';
import {C, F} from '../../assets/styles/ColorsFonts';
import {EMAIL, NUMBER, fS} from '../../constants/Loader/Loader';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const SignUp = () => {
  const navigation = useNavigation();
  const [isChecked, setIsChecked] = useState(false);

  const navi = useNavigation();

  // Form state
  const [mobileno, setMobileNo] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [termsCond, setTermsCond] = useState(false);

  //Error State
  const [firstNameErr, setFirstNameErr] = useState(false);
  const [lastNameErr, setLastNameErr] = useState(false);
  const [emailErr, setEmailErr] = useState(false);
  const [btn, setBtn] = useState(false);
  const [mobileNumberErr, setMobileNumberErr] = useState(false);
  const [passwordErr, setPasswordErr] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [validPassErr, setValidPassErr] = useState('');

  const onClickHandler = () => {
    setTermsCond(!termsCond);
  };

  const passwordchange = e => {
    setPassword(e);
    Keyboard.isVisible();
    if (password.length < 8) {
      setPasswordErr(true);
      setPasswordError(false);
      setValidPassErr('Password should be at least 8 characters long');
    } else {
      if (!/\d/.test(e)) {
        setPasswordErr(true);
        setPasswordError(false);

        setValidPassErr('Add at least one number');
      } else {
        if (!/[A-Z]/.test(e) || !/[a-z]/.test(e)) {
          setPasswordErr(true);
          setPasswordError(false);

          setValidPassErr('Include both upper and lower case letters');
        } else {
          if (!/[^A-Za-z0-9]/.test(e)) {
            setPasswordErr(true);
            setPasswordError(false);

            setValidPassErr('Include at least one special character');
          } else {
            setPasswordErr(false);
            setPasswordError(false);
          }
        }
      }
    }
  };

  const onSubmitHandle = () => {
    if (mobileno == 10) {
    }
    if (
      firstName.length < 1 ||
      lastName.length < 1 ||
      NUMBER.test(mobileno) == false ||
      mobileno.length < 10 ||
      email.length == 0 ||
      (password.length == 0 && !passwordErr)
    ) {
      console.log('passwordErr', passwordErr);
      setPasswordError(true);
      setPasswordErr(false);
      setFirstNameErr(true);
      setLastNameErr(true);
      setEmailErr(true);
      setMobileNumberErr(true);
    } else if (!termsCond) {
      console.log('Please agree');
    } else {
      navi.navigate('home');
    }
  };

  const toggleCheckbox = () => {
    setIsChecked(!isChecked);
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: C.PRIMARY_BG}}>
      <ScrollView style={{flex: 1}}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: '10%',
              marginBottom: '5%',
            }}>
            <View
              style={{
                width: '70%',
                height: height / fS(10),
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <View
                style={{
                  width: '100%',
                  height: '97%',
                }}>
                <Image
                  source={spoon}
                  style={{
                    flex: 1,
                    width: undefined,
                    height: undefined,
                    resizeMode: 'contain',
                  }}
                />
              </View>
            </View>
          </View>
          <View style={styles.formcomp}>
            <Text style={styles.signtext}>Create Account</Text>
            <View style={styles.form}>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="First Name"
                  keyboardType="name-phone-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={styles.input}
                  value={firstName}
                  onChangeText={e => {
                    setFirstName(e);
                  }}
                />
                {firstNameErr && firstName.length < 4 && (
                  <Text style={styles.errorText}>Please Enter First Name*</Text>
                )}
              </View>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="Last Name"
                  keyboardType="name-phone-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={styles.input}
                  value={lastName}
                  onChangeText={e => {
                    setLastName(e);
                  }}
                />
                {lastNameErr && lastName.length < 1 && (
                  <Text style={styles.errorText}>Please Enter Last Name*</Text>
                )}
              </View>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="Email"
                  keyboardType="email-address"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={styles.input}
                  value={email}
                  onChangeText={e => {
                    setEmail(e);
                  }}
                />
                {emailErr && EMAIL.test(email) == false && (
                  <Text style={styles.errorText}>Please Enter Email*</Text>
                )}
              </View>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="Mobile number"
                  keyboardType="number-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  maxLength={10}
                  editable={true}
                  style={styles.input}
                  value={mobileno}
                  onChangeText={e => setMobileNo(e)}
                />
                {mobileNumberErr && mobileno.length < 10 && (
                  <Text style={styles.errorText}>
                    Please Enter Mobile number*
                  </Text>
                )}
              </View>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="Password"
                  keyboardType="name-phone-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={styles.input}
                  value={password}
                  onChangeText={passwordchange}
                />
                {passwordError && password.length == 0 && (
                  <Text style={styles.errorText}>Please Enter Password *</Text>
                )}
                {passwordErr && (
                  <Text style={styles.errorText}>{validPassErr}</Text>
                )}
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'flex-start',
                justifyContent: 'center',
                marginHorizontal: fS(25),
                marginTop: fS(20),
              }}>
              <Pressable
                onPress={onClickHandler}
                style={{
                  width: fS(25),
                  height: fS(25),
                  marginRight: fS(10),
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                <Image
                  source={termsCond ? checkbox : uncheckbox}
                  style={styles.chechImg}
                />
              </Pressable>
              <View style={styles.heading}>
                <View style={[styles.headingss]}>
                  <Text style={[styles.headingText]}>
                    By Login you are agreeing to our
                  </Text>
                  <TouchableOpacity>
                    <Text style={styles.headingText1}> Terms of use</Text>
                  </TouchableOpacity>
                </View>
                <View style={styles.headingss}>
                  <Text style={styles.headingText}> and </Text>
                  <TouchableOpacity>
                    <Text style={styles.headingText1}>Privacy policy</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View style={styles.btncont}>
              <TouchableOpacity
                style={styles.btn}
                activeOpacity={0.7}
                onPress={onSubmitHandle}>
                <Text style={styles.btntxt}>Continue</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.bcont}>
              <Text style={[styles.btext, {color: C.BLACK}]}>
                Already have an account?{' '}
              </Text>
              <TouchableOpacity
                activeOpacity={0.6}
                onPress={() => navi.navigate('LoginScreen')}>
                <Text style={[styles.btext, {color: C.PRIMARY}]}>Sign in</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  checkbox: {
    width: 20,
    height: 20,
    borderWidth: 2,
    borderColor: '#000',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
  checkboxChecked: {
    backgroundColor: '#000',
    borderColor: '#000',
  },
  checkmark: {
    color: 'white',
  },
  safView: {
    // flex: 1,
    SCREEN_WIDTH,
    backgroundColor: C.PRIMARY_BG,
    height: '100%',
    alignItems: 'center',
    // justifyContent: 'center',
    paddingTop: fS(100),
  },
  formcomp: {
    // flex: 3,
    width: '100%',
    padding: fS(25),
    marginTop: fS(10),
  },
  container: {
    SCREEN_WIDTH,
  },
  signtext: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(30),
  },
  form: {
    // marginTop: fS(30),
    marginBottom: fS(20),
  },
  labletext: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(22),
  },
  input: {
    width: '100%',
    height: fS(76),
    backgroundColor: C.WHITE,
    borderRadius: fS(20),
    marginTop: fS(35),
    padding: fS(20),
    fontSize: fS(19),
    fontFamily: F.f2,
    color: C.BLACK,
    shadowOpacity: 0.5,
    shadowRadius: fS(20),
    shadowColor: C.LIGHT_GRAY,
    shadowOffset: {
      height: fS(80),
      width: 0,
    },
    elevation: 5,
  },
  errorText: {
    fontFamily: F.f1,
    color: C.RED,
    fontSize: fS(16),
    position: 'absolute',
    bottom: fS(-33),
    right: 0,
  },
  inputcont: {
    position: 'relative',
  },
  forgottxt: {
    fontFamily: F.f3,
    fontSize: fS(23),
    color: C.BLACK,
    textAlign: 'right',
  },
  forgotcont: {
    marginTop: fS(20),
  },
  btncont: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(40),
  },
  btn: {
    width: '100%',
    backgroundColor: C.PRIMARY,
    paddingVertical: fS(22),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(20),
  },
  btntxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(23),
  },
  bcont: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginTop: fS(40),
    marginBottom: fS(50),
  },
  btext: {
    fontFamily: F.f4,
    fontSize: fS(20),
  },
  heading: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  headingss: {
    flexDirection: 'row',
    // flexWrap: 'wrap',
  },
  headingText: {
    fontFamily: F.f4,
    color: C.BLACK,
    fontSize: fS(17),
  },
  headingText1: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(17),
  },
  chechImg: {
    width: '100%',
    height: '100%',
    marginTop: 0,
    // tintColor: C.PRIMARY,
    objectFit: 'contain',
  },
});

export default SignUp;
