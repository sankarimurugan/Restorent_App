import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {spoon} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';

const SignUp = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScrollView style={{flex: 1}}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: '15%',
              marginBottom: '5%',
            }}>
            <View
              style={{
                width: '70%',
                height: height / 9,
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <View
                style={{
                  width: '100%',
                  height: '97%',
                }}>
                <Image
                  source={spoon}
                  style={{
                    flex: 1,
                    width: undefined,
                    height: undefined,
                    resizeMode: 'contain',
                  }}
                />
              </View>
            </View>
          </View>

          <View
            style={{
              width: '100%',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: '90%',
              }}>
              <View style={{marginBottom: '10%'}}>
                <Text
                  style={{fontWeight: '700', fontSize: fS(32), color: '#000'}}>
                  Create Account
                </Text>
              </View>

              <View style={{marginBottom: '3%'}}>
                <Text
                  style={{fontWeight: '700', fontSize: fS(35), color: '#000'}}>
                  Verify OTP
                </Text>
              </View>

              <View style={{marginBottom: '8%'}}>
                <Text
                  style={{fontWeight: '600', fontSize: fS(20), color: '#000'}}>
                  Enter your OTP sent on your mobile number
                </Text>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  marginBottom: '8%',
                  width: '100%',
                }}>
                <View style={{width: '15%'}}>
                  <TextInput
                    style={[
                      {
                        width: '100%',
                        height: fS(75),
                        paddingHorizontal: 15,
                        borderRadius: 10,
                        shadowOpacity: 2,
                        fontSize: fS(23),
                        shadowRadius: 3,
                        shadowOffset: {
                          height: 0,
                          width: 0,
                        },
                        backgroundColor: '#FFF',
                        elevation: 5,
                        borderColor: '#FFD400',
                        borderWidth: 1,
                      },
                    ]}
                    keyboardType="numeric"
                    maxLength={1}
                  />
                </View>
                <View style={{width: '15%', marginLeft: '10%'}}>
                  <TextInput
                    style={[
                      {
                        width: '100%',
                        height: fS(75),
                        paddingHorizontal: 15,
                        borderRadius: 10,
                        shadowOpacity: 2,
                        fontSize: fS(23),
                        shadowRadius: 3,
                        shadowOffset: {
                          height: 0,
                          width: 0,
                        },
                        backgroundColor: '#FFF',
                        elevation: 5,
                        borderColor: '#FFD400',
                        borderWidth: 1,
                      },
                    ]}
                    keyboardType="numeric"
                    maxLength={1}
                  />
                </View>
                <View style={{width: '15%', marginLeft: '10%'}}>
                  <TextInput
                    style={[
                      {
                        width: '100%',
                        height: fS(75),
                        paddingHorizontal: 15,
                        borderRadius: 10,
                        shadowOpacity: 2,
                        fontSize: fS(23),
                        shadowRadius: 3,
                        shadowOffset: {
                          height: 0,
                          width: 0,
                        },
                        backgroundColor: '#FFF',
                        elevation: 5,
                        borderColor: '#FFD400',
                        borderWidth: 1,
                      },
                    ]}
                    keyboardType="numeric"
                    maxLength={1}
                  />
                </View>
                <View style={{width: '15%', marginLeft: '10%'}}>
                  <TextInput
                    style={[
                      {
                        width: '100%',
                        height: fS(75),
                        paddingHorizontal: 15,
                        borderRadius: 10,
                        shadowOpacity: 2,
                        fontSize: fS(23),
                        shadowRadius: 3,
                        shadowOffset: {
                          height: 0,
                          width: 0,
                        },
                        backgroundColor: '#FFF',
                        elevation: 5,
                        borderColor: '#FFD400',
                        borderWidth: 1,
                      },
                    ]}
                    keyboardType="numeric"
                    maxLength={1}
                  />
                </View>
              </View>

              <View style={{justifyContent: 'center', marginBottom: '6%'}}>
                <Text
                  style={{
                    color: '#000',
                    fontSize: fS(20),
                    fontWeight: '400',
                  }}>
                  Didn’t receive the OTP,{' '}
                  <Text
                    style={{
                      color: '#FFD400',
                      fontSize: fS(20),
                      fontWeight: '500',
                    }}>
                    Resend OTP
                  </Text>{' '}
                  <Text
                    style={{
                      color: '#000',
                      fontSize: fS(20),
                      fontWeight: '500',
                    }}>
                    in 58 sec
                  </Text>
                </Text>
              </View>
              <TouchableOpacity
                onPress={() => navigation.navigate('NewPassword')}
                style={{
                  width: '100%',
                  padding: 12,
                  backgroundColor: '#FFD400',
                  borderRadius: 10,
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginBottom: '3%',
                }}>
                <Text
                  style={[
                    {
                      color: '#000',
                      fontSize: fS(22),
                      fontWeight: '700',
                    },
                  ]}>
                  Verify
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default SignUp;
