import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {spoon} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

const NewPassword = () => {
  const navigation = useNavigation();

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <View
        style={{
          width: '100%',
          flex: 1,
        }}>
        <View
          style={{
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: '15%',
            marginBottom: '12%',
          }}>
          <View
            style={{
              width: '70%',
              height: height / 9,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <View
              style={{
                width: '100%',
                height: '97%',
              }}>
              <Image
                source={spoon}
                style={{
                  flex: 1,
                  width: undefined,
                  height: undefined,
                  resizeMode: 'contain',
                }}
              />
            </View>
          </View>
          <View style={{marginBottom: 10}}>
            <Text style={{fontWeight: '700', fontSize: 20, color: '#000'}}>
              OrderZest
            </Text>
          </View>
          <View style={{}}>
            <Text style={{fontWeight: '500', fontSize: 14, color: '#000'}}>
              “Where Every Meal is a Celebration”
            </Text>
          </View>
        </View>

        <View
          style={{
            width: '100%',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '90%',
            }}>
            <View style={{marginBottom: 20}}>
              <Text
                style={{fontWeight: '700', fontSize: fS(22), color: '#000'}}>
                New Password
              </Text>
            </View>

            <View
              style={[
                {
                  width: '100%',
                  height: height / 14,
                  paddingHorizontal: 10,
                  borderRadius: 10,
                  shadowOpacity: 2,
                  shadowRadius: 3,
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  backgroundColor: '#FFF',
                  elevation: 3,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '5%',
                },
              ]}>
              <View>
                <TextInput
                  placeholderTextColor="#CDCDCD"
                  placeholder="Enter the Password"
                  secureTextEntry={true}
                  style={{
                    flex: 1,
                    marginLeft: 5,
                    fontSize: fS(20),
                    fontWeight: '500',
                  }}
                />
              </View>
              <View>
                <MaterialCommunityIcons
                  name="eye-off"
                  color="#000"
                  size={height / 35}
                />
              </View>
            </View>

            <View style={{marginBottom: 20}}>
              <Text
                style={{fontWeight: '700', fontSize: fS(22), color: '#000'}}>
                Confirm Password
              </Text>
            </View>

            <View
              style={[
                {
                  width: '100%',
                  height: height / 14,
                  paddingHorizontal: 10,
                  borderRadius: 10,
                  shadowOpacity: 2,
                  shadowRadius: 3,
                  shadowOffset: {
                    height: 0,
                    width: 0,
                  },
                  backgroundColor: '#FFF',
                  elevation: 3,
                  flexDirection: 'row',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  marginBottom: '15%',
                },
              ]}>
              <View>
                <TextInput
                  placeholderTextColor="#CDCDCD"
                  placeholder="Enter the Password"
                  secureTextEntry={true}
                  style={{
                    flex: 1,
                    marginLeft: 5,
                    fontSize: fS(20),
                    fontWeight: '500',
                  }}
                />
              </View>
              <View>
                <MaterialCommunityIcons
                  name="eye-off"
                  color="#000"
                  size={height / 35}
                />
              </View>
            </View>

            <TouchableOpacity
              onPress={() => navigation.navigate('home')}
              style={{
                width: '100%',
                padding: 12,
                backgroundColor: '#FFD400',
                borderRadius: 10,
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <Text
                style={[
                  {
                    color: '#000',
                    fontSize: 16,
                    fontWeight: '700',
                  },
                ]}>
                Register
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default NewPassword;
