import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  Keyboard,
  StyleSheet,
  BackHandler,
  Alert,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

import {useNavigation, useRoute} from '@react-navigation/native';
import {spoon} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const LoginScreen = () => {
  const navi = useNavigation();
  const location = useRoute();
  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');

  // Error State

  const [userNameErr, setUserNameErr] = useState(false);
  const [passwordErr, setPasswordErr] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [validPassErr, setValidPassErr] = useState('');

  const onSubmitHandle = () => {
    if (userName.length < 1 || (password.length == 0 && !passwordErr)) {
      console.log('passwordErr', passwordErr);
      console.log('userNameErr', userNameErr);
      setUserNameErr(true);
      setPasswordError(true);
      setPasswordErr(false);
    } else {
      if (validPassErr == '') {
        setPasswordErr(false);
        setPasswordError(false);
        navi.navigate('home');
      }
    }
    console.log(validPassErr);
  };
  const userNamechange = e => {
    setUserName(e);
    Keyboard.isVisible();
    if (e.length < 1) {
      setUserNameErr(true);
    } else {
      setUserNameErr(false);
    }
  };

  const passwordchange = e => {
    setPassword(e);
    Keyboard.isVisible();
    if (password.length < 8) {
      setPasswordErr(true);
      setPasswordError(false);
      setValidPassErr('Password should be at least 8 characters long');
    } else {
      if (!/\d/.test(e)) {
        setPasswordErr(true);
        setPasswordError(false);

        setValidPassErr('Add at least one number');
      } else {
        if (!/[A-Z]/.test(e) || !/[a-z]/.test(e)) {
          setPasswordErr(true);
          setPasswordError(false);

          setValidPassErr('Include both upper and lower case letters');
        } else {
          if (!/[^A-Za-z0-9]/.test(e)) {
            setPasswordErr(true);
            setPasswordError(false);

            setValidPassErr('Include at least one special character');
          } else {
            setPasswordErr(false);
            setPasswordError(false);
            setValidPassErr('');
            Keyboard.dismiss();
          }
        }
      }
    }
  };

  useEffect(() => {
    if (location?.name === 'LoginScreen') {
      const backAction = () => {
        Alert.alert('Exit App', 'Do you want to exit the app?', [
          {
            text: 'Cancel',
            onPress: () => null,
            style: 'cancel',
          },
          {
            text: 'Exit',
            onPress: () => BackHandler.exitApp(),
          },
        ]);
        return true;
      };
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        backAction,
      );
      return () => backHandler.remove();
    }
  }, [navi]);
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScrollView
        contentContainerStyle={{paddingBottom: fS(10)}}
        showsVerticalScrollIndicator={false}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              marginTop: '15%',
              marginBottom: '5%',
            }}>
            <View
              style={{
                width: '70%',
                height: SCREEN_HEIGHT / 9,
                alignItems: 'center',
                justifyContent: 'center',
              }}>
              <View
                style={{
                  width: '100%',
                  height: '97%',
                }}>
                <Image
                  source={spoon}
                  style={{
                    flex: 1,
                    width: undefined,
                    height: undefined,
                    resizeMode: 'contain',
                  }}
                />
              </View>
            </View>
            <View style={{marginBottom: fS(20)}}>
              <Text style={styles.logoname}>OrderZest</Text>
            </View>
            <View style={{}}>
              <Text style={styles.distext}>
                “Where Every Meal is a Celebration”
              </Text>
            </View>
          </View>

          <View style={styles.formcomp}>
            <Text style={styles.signtext}>Sign in</Text>
            <View style={styles.form}>
              <Text style={styles.labletext}>
                Enter your email and password
              </Text>
              <View style={styles.inputcont}>
                <TextInput
                  placeholder="Enter your Username"
                  keyboardType="name-phone-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={styles.input}
                  value={userName}
                  onChangeText={userNamechange}
                />
                {userNameErr && userName.length < 1 && (
                  <Text style={styles.errorText}>Please Enter Username *</Text>
                )}
              </View>
              <View style={[styles.inputcont, {marginBottom: fS(30)}]}>
                <TextInput
                  placeholder="Password"
                  keyboardType="name-phone-pad"
                  placeholderTextColor={C.LIGHT_GRAY}
                  autoComplete="off"
                  editable={true}
                  style={[styles.input]}
                  value={password}
                  onChangeText={passwordchange}
                />
                {passwordError && password.length == 0 && (
                  <Text style={styles.errorText}>Please Enter Password *</Text>
                )}
                {passwordErr && (
                  <Text style={styles.errorText}>{validPassErr}</Text>
                )}
              </View>
            </View>
            <TouchableOpacity
              onPress={() => navi.navigate('forgot_password')}
              activeOpacity={0.7}
              style={styles.forgotcont}>
              <Text style={styles.forgottxt}>Forgot Password</Text>
            </TouchableOpacity>
            <View style={styles.btncont}>
              <TouchableOpacity
                style={styles.btn}
                activeOpacity={0.7}
                onPress={onSubmitHandle}>
                <Text style={styles.btntxt}>Continue</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.bcont}>
              <Text style={[styles.btext, {color: C.BLACK}]}>
                Don’t have an account?{' '}
              </Text>
              <TouchableOpacity
                activeOpacity={0.6}
                onPress={() => navi.navigate('SignUp')}>
                <Text style={[styles.btext, {color: C.PRIMARY}]}>Sign up</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

export default LoginScreen;

const styles = StyleSheet.create({
  safView: {
    // flex: 1,
    SCREEN_WIDTH,
    backgroundColor: C.PRIMARY_BG,
    height: '100%',
    alignItems: 'center',
    // justifyContent: 'center',
    paddingTop: fS(100),
  },
  formcomp: {
    // flex: 3,
    width: '100%',
    padding: fS(25),
  },
  container: {
    SCREEN_WIDTH,
  },
  signtext: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(30),
  },
  form: {
    marginTop: fS(20),
  },
  labletext: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(20),
  },
  input: {
    width: '100%',
    height: fS(76),
    backgroundColor: C.WHITE,
    borderRadius: fS(20),
    marginTop: fS(40),
    padding: fS(20),
    fontSize: fS(19),
    fontFamily: F.f2,
    color: C.BLACK,
    shadowOpacity: 0.5,
    shadowRadius: fS(20),
    shadowColor: C.LIGHT_GRAY,
    shadowOffset: {
      height: fS(80),
      width: 0,
    },
    elevation: 5,
  },
  errorText: {
    fontFamily: F.f1,
    color: C.RED,
    fontSize: fS(14),
    position: 'absolute',
    bottom: fS(-33),
    right: 0,
  },
  inputcont: {
    position: 'relative',
  },
  forgottxt: {
    fontFamily: F.f3,
    fontSize: fS(20),
    color: C.BLACK,
    textAlign: 'right',
  },
  forgotcont: {
    // marginVertical: fS(15),
    marginTop: fS(5),
    marginBottom: fS(20),
  },
  btncont: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(10),
  },
  btn: {
    width: '100%',
    backgroundColor: C.PRIMARY,
    paddingVertical: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(20),
  },
  btntxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(23),
  },
  bcont: {
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    marginTop: fS(30),
  },
  btext: {
    fontFamily: F.f4,
    fontSize: fS(20),
  },
  logoname: {
    fontFamily: F.f6,
    color: C.BLACK,
    fontSize: fS(30),
    // marginVertical: fS(10),
  },
  distext: {
    fontFamily: F.f4,
    color: C.BLACK,
    fontSize: fS(20),
    // marginVertical: fS(15),
  },
});
