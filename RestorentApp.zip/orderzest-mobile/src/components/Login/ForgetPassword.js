import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
  Keyboard,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {spoon} from '../../assets/img';
import {EMAIL, fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const ForgetPassword = () => {
  const navi = useNavigation('');
  const [email, setEmail] = useState('');

  // Error
  const [emailErr, setEmailErr] = useState(false);
  const [emailError, setEmailError] = useState(false);

  const onSubmitHandle = () => {
    if (email.length == 0) {
      setEmailError(true);
      setEmailErr(false);
    } else {
      if (EMAIL.test(email) == false && email != '') {
        setEmailError(false);
        setEmailErr(true);
      } else {
        navi.navigate('OtpScreen');
      }
    }
  };

  const emailrextChange = e => {
    setEmail(e);
    Keyboard.isVisible();
    if (EMAIL.test(e) == false && e != '') {
      setEmailErr(true);
      setEmailError(false);
    } else {
      setEmailErr(false);
      setEmailError(false);
    }
  };
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: C.PRIMARY_BG}}>
      <View
        style={{
          width: '100%',
          flex: 1,
        }}>
        <View
          style={{
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: fS(50),
          }}>
          <View
            style={{
              width: '70%',
              height: SCREEN_HEIGHT / 9,
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <View
              style={{
                width: '100%',
                height: '97%',
              }}>
              <Image
                source={spoon}
                style={{
                  flex: 1,
                  width: undefined,
                  height: undefined,
                  resizeMode: 'contain',
                }}
              />
            </View>
          </View>
          <View style={{marginBottom: fS(20)}}>
            <Text style={styles.logoname}>OrderZest</Text>
          </View>
          <View style={{}}>
            <Text style={styles.distext}>
              “Where Every Meal is a Celebration”
            </Text>
          </View>
        </View>
        <View style={styles.formcomp}>
          <Text style={styles.signtext}>Forgot Password</Text>
          <View style={styles.form}>
            <View style={[styles.inputcont, {marginBottom: fS(30)}]}>
              <TextInput
                placeholder="Enter your Email"
                keyboardType="name-phone-pad"
                placeholderTextColor={C.LIGHT_GRAY}
                autoComplete="off"
                editable={true}
                style={[styles.input]}
                onChangeText={emailrextChange}
                value={email}
              />
              {emailErr && (
                <Text style={styles.errorText}>Please Enter valid email *</Text>
              )}
              {emailError && (
                <Text style={styles.errorText}> Please Enter Your Email*</Text>
              )}
            </View>
          </View>
          <View style={styles.bcont}>
            <Text style={[styles.btext, {color: C.BLACK}]}>
              Please Enter your{' '}
            </Text>
            <TouchableOpacity
              activeOpacity={0.6}
              onPress={() => navi.navigate('phone_verify')}>
              <Text style={[styles.btext, {color: C.PRIMARY}]}>
                Mobile number
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.btncont}>
            <TouchableOpacity
              style={styles.btn}
              activeOpacity={0.7}
              onPress={onSubmitHandle}>
              <Text style={styles.btntxt}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  checkbox: {
    width: 17,
    height: 17,
    borderWidth: 1,
    borderColor: 'grey',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 5,
  },
  checkboxChecked: {
    backgroundColor: '#FFD400',
    borderColor: '#FFD400',
  },
  checkmark: {
    color: 'white',
  },
  safView: {
    // flex: 1,
    SCREEN_WIDTH,
    backgroundColor: C.PRIMARY_BG,
    height: '100%',
    alignItems: 'center',
    // justifyContent: 'center',
    paddingTop: fS(100),
  },
  formcomp: {
    // flex: 3,
    width: '100%',
    padding: fS(25),
  },
  container: {
    SCREEN_WIDTH,
  },
  signtext: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(30),
  },
  form: {
    // marginTop: fS(10),
  },
  labletext: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(22),
  },
  input: {
    width: '100%',
    height: fS(76),
    backgroundColor: C.WHITE,
    borderRadius: fS(20),
    marginTop: fS(40),
    padding: fS(20),
    fontSize: fS(19),
    fontFamily: F.f2,
    color: C.BLACK,
    shadowOpacity: 0.5,
    shadowRadius: fS(20),
    shadowColor: C.LIGHT_GRAY,
    shadowOffset: {
      height: fS(80),
      width: 0,
    },
    elevation: 5,
  },
  errorText: {
    fontFamily: F.f1,
    color: C.RED,
    fontSize: fS(16),
    position: 'absolute',
    bottom: fS(-33),
    right: 0,
  },
  inputcont: {
    position: 'relative',
  },
  forgottxt: {
    fontFamily: F.f3,
    fontSize: fS(23),
    color: C.BLACK,
    textAlign: 'right',
  },
  forgotcont: {
    marginTop: fS(20),
  },
  btncont: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: fS(40),
  },
  btn: {
    width: '100%',
    backgroundColor: C.PRIMARY,
    paddingVertical: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: fS(20),
  },
  btntxt: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(23),
  },
  bcont: {
    // alignItems: 'center',
    // justifyContent: 'center',
    flexDirection: 'row',
    // marginTop: fS(30),
  },
  btext: {
    fontFamily: F.f4,
    fontSize: fS(19),
  },
  logoname: {
    fontFamily: F.f6,
    color: C.BLACK,
    fontSize: fS(30),
    // marginVertical: fS(10),
  },
  distext: {
    fontFamily: F.f4,
    color: C.BLACK,
    fontSize: fS(20),
    // marginVertical: fS(15),
  },
});

export default ForgetPassword;
