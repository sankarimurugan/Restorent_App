import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
} from 'react-native';
import React, {useEffect} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {
  empty_reservation,
  left,
  leftarrow,
  location,
  pic,
  plate,
  spoon,
} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {F} from '../../assets/styles/ColorsFonts';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');
const EmptyRecervationComp = ({setActive, active}) => {
  const navi = useNavigation();
  return (
    <View
      style={{
        flex: 8,
        alignItems: 'center',
        justifyContent: 'center',
        SCREEN_HEIGHT,
        SCREEN_WIDTH,
      }}>
      <View
        style={{
          width: fS(200),
          height: fS(170),
          alignItems: 'center',
          justifyContent: 'center',
        }}>
        <Image
          source={empty_reservation}
          style={{
            resizeMode: 'contain',
            height: '100%',
            width: '100%',
          }}
        />
      </View>
      <View style={{marginBottom: '3%', marginTop: '5%'}}>
        <Text style={{fontFamily: F.f5, fontSize: fS(24), color: '#252525'}}>
          Empty Reservation
        </Text>
      </View>
      <View style={{marginBottom: '3%'}}>
        <Text style={{fontFamily: F.f3, fontSize: fS(17), color: '#252525'}}>
          There are no reservations to display.
        </Text>
      </View>
      <TouchableOpacity
        // onPress={() => navi.navigate('TableReservation')}
        onPress={() => setActive(!active)}
        style={{
          backgroundColor: '#FFD400',
          borderRadius: 10,
          alignItems: 'center',
          justifyContent: 'center',
          flexDirection: 'row',
          padding: 12,
          width: '40%',
          marginTop: fS(20),
        }}>
        <View>
          <Text
            style={{
              fontFamily: F.f5,
              fontSize: fS(18),
              color: '#252525',
            }}>
            Reserve now
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default EmptyRecervationComp;
