import {Image, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {food1, start, trash} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import {F} from '../../assets/styles/ColorsFonts';

const CartListComp = ({productList, seDlt}) => {
  return (
    <View
      style={{
        width: '100%',
        flex: 1,
      }}>
      <View
        style={{
          width: '100%',
          alignItems: 'center',
          flex: 1,
        }}>
        {productList.map((food, index) => (
          <View
            style={[
              {
                width: '93%',
                borderRadius: 20,
                elevation: 5,
                backgroundColor: '#FFF',
                padding: 10,
                marginBottom: '5%',
              },
            ]}
            key={index}>
            <View
              style={{
                width: '100%',
              }}>
              <View
                style={{
                  width: '100%',
                  flexDirection: 'row',
                }}>
                <View
                  style={{
                    width: '45%',
                  }}>
                  <View
                    style={{
                      width: '100%',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}>
                    <Image
                      source={food1}
                      style={{
                        width: '100%',
                        height: fS(150),
                        resizeMode: 'stretch',
                        borderRadius: fS(15),
                      }}
                    />
                  </View>
                </View>

                <View
                  style={{
                    width: '55%',
                  }}>
                  <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                    <Text
                      style={{
                        fontSize: fS(20),
                        color: '#252525',
                        fontFamily: F.f5,
                      }}>
                      {food.name}
                    </Text>
                  </View>
                  <View style={{marginTop: '4%', marginHorizontal: '6%'}}>
                    <Text
                      style={{
                        fontSize: fS(15),
                        color: '#252525',
                        fontFamily: F.f4,
                      }}>
                      {food.rate}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      alignItems: 'flex-end',
                      justifyContent: 'flex-end',
                    }}>
                    <View
                      style={{
                        width: '70%',
                        height: fS(50),
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        backgroundColor: '#FFF',
                        borderRadius: 10,
                        elevation: 5,
                        padding: 8,
                        marginTop: '4%',
                        marginHorizontal: '6%',
                        shadowColor: 'black',
                        shadowOffset: {
                          width: 7,
                          height: 7,
                        },
                        shadowOpacity: 0.5,
                        shadowRadius: 5,
                      }}>
                      <TouchableOpacity
                        style={{
                          width: fS(30),
                          height: fS(30),
                          backgroundColor: '#F5F5F5',
                          borderRadius: fS(5),
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}>
                        <Text
                          style={{
                            fontSize: fS(17),
                            color: '#252525',
                            fontFamily: F.f5,
                          }}>
                          -
                        </Text>
                      </TouchableOpacity>
                      <Text
                        style={{
                          fontSize: fS(20),
                          color: '#252525',
                          fontFamily: F.f5,
                        }}>
                        01
                      </Text>
                      <TouchableOpacity
                        style={{
                          width: fS(30),
                          height: fS(30),
                          backgroundColor: '#FFD400',
                          borderRadius: 5,
                          alignItems: 'center',
                          justifyContent: 'center',
                          borderRadius: fS(5),
                        }}>
                        <Text
                          style={{
                            fontSize: fS(17),
                            color: '#252525',
                            fontFamily: F.f4,
                            textAlignVertical: 'center',
                            textAlign: 'center',
                          }}>
                          +
                        </Text>
                      </TouchableOpacity>
                    </View>
                    <TouchableOpacity
                      onPress={() => seDlt()}
                      style={{marginBottom: fS(10)}}>
                      <Image source={trash} />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
};

export default CartListComp;

const styles = StyleSheet.create({});
