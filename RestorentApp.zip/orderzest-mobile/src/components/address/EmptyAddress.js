import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
} from 'react-native';
import React, {useEffect} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation} from '@react-navigation/native';
import {left, leftarrow, location, pic, plate, spoon} from '../../assets/img';
import {fS} from '../../constants/Loader/Loader';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {F} from '../../assets/styles/ColorsFonts';

const EmptyAddress = () => {
  const navigation = useNavigation();
  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <View
        style={{
          width: '100%',
          flex: 1,
        }}>
        <ScreenHeaderComp headername={'Address'} />
        <View
          style={{
            flex: 0.9,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <View style={{}}>
            <Image
              source={location}
              style={{
                width: fS(200),
                height: fS(140),
                resizeMode: 'contain',
              }}
            />
          </View>
          <View style={{marginBottom: '3%', marginTop: '5%'}}>
            <Text
              style={{fontFamily: F.f5, fontSize: fS(24), color: '#252525'}}>
              Add Address
            </Text>
          </View>
          <View style={{marginBottom: '3%'}}>
            <Text
              style={{fontFamily: F.f3, fontSize: fS(17), color: '#252525'}}>
              No address has been added.
            </Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('AddAddress')}
            style={{
              backgroundColor: '#FFD400',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              padding: 12,
              width: '40%',
              marginTop: fS(20),
            }}>
            <View>
              <Text
                style={{
                  fontFamily: F.f5,
                  fontSize: fS(18),
                  color: '#252525',
                }}>
                + Add address
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

export default EmptyAddress;
