import {
  View,
  Text,
  Dimensions,
  Image,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  TextInput,
  StyleSheet,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {SafeAreaView} from 'react-native-safe-area-context';

const {height} = Dimensions.get('window');
import {useNavigation, useRoute} from '@react-navigation/native';
import {leftarrow, location, locationicon, spoon} from '../../assets/img';
import {NUMBER, fS} from '../../constants/Loader/Loader';
import ScreenHeaderComp from '../Header/ScreenHeaderComp';
import {C, F} from '../../assets/styles/ColorsFonts';

const AddAddress = () => {
  const navi = useNavigation();
  const loc = useRoute();
  const Edit = loc?.params?.edit;
  const [checkbox1Selected, setCheckbox1Selected] = useState(false);
  const [checkbox2Selected, setCheckbox2Selected] = useState(false);
  const [inputDiss, setInputDiss] = useState(true);

  // Form States
  const [name, setName] = useState('');
  const [phoneNo, setPhoneNo] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [altPhonNo, setAltPhoneNo] = useState('');

  // Form ErrStates
  const [nameErr, setNameErr] = useState(false);
  const [phoneNoErr, setPhoneNoErr] = useState(false);
  const [addressErr, setAddressErr] = useState(false);
  const [cityErr, setCityErr] = useState(false);
  const [stateErr, setStateErr] = useState(false);
  const [zipCodeErr, setZipCodeErr] = useState(false);
  const [validPhonNoErr, setValidPhoneNoErr] = useState(false);

  const toggleCheckbox1 = () => {
    setCheckbox1Selected(true);
    setCheckbox2Selected(false);
  };

  const toggleCheckbox2 = () => {
    setCheckbox1Selected(false);
    setCheckbox2Selected(true);
  };

  const onSubmit = () => {
    if (
      name?.length < 1 ||
      phoneNo < 10 ||
      address.length < 1 ||
      city.length < 1 ||
      state.length < 1 ||
      zipCode.length < 4 ||
      NUMBER.test(phoneNo) == false
    ) {
      setNameErr(true);
      setPhoneNoErr(true);
      setAddressErr(true);
      setCityErr(true);
      setStateErr(true);
      setZipCodeErr(true);
      setValidPhoneNoErr(true);
    } else {
      console.log('Success');
      if (loc?.params?.type == 'saved') {
        navi.navigate('savedaddress', {list: true});
      } else {
        navi.navigate('address', {list: true});
      }
    }
  };

  useEffect(() => {
    if (Edit) {
      setName('Stella Chrish');
      setPhoneNo('9876543210');
      setAddress('132, My Street');
      setCity('Kingston');
      setState('New York');
      setZipCode('12401');
      setAltPhoneNo('98765 43322');
      setInputDiss(true);
    } else {
      setName('');
      setPhoneNo('');
      setAddress('');
      setCity('');
      setState('');
      setZipCode('');
      setAltPhoneNo('');
    }
  }, [Edit]);

  return (
    <SafeAreaView style={{flex: 1, backgroundColor: '#FCFBF4'}}>
      <ScreenHeaderComp headername={' Add Address'} />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{paddingBottom: fS(15)}}>
        <View
          style={{
            width: '100%',
            flex: 1,
          }}>
          <View
            style={{
              width: '100%',
              alignItems: 'center',
            }}>
            <View
              style={{
                width: '90%',
              }}>
              <TouchableOpacity
                onPress={() => navi.navigate('setlocation')}
                style={{
                  backgroundColor: '#FFD400',
                  alignItems: 'center',
                  flexDirection: 'row',
                  paddingVertical: fS(15),
                  paddingHorizontal: fS(15),
                  borderRadius: fS(15),
                  marginTop: fS(20),
                  gap: fS(10),
                }}>
                <View>
                  <Image
                    source={locationicon}
                    style={{
                      width: fS(21),
                      height: fS(21),
                      resizeMode: 'contain',
                    }}
                  />
                </View>
                <Text
                  style={{
                    fontSize: fS(20),
                    color: '#252525',
                    fontFamily: F.f5,
                  }}>
                  Use my current location
                </Text>
              </TouchableOpacity>
              <View style={{marginTop: fS(20)}}>
                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="Name"
                    value={name}
                    onChangeText={e => setName(e)}
                    editable={inputDiss}
                  />
                  {nameErr && name.length < 4 && (
                    <Text style={styles.errorText}>Please Enter Name*</Text>
                  )}
                </View>
                <View style={{marginVertical: fS(20), position: 'relative'}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="Mobile number"
                    value={phoneNo}
                    onChangeText={e => setPhoneNo(e)}
                    maxLength={10}
                    keyboardType="number-pad"
                    editable={inputDiss}
                  />
                  {phoneNoErr && phoneNo.length < 10 && (
                    <Text style={styles.errorText}>
                      Please Enter Mobile number*
                    </Text>
                  )}
                  {validPhonNoErr &&
                    phoneNoErr &&
                    NUMBER.test(phoneNo) == false &&
                    phoneNo.length == 10 && (
                      <Text style={styles.errorText}>
                        Please Enter Valid Mobile number*
                      </Text>
                    )}
                </View>

                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="Address"
                    value={address}
                    onChangeText={e => setAddress(e)}
                    editable={inputDiss}
                  />
                  {addressErr && address.length < 1 && (
                    <Text style={styles.errorText}>Please Enter Address*</Text>
                  )}
                </View>

                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="City"
                    value={city}
                    onChangeText={e => setCity(e)}
                    editable={inputDiss}
                  />
                  {cityErr && city.length < 1 && (
                    <Text style={styles.errorText}>Please Enter City*</Text>
                  )}
                </View>

                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="State"
                    value={state}
                    onChangeText={e => setState(e)}
                    editable={inputDiss}
                  />
                  {stateErr && state.length < 1 && (
                    <Text style={styles.errorText}>Please Enter State*</Text>
                  )}
                </View>

                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="ZIP Code"
                    value={zipCode}
                    keyboardType="number-pad"
                    maxLength={8}
                    onChangeText={e => setZipCode(e)}
                    editable={inputDiss}
                  />
                  {zipCodeErr && zipCode.length < 4 && (
                    <Text style={styles.errorText}>Please Enter ZIP Code*</Text>
                  )}
                </View>

                <View style={{marginVertical: fS(20)}}>
                  <TextInput
                    style={styles.inputcont}
                    placeholderTextColor="#CDCDCD"
                    placeholder="Alternate Phone (Optional)"
                    editable={inputDiss}
                    value={altPhonNo}
                    onChangeText={e => setAltPhoneNo(e)}
                  />
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: '5%',
                  marginTop: fS(20),
                }}>
                <View>
                  <Text
                    style={{
                      fontSize: fS(19),
                      color: '#252525',
                      fontFamily: F.f4,
                    }}>
                    Address Type
                  </Text>
                </View>
                <View style={{marginLeft: 5}}>
                  <Text
                    style={{
                      fontSize: fS(15),
                      color: '#252525',
                      fontFamily: F.f3,
                    }}>
                    (Optional)
                  </Text>
                </View>
              </View>

              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: fS(20),
                }}>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <TouchableOpacity
                    style={[
                      styles.checkbox,
                      checkbox1Selected
                        ? {borderColor: '#0A7AFF'}
                        : {borderColor: '#636366'},
                    ]}
                    onPress={toggleCheckbox1}>
                    {checkbox1Selected && (
                      // <Text style={styles.checkmark}>✓</Text>
                      <View
                        style={{
                          height: fS(15),
                          width: fS(15),
                          backgroundColor: '#0A7AFF',
                          borderRadius: fS(10),
                          alignSelf: 'center',
                        }}
                      />
                    )}
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontSize: fS(18),
                      color: '#252525',
                      fontFamily: F.f4,
                    }}>
                    Home
                  </Text>
                </View>
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <TouchableOpacity
                    style={[
                      styles.checkbox,
                      ,
                      checkbox2Selected
                        ? {borderColor: '#0A7AFF'}
                        : {borderColor: '#636366'},
                    ]}
                    onPress={toggleCheckbox2}>
                    {checkbox2Selected && (
                      <View
                        style={{
                          height: fS(15),
                          width: fS(15),
                          backgroundColor: '#0A7AFF',
                          borderRadius: fS(10),
                          alignSelf: 'center',
                        }}
                      />
                    )}
                  </TouchableOpacity>
                  <Text
                    style={{
                      fontSize: fS(18),
                      color: '#252525',
                      fontFamily: F.f4,
                    }}>
                    Work
                  </Text>
                </View>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
      <View
        style={{
          flexDirection: 'row',
          width: '100%',
          marginBottom: '5%',
          paddingHorizontal: fS(20),
          paddingVertical: fS(20),
          borderTopRightRadius: fS(20),
          borderTopLeftRadius: fS(20),
        }}>
        <View
          style={{
            justifyContent: 'space-between',
            flexDirection: 'row',
            width: '100%',
          }}>
          <TouchableOpacity
            onPress={() => navi.goBack()}
            style={{
              backgroundColor: '#A4A4A4',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              padding: 12,
              width: '45%',
            }}>
            <Text
              style={{
                fontSize: fS(21),
                color: '#FFF',
                fontFamily: F.f5,
              }}>
              Cancel
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={onSubmit}
            style={{
              backgroundColor: '#FFD400',
              borderRadius: 10,
              alignItems: 'center',
              justifyContent: 'center',
              flexDirection: 'row',
              padding: 12,
              width: '45%',
            }}>
            <Text
              style={{
                fontSize: fS(21),
                color: '#000',
                fontFamily: F.f5,
              }}>
              Save
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  checkbox: {
    width: fS(30),
    height: fS(30),
    borderRadius: 15,
    borderWidth: 2,
    borderColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 5,
    marginLeft: 5,
  },
  selected: {
    backgroundColor: '#0A7AFF',
    borderColor: '#0A7AFF',
  },
  checkmark: {
    color: 'white',
  },
  inputcont: {
    width: '100%',
    borderRadius: fS(15),
    paddingVertical: fS(15),
    paddingHorizontal: fS(20),
    fontSize: fS(18),
    fontFamily: F.f3,
    shadowOpacity: 2,
    shadowRadius: 3,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    backgroundColor: '#FFF',
    elevation: 3,
    color: C.BLACK,
  },
  errorText: {
    fontFamily: F.f1,
    color: C.RED,
    fontSize: fS(14),
    position: 'absolute',
    bottom: fS(-33),
    right: 0,
  },
});

export default AddAddress;
