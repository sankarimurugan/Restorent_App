import {View, Text} from 'react-native';
const AddressEditPage = () => {
  return (
    <View>
      <Text>AddressEditPage</Text>
    </View>
  );
};
export default AddressEditPage;
