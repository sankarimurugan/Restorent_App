import {
  Dimensions,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useState} from 'react';
import {fS} from '../../constants/Loader/Loader';
import {C, F} from '../../assets/styles/ColorsFonts';
import {dotes, home, house} from '../../assets/img';
import {address_list, product_list} from '../../redux/api/DummyJson';
import {useNavigation} from '@react-navigation/native';

const {height: SCREEN_HEIGHT, width: SCREEN_WIDTH} = Dimensions.get('window');

const AddressListComp = ({addresList, setAddressList}) => {
  const navi = useNavigation();
  const [dropdown, setDropDown] = useState(undefined);

  const menufun = ind => {
    if (dropdown == ind) {
      setDropDown(null);
    } else {
      setDropDown(ind);
    }
  };

  const addressDeleter = ind => {
    const updatedList = [...addresList];
    updatedList.splice(ind, 1);
    setAddressList(updatedList);
  };
  return (
    <View style={styles.cont}>
      <View style={styles.listcont}>
        {addresList?.map((item, ind) => {
          return (
            <View style={styles.box}>
              <View style={styles.topcont}>
                <TouchableOpacity style={styles.btn}>
                  <View style={styles.imgcont}>
                    <Image source={item?.icon} style={styles.img} />
                  </View>
                  <Text style={styles.text}>{item?.iconName}</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => menufun(ind)}
                  style={styles.dotecont}>
                  <View style={styles.imgcont}>
                    <Image source={dotes} style={styles.img} />
                  </View>
                </TouchableOpacity>
              </View>
              <View style={styles.textcont}>
                <Text style={styles.lefttext}>{item?.name}</Text>
                <Text style={styles.righttext}>{item?.no}</Text>
              </View>
              <Text style={styles.righttext}>{item?.address}</Text>
              {dropdown === ind && (
                <View style={styles.menu}>
                  <TouchableOpacity
                    style={styles.btncont}
                    onPress={() => {
                      menufun(ind);
                      navi.navigate('AddAddress', {edit: true});
                    }}>
                    <Text style={styles.menutxt}>Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      addressDeleter(ind);
                      menufun(ind);
                    }}
                    style={styles.btncont}>
                    <Text style={styles.menutxt}>Delete</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          );
        })}
      </View>
    </View>
  );
};

export default AddressListComp;

const styles = StyleSheet.create({
  cont: {
    marginBottom: fS(30),
  },
  listcont: {
    marginHorizontal: fS(25),
  },
  box: {
    padding: fS(10),
    elevation: 10,
    backgroundColor: C.WHITE,
    width: SCREEN_WIDTH / 1.1,
    borderRadius: fS(10),
    marginVertical: fS(20),
    position: 'relative',
  },
  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: fS(7),
    backgroundColor: C.PRIMARY,
    paddingHorizontal: fS(10),
    paddingVertical: fS(5),
    borderRadius: fS(6),
    width: '25%',
  },
  imgcont: {
    height: fS(20),
    width: fS(20),
    alignItems: 'center',
    justifyContent: 'center',
  },
  img: {
    height: '100%',
    width: '100%',
    objectFit: 'contain',
  },
  text: {
    fontFamily: F.f5,
    color: C.BLACK,
    fontSize: fS(16),
  },
  topcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dotecont: {
    height: fS(40),
    width: fS(40),
    alignItems: 'center',
    justifyContent: 'center',
  },
  textcont: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: fS(7),
    marginVertical: fS(10),
  },
  lefttext: {
    fontFamily: F.f5,
    fontSize: fS(17),
    color: C.BLACK,
  },
  righttext: {
    fontFamily: F.f3,
    fontSize: fS(17),
    color: C.BLACK,
  },
  menu: {
    position: 'absolute',
    right: fS(35),
    top: fS(40),
    backgroundColor: C.LT_YELLOW,
    borderRadius: fS(10),
    elevation: 2,
    zIndex: 1000,
  },
  menutxt: {
    fontFamily: F.f3,
    color: C.BLACK,
    fontSize: fS(15),
  },
  btncont: {
    paddingStart: fS(10),
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    paddingEnd: fS(40),
    paddingVertical: fS(10),
  },
});
