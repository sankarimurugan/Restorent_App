import {StyleSheet} from 'react-native';
import {fS} from '../../constants/Loader/Loader';

export default StyleSheet.create({
  flexAcJc: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  flexAcJs: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  flexAcJb: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  flexWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  ac: {
    alignItems: 'center',
  },
  ae: {
    alignItems: 'flex-end',
  },
  je: {
    justifyContent: 'flex-end',
  },
  m5: {
    margin: fS(5),
  },
  m10: {
    margin: fS(10),
  },
  m15: {
    margin: fS(15),
  },
  m20: {
    margin: fS(20),
  },
  m30: {
    margin: fS(30),
  },
  m40: {
    margin: fS(40),
  },
  m50: {
    margin: fS(50),
  },
  m70: {
    margin: fS(70),
  },
  m100: {
    margin: fS(100),
  },

  mH5: {
    marginHorizontal: fS(5),
  },
  mH10: {
    marginHorizontal: fS(10),
  },
  mH15: {
    marginHorizontal: fS(15),
  },
  mH20: {
    marginHorizontal: fS(20),
  },
  mH30: {
    marginHorizontal: fS(30),
  },
  mH40: {
    marginHorizontal: fS(40),
  },
  mH50: {
    marginHorizontal: fS(50),
  },
  mH70: {
    marginHorizontal: fS(70),
  },
  mH100: {
    marginHorizontal: fS(100),
  },

  mV5: {
    marginVertical: fS(5),
  },
  mV10: {
    marginVertical: fS(10),
  },
  mV15: {
    marginVertical: fS(15),
  },
  mV20: {
    marginVertical: fS(20),
  },
  mV30: {
    marginVertical: fS(30),
  },
  mV40: {
    marginHorizontal: fS(40),
  },
  mV50: {
    marginVertical: fS(50),
  },
  mV70: {
    marginVertical: fS(70),
  },
  mV100: {
    marginVertical: fS(100),
  },

  mT5: {
    marginTop: fS(5),
  },
  mT10: {
    marginTop: fS(10),
  },
  mT15: {
    marginTop: fS(15),
  },
  mT20: {
    marginTop: fS(20),
  },
  mT30: {
    marginTop: fS(30),
  },
  mT40: {
    marginTop: fS(40),
  },
  mT50: {
    marginTop: fS(50),
  },
  mT70: {
    marginTop: fS(70),
  },
  mT100: {
    marginTop: fS(100),
  },

  mB5: {
    marginBottom: fS(5),
  },
  mB10: {
    marginBottom: fS(10),
  },
  mB15: {
    marginBottom: fS(15),
  },
  mB20: {
    marginBottom: fS(20),
  },
  mB30: {
    marginBottom: fS(30),
  },
  mB40: {
    marginBottom: fS(40),
  },
  mB50: {
    marginBottom: fS(50),
  },
  mB70: {
    marginBottom: fS(70),
  },
  mB100: {
    marginBottom: fS(100),
  },

  mR5: {
    marginRight: fS(5),
  },
  mR10: {
    marginRight: fS(10),
  },
  mR15: {
    marginRight: fS(15),
  },
  mR20: {
    marginRight: fS(20),
  },
  mR30: {
    marginRight: fS(30),
  },
  mR40: {
    marginRight: fS(40),
  },
  mR50: {
    marginRight: fS(50),
  },
  mR70: {
    marginRight: fS(70),
  },
  mR100: {
    marginRight: fS(100),
  },

  mL5: {
    marginLeft: fS(5),
  },
  mL10: {
    marginLeft: fS(10),
  },
  mL15: {
    marginLeft: fS(15),
  },
  mL20: {
    marginLeft: fS(20),
  },
  mL30: {
    marginLeft: fS(30),
  },
  mL40: {
    marginLeft: fS(40),
  },
  mL50: {
    marginLeft: fS(50),
  },
  mL70: {
    marginLeft: fS(70),
  },
  mL100: {
    marginLeft: fS(100),
  },

  p5: {
    padding: fS(5),
  },
  p10: {
    padding: fS(10),
  },
  p15: {
    padding: fS(15),
  },
  p20: {
    padding: fS(20),
  },
  p30: {
    padding: fS(30),
  },
  p40: {
    padding: fS(40),
  },
  p50: {
    padding: fS(50),
  },
  p70: {
    padding: fS(70),
  },
  p100: {
    padding: fS(100),
  },

  pH5: {
    paddingHorizontal: fS(5),
  },
  pH10: {
    paddingHorizontal: fS(10),
  },
  pH15: {
    paddingHorizontal: fS(15),
  },
  pH20: {
    paddingHorizontal: fS(20),
  },
  pH30: {
    paddingHorizontal: fS(30),
  },
  pH40: {
    paddingHorizontal: fS(40),
  },
  p50: {
    padding: fS(50),
  },
  p70: {
    padding: fS(70),
  },
  p100: {
    padding: fS(100),
  },

  pV5: {
    paddingVertical: fS(5),
  },
  pV10: {
    paddingVertical: fS(10),
  },
  pV15: {
    paddingVertical: fS(15),
  },
  pV20: {
    paddingVertical: fS(20),
  },
  pV50: {
    paddingVertical: fS(50),
  },
  pV70: {
    paddingVertical: fS(70),
  },
  pV100: {
    paddingVertical: fS(100),
  },

  pT5: {
    paddingTop: fS(5),
  },
  pT10: {
    paddingTop: fS(10),
  },
  pT15: {
    paddingTop: fS(15),
  },
  pT20: {
    paddingTop: fS(20),
  },
  pT50: {
    paddingTop: fS(50),
  },
  pT70: {
    paddingTop: fS(70),
  },
  pT100: {
    paddingTop: fS(100),
  },

  pB5: {
    paddingBottom: fS(5),
  },
  pB10: {
    paddingBottom: fS(10),
  },
  pB15: {
    paddingBottom: fS(15),
  },
  pB20: {
    paddingBottom: fS(20),
  },
  pB50: {
    paddingBottom: fS(50),
  },
  pB70: {
    paddingBottom: fS(70),
  },
  pB100: {
    paddingBottom: fS(100),
  },

  pR5: {
    paddingRight: fS(5),
  },
  pR10: {
    paddingRight: fS(10),
  },
  pR15: {
    paddingRight: fS(15),
  },
  pR20: {
    paddingRight: fS(20),
  },
  pR50: {
    paddingRight: fS(50),
  },
  pR70: {
    paddingRight: fS(70),
  },
  pR100: {
    paddingRight: fS(100),
  },

  pL5: {
    paddingLeft: fS(5),
  },
  pL10: {
    paddingLeft: fS(10),
  },
  pL15: {
    paddingLeft: fS(15),
  },
  pb20: {
    paddingLeft: fS(20),
  },
  pL50: {
    paddingLeft: fS(50),
  },
  pL70: {
    paddingLeft: fS(70),
  },
  pL100: {
    paddingLeft: fS(100),
  },
});
