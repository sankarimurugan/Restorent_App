export const pic = require('./pic.png');
export const spoon = require('./spoon.png');
export const left = require('./left.png');
export const plate = require('./plate.png');
export const profile = require('./profile.png');
export const scan = require('./scan.png');
export const banner = require('./banner.jpg');
export const table = require('./table.png');
export const food = require('./food.png');
export const india = require('./india.png');
export const food1 = require('./food1.jpg');
export const food2 = require('./food2.jpg');
export const food3 = require('./food3.jpg');
export const food4 = require('./food4.jpg');
export const hamburger = require('./hamburger.png');
export const homeicon = require('./homeicon.png');
export const histry = require('./histry.png');
export const profileicon = require('./profileicon.png');
export const rewards = require('./rewards.png');
export const homesmile = require('./homesmile.png');
export const location = require('./location.png');
export const leftarrow = require('./leftarrow.png');
export const locationicon = require('./locationicon.png');
export const bottomicon = require('./bottomicon.png');
export const delivery = require('./delivery.png');
export const tableicon = require('./tableicon.png');
export const schedule = require('./schedule.png');
export const women = require('./women.png');
export const cart = require('./cart.png');
export const table2 = require('./table2.png');
export const cooking = require('./cooking.png');
export const profile1 = require('./profile1.png');
// export const food4 = require('./food4.png');
export const phonehand = require('./phonehand.png');
export const fooddelivery = require('./fooddelivery.png');
export const process = require('./process.png');
export const detailBanner = require('./detailBanner.png');
export const detailBanner1 = require('./detailBanner1.webp');

export const checkbox = require('./checkbox.png');
export const uncheckbox = require('./uncheckbox.png');
export const eye_hide = require('./eye_hide.png');
export const eye_view = require('./eye_view.png');
export const menu = require('./menu.png');
export const table_img = require('./table_img.png');
export const qr_icon = require('./qr_icon.png');
export const profile_img = require('./profile_img.png');

// Cusisne
export const cusisne1 = require('./cuisine_1.jpg');
export const cusisne2 = require('./cuisine_2.jpg');
export const americaflag = require('./americaflag.png');

// Side Menu Icons

export const home = require('./home_icon.png');
export const map_pin = require('./map_pin.png');
export const heart = require('./heart.png');
export const booklet = require('./booklet.png');
export const gift = require('./gift.png');
export const chat_history = require('./chat_history.png');
export const questionnai = require('./questionnai.png');
export const logout = require('./logout.png');

// Food List

export const start = require('./Star.png');
export const bottomnav = require('./bottomnav.png');
export const rightArrow = require('./rightArrow.png');
export const leftArrowtab = require('./leftArrowtab.png');
export const likeafter = require('./likeafter.png');
export const likebefore = require('./likebefore.png');
export const likes = require('./likes.png');
export const trash = require('./trash.png');
export const empty_reservation = require('./empty_reservation.png');
export const tasty_emoji = require('./tasty_emoji.png');
export const sad = require('./sad.png');
export const cartEmpty = require('./cartEmpty.png');
export const house = require('./house.png');
export const dotes = require('./dotes.png');
export const work = require('./work.png');
export const contact_us = require('./contact_us.png');
export const call = require('./call.png');
export const veg = require('./veg.png');
export const non_veg = require('./non_veg.png');
export const delivered = require('./delivered.png');
export const cancelled = require('./cancelled.png');
export const editicon = require('./editicon.png');
export const pascel = require('./pascel.png');
export const food_delivery = require('./food-delivery.png');
export const deliverybike = require('./deliverybike.png');
export const LocationPin = require('./LocationPin.png');
export const GreenLocation = require('./location_green.png');
export const Tracker = require('./Tracker.png');
export const trackcheck = require('./trackcheck.png');
export const restaurantmap = require('./restaurantmap.png');
export const homemap = require('./homemap.png');
export const bikemap = require('./bikemap.png');
export const mapdown = require('./mapdown.png');
export const emptyOrder = require('./emptyOrder.png');
export const emptycart = require('./emptycart.png');
export const networkerr = require('./networkerr.png');
export const profileboy = require('./profileboy.png');

// Profile
export const shopping_list = require('./shopping_list.png');
export const locationpro = require('./locationpro.png');
export const faqpro = require('./faqpro.png');
export const termpro = require('./termpro.png');
export const shield = require('./shield.png');
export const customerpro = require('./customerpro.png');
export const info_button = require('./info-button.png');
