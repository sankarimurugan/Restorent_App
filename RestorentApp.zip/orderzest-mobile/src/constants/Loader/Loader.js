import React from 'react';

import {
  ActivityIndicator,
  StyleSheet,
  Text,
  View,
  Dimensions,
  Platform,
  PixelRatio,
} from 'react-native';
// import { log } from "react-native-reanimated";

const {width: SCREEN_WIDTH, height: SCREEN_HEIGHT} = Dimensions.get('window');

const fontscale = SCREEN_WIDTH;
const imageScale = SCREEN_WIDTH / 320;

const ScreenHeight = SCREEN_HEIGHT;

export function iS(size) {
  const newSize = size * imageScale;
  if (Platform.OS === 'ios') {
    return Math.round(PixelRatio.get(newSize));
  } else {
    return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2;
  }
}

const fontSize393 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.795;
    case 'tamil':
      return 0.68;
    case 'kanada':
      return 0.75;
    case 'telugu':
      return 0.8;
    case 'hindi':
      return 0.8;
    case 'malayalam':
      return 0.73;
    default:
      return 0.795;
  }
};

const fontSize380 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.82;
    case 'tamil':
      return 0.71;
    case 'kanada':
      return 0.78;
    case 'telugu':
      return 0.83;
    case 'hindi':
      return 0.83;
    case 'malayalam':
      return 0.76;
    default:
      return 0.82;
  }
};
const fontSize370 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.99;
    case 'tamil':
      return 0.89;
    case 'kanada':
      return 0.95;
    case 'telugu':
      return 0.98;
    case 'hindi':
      return 0.98;
    case 'malayalam':
      return 0.9;
    default:
      return 0.99;
  }
};

const fontSize360 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.65;
    case 'tamil':
      return 0.61;
    case 'kanada':
      return 0.61;
    case 'telugu':
      return 0.64;
    case 'hindi':
      return 0.64;
    case 'malayalam':
      return 0.56;
    default:
      return 0.65;
  }
};

const fontSize359 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.8;
    case 'tamil':
      return 0.72;
    case 'kanada':
      return 0.76;
    case 'telugu':
      return 0.79;
    case 'hindi':
      return 0.79;
    case 'malayalam':
      return 0.72;
    default:
      return 0.8;
  }
};

const iFontSize420 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.78;
    case 'tamil':
      return 0.82;
    case 'kanada':
      return 0.78;
    case 'telugu':
      return 0.78;
    case 'hindi':
      return 0.78;
    case 'malayalam':
      return 0.78;
    default:
      return 0.78;
  }
};

const iFontSize393 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.735;
    case 'tamil':
      return 0.835;
    case 'kanada':
      return 0.735;
    case 'telugu':
      return 0.735;
    case 'hindi':
      return 0.735;
    case 'malayalam':
      return 0.735;
    default:
      return 0.735;
  }
};

const iFontSize380 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.7;
    case 'tamil':
      return 0.8;
    case 'kanada':
      return 0.7;
    case 'telugu':
      return 0.7;
    case 'hindi':
      return 0.7;
    case 'malayalam':
      return 0.7;
    default:
      return 0.7;
  }
};

const iFontSize370 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.68;
    case 'tamil':
      return 0.78;
    case 'kanada':
      return 0.68;
    case 'telugu':
      return 0.68;
    case 'hindi':
      return 0.68;
    case 'malayalam':
      return 0.68;
    default:
      return 0.68;
  }
};

const iFontSize360 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.66;
    case 'tamil':
      return 0.76;
    case 'kanada':
      return 0.66;
    case 'telugu':
      return 0.66;
    case 'hindi':
      return 0.66;
    case 'malayalam':
      return 0.66;
    default:
      return 0.66;
  }
};

const iFontSize319 = () => {
  switch (i18next.language) {
    case 'english':
      return 0.6;
    case 'tamil':
      return 0.7;
    case 'kanada':
      return 0.6;
    case 'telugu':
      return 0.6;
    case 'hindi':
      return 0.6;
    case 'malayalam':
      return 0.6;
    default:
      return 0.6;
  }
};

export function fS(size) {
  const newSize = size;
  const font393Size = 0.795;
  const font380Size = 0.82;
  const font370Size = 0.99;
  const font360Size = 0.65;
  const font359Size = 0.8;

  const iFont420Size = 0.78;
  const iFont393Size = 0.735;
  const iFont380Size = 0.7;
  const iFont370Size = 0.68;
  const iFont360Size = 0.66;
  const iFont319Size = 0.6;

  if (Platform.OS === 'ios') {
    // return Math.round(PixelRatio.get(newSize));
    // console.log(fontscale, 'fontscale');
    if (420 < fontscale) {
      // iphone 12 pro max
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont420Size;
    } else if (393 < fontscale) {
      // samsung
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont393Size;
    } else if (380 < fontscale) {
      // vivo
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont380Size;
    } else if (370 < fontscale) {
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont370Size;
    } else if (360 == fontscale) {
      //realmi 5i
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont360Size;
    } else if (359 < fontscale) {
      //honor
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont360Size;
    } else if (319 < fontscale) {
      //honor
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * iFont319Size;
    } else {
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * 0.55;
    }
  } else {
    // console.log(fontscale, 'fontscale');
    // return Math.round(PixelRatio.roundToNearestPixel(newSize)) - 2;
    if (393 < fontscale) {
      // samsung
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * font393Size;
    } else if (380 < fontscale) {
      // vivo
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * font380Size;
    } else if (370 < fontscale) {
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * font370Size;
    } else if (360 == fontscale) {
      //realmi 5i
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * font360Size;
    } else if (359 < fontscale) {
      //honor
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * font359Size;
    } else {
      return Math.round(PixelRatio.roundToNearestPixel(newSize)) * 0.85;
    }
  }
}

export const NUMBER = /^\+?(0|[6-9]\d*)$/;
export const EMAIL =
  /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
export const Loader = () => (
  <View style={[styles.container, styles.horizontal]}>
    <ActivityIndicator size="large" color="#6b18a6F2" />
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  horizontal: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
  },
});

export default Loader;
