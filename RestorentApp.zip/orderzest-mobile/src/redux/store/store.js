import { configureStore } from "@reduxjs/toolkit";
import { rtkQueryErrorLogger } from "../slice/errorLogger";
import { api } from "../api/api";
import alertMessage from "../slice/alertMessage";
import loginHeader from "../slice/loginHeader";

const store = configureStore({
  reducer: {
    alertMessage: alertMessage,
    loginHeader: loginHeader,
    [api.reducerPath]: api.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(api.middleware, rtkQueryErrorLogger),
});

export default store;
