// @ts-nocheck
import { Outlet, Navigate } from "react-router-dom";

const PrivateRoutes = ({ token }) => {
  let temp = localStorage.getItem("token");
  return token || temp ? <Outlet /> : <Navigate to="/" />;
};

export default PrivateRoutes;
