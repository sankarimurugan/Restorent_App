import {
  booklet,
  chat_history,
  customerpro,
  faqpro,
  food,
  food1,
  food2,
  food3,
  food4,
  gift,
  heart,
  home,
  house,
  info_button,
  locationpro,
  logout,
  map_pin,
  questionnai,
  sad,
  shield,
  shopping_list,
  tasty_emoji,
  termpro,
  work,
} from '../../assets/img';
import moment from 'moment';

export const date = moment(new Date()).format('DD MMM YYYY');

export const selecttime = moment(new Date()).format('HH:mm');

export const product_list = [
  {
    name: 'Chicken Briyani',
    amount: '22.50',
    review: '(256 reviews)',
    rating: 4.8,
    img: food3,
  },
  {
    name: 'Burger & Fries',
    amount: '15.80',
    review: '(100 reviews)',
    rating: 4.5,
    img: food1,
  },
  {
    name: 'Falafel',
    amount: '12.50',
    review: '(200 reviews)',
    rating: 4.3,
    img: food2,
  },
  {
    name: 'Spicy Tandoori',
    amount: '14.00',
    review: '(200 reviews)',
    rating: 4.7,
    img: food3,
  },
  {
    name: 'Burritos Wraps',
    amount: '20.00',
    review: '(200 reviews)',
    rating: 4.7,
    img: food4,
  },
  {
    name: 'Chicken Rolls',
    amount: '20.00',
    review: '(200 reviews)',
    rating: 4.0,
    img: food4,
  },
  {
    name: 'Chicken Rolls',
    amount: '20.00',
    review: '(200 reviews)',
    rating: 4.0,
    img: food4,
  },
  {
    name: 'Chicken Rolls',
    amount: '20.00',
    review: '(200 reviews)',
    rating: 4.0,
    img: food4,
  },
  {
    name: 'Chicken Rolls',
    amount: '20.00',
    review: '(200 reviews)',
    rating: 4.0,
    img: food4,
  },
];

export const side_menu_list = [
  {list: 'Home', img: home, navi: 'home'},
  {
    list: 'Address',
    img: map_pin,
    navi: 'EmptyAddress',
  },
  {
    list: 'Favorites',
    img: heart,
    navi: 'favorits',
  },
  {
    list: 'Table Reservation',
    img: booklet,
    navi: 'reservationscreen',
  },
  {
    list: 'Rewards',
    img: gift,
    navi: 'home',
  },
  {
    list: 'Orders',
    img: chat_history,
    navi: 'orders',
  },
  {
    list: 'Help & Support',
    img: questionnai,
    navi: 'help&support',
  },
];

export const book_tabele = [
  {
    id: 1,
    table: 3,
  },
];

export const cartList = [
  {
    naem: 'Chicken Briyani',
    amount: '22.50',
    img: food1,
  },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
  // {
  //   naem: 'Chicken Briyani',
  //   amount: '22.50',
  //   img: food1,
  // },
];

export const reservationList = [
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 03',
    time: 'Reservation Date & Time : 7th Oct - 11:30 AM - 12:30 PM',
    comments: 'You have ordered food for this Table Reservation',
    icon: sad,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: tasty_emoji,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: sad,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: tasty_emoji,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: sad,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: tasty_emoji,
  },
  {
    name: 'Wingman’s Restaurant',
    tablecount: 'Reserved Table No : 02',
    time: 'Reservation Date & Time : 10th Oct - 4:30 PM - 6:30 PM  ',
    comments: 'It seems like no food has been ordered for this reservation.',
    icon: sad,
  },
];

export const foodlist = [
  {
    name: 'Chicken Briyani',
    amount: '22.50',
    qty: '01',
  },
  {
    name: 'Dosai',
    amount: '22.00',
    qty: '01',
  },
  {
    name: 'Pongal',
    amount: '20.00',
    qty: '01',
  },
  {
    name: 'Pongal',
    amount: '20.00',
    qty: '01',
  },
  {
    name: 'Pongal',
    amount: '20.00',
    qty: '01',
  },
  {
    name: 'Pongal',
    amount: '20.00',
    qty: '01',
  },
];

export const address_list = [
  {
    icon: house,
    iconName: 'Home',
    name: 'Stella Chrish',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
  {
    icon: work,
    iconName: 'Work',
    name: 'Sankari',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
  {
    icon: work,
    iconName: 'Work',
    name: 'Sankari',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
  {
    icon: house,
    iconName: 'Home',
    name: 'Stella Chrish',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
];
export const address_list2 = [
  {
    icon: house,
    iconName: 'Home',
    name: 'Stella Chrish',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
  {
    icon: work,
    iconName: 'Work',
    name: 'Sankari',
    no: '+1-212-456-7890',
    address: '132, My Street, Kingston, New York 12401.',
  },
];

export const ongoing_order_list = [
  {
    name: 'Wingsman’s Restaurant',
  },
];

export const profile_list = [
  {
    name: 'My Order List',
    img: shopping_list,
    navi: 'orders',
  },
  {
    name: 'Manage Address',
    img: locationpro,
    navi: 'address',
  },
  {
    name: 'FAQs',
    img: faqpro,
    navi: 'profile',
  },
  {
    name: 'Terms & Conditions',
    img: termpro,
    navi: 'profile',
  },
  {
    name: 'Privacy Policy',
    img: shield,
    navi: 'profile',
  },
  {
    name: 'Help & Support',
    img: customerpro,
    navi: 'help&support',
  },
  {
    name: 'About OZ Pos',
    img: info_button,
    navi: 'profile',
  },
];
